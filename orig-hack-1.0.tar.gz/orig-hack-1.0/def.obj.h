/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1984. */

struct obj {
    struct obj *nobj;
    unsigned o_id;
    unsigned o_cnt_id;/* id of container object is in */
    xchar ox,oy;
    xchar odx,ody;
    uchar otyp;
    uchar owt;
    unsigned quan;/* small in general but large in case of gold */
    schar spe;
    char olet;
    Bitfield(oinvis,1);
    Bitfield(odispl,1);
    Bitfield(known,1);/* exact nature known */
    Bitfield(dknown,1);/* color or text known */
    Bitfield(cursed,1);
    Bitfield(unpaid,1);/* on some bill */
    Bitfield(rustfree,1);
    Bitfield(onamelth,6);
    long age;/* creation date */
    long owornmask;
#defineW_ARM01L
#defineW_ARM202L
#defineW_ARMH04L
#defineW_ARMS010L
#defineW_ARMG020L
#defineW_ARMOR(W_ARM | W_ARM2 | W_ARMH | W_ARMS | W_ARMG)
#defineW_RINGL010000L/* make W_RINGL = RING_LEFT (see uprop) */
#defineW_RINGR020000L
#defineW_RING(W_RINGL | W_RINGR)
#defineW_WEP01000L
#defineW_BALL02000L
#defineW_CHAIN04000L
    long oextra[1];
};

extern struct obj *fobj;

#define newobj(xl)(struct obj *) alloc((unsigned)(xl) + sizeof(struct obj))
#defineONAME(otmp)((char *) otmp->oextra)
