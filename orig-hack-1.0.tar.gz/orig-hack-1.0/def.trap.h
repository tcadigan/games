/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1984. */

/* various kinds of traps */
#define BEAR_TRAP0
#defineARROW_TRAP1
#defineDART_TRAP2
#define TRAPDOOR3
#defineTELEP_TRAP4
#define PIT 5
#define SLP_GAS_TRAP6
#definePIERC7
#defineMIMIC8/* used only in mklev.c */
/* before adding more trap types, check mfndpos ! */
/* #define SEEN 32 - trap which has been seen */
