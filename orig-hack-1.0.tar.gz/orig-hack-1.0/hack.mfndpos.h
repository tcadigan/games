/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1984. */

#defineALLOW_TRAPS0777
#defineALLOW_U01000
#defineALLOW_M02000
#defineALLOW_TM04000
#defineALLOW_ALL(ALLOW_U | ALLOW_M | ALLOW_TM | ALLOW_TRAPS)
#defineALLOW_SSM010000
#defineALLOW_ROCK020000
#defineNOTONL040000
#defineNOGARLIC0100000
