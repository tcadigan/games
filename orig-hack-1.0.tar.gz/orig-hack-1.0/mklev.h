/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1984. */

#include "config.h"

#ifdef BSD
#include <strings.h>/* declarations for strcat etc. */
#else
#include <string.h>/* idem on System V */
#defineindexstrchr
#definerindexstrrchr
#endif BSD

#include"def.objclass.h"

typedef struct {
    xchar x,y;
} coord;

#include"def.monst.h"/* uses coord */
#include"def.gen.h"
#include"def.obj.h"

extern char *sprintf();

#defineBUFSZ256/* for getlin buffers */
#definePL_NSIZ32/* name of player, ghost, shopkeeper */

#defineHWALL 1/* Level location types */
#defineVWALL 2
#defineSDOOR 3
#defineSCORR 4
#defineLDOOR 5
#defineDOOR 6/* smallest accessible type */
#defineCORR 7
#defineROOM 8
#defineSTAIRS 9
#ifdef QUEST
#defineCORR_SYM':'
#else
#defineCORR_SYM'#'
#endif QUEST

#defineERRCHAR'{'

#define TRAPNUM 9

struct rm {
    char scrsym;
    unsigned typ:5;
    unsigned new:1;
    unsigned seen:1;
    unsigned lit:1;
};
extern struct rm levl[COLNO][ROWNO];

#ifndef QUEST
struct mkroom {
    xchar lx,hx,ly,hy;
    schar rtype,rlit,doorct,fdoor;
};
#defineMAXNROFROOMS15
extern struct mkroom rooms[MAXNROFROOMS+1];
#defineDOORMAX100
extern coord doors[DOORMAX];
#endif QUEST


#include"def.permonst.h"
extern struct permonst mons[];
#define PM_ACIDBLOB&mons[7]
#definePM_PIERC&mons[17]
#definePM_MIMIC&mons[37]
#definePM_CHAM&mons[47]
#definePM_DEMON&mons[54]
#definePM_MINOTAUR&mons[55]/* last in mons array */
#definePM_SHK&mons[56]/* very last */
#defineCMNUM55/* number of common monsters */

extern long *alloc();

extern xchar xdnstair, ydnstair, xupstair, yupstair; /* stairs up and down. */

extern xchar dlevel;
#ifdef WIZARD
extern boolean wizard;
#endif WIZARD
#definenewstring(x)(char *) alloc((unsigned)(x))
