/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1984. */

struct permonst {
    char *mname,mlet;
    schar mlevel,mmove,ac,damn,damd;
    unsigned pxlth;
};
