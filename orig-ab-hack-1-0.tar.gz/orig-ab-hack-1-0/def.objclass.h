/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1984. */

/* definition of a class of objects */

struct objclass {
    char *oc_name;/* actual name */
    char *oc_descr;/* description when name unknown */
    char *oc_uname;/* called by user */
    Bitfield(oc_name_known,1);
    Bitfield(oc_merge,1);/* merge otherwise equal objects */
    char oc_olet;
    schar oc_prob;/* probability for mkobj() */
    schar oc_delay;/* delay when using such an object */
    uchar oc_weight;
    schar oc_oc1, oc_oc2;
    int oc_oi;
#definenutritionoc_oi/* for foods */
#definea_acoc_oc1/* for armors */
#definea_canoc_oc2/* for armors */
#define bitsoc_oc1/* for wands and rings */
    /* wands */
#defineNODIR1
#defineIMMEDIATE2
#defineRAY4
    /* rings */
#defineSPEC1/* +n is meaningful */
#definewldamoc_oc1/* for weapons */
#definewsdamoc_oc2/* for weapons */
#defineg_valoc_oi/* for gems: value on exit */
};

extern struct objclass objects[];

/* definitions of all object-symbols */

#defineILLOBJ_SYM'\\'
#defineAMULET_SYM'"'
#defineFOOD_SYM'%'
#defineWEAPON_SYM')'
#defineTOOL_SYM'('
#defineBALL_SYM'0'
#defineCHAIN_SYM'_'
#defineROCK_SYM'`'
#defineARMOR_SYM'['
#definePOTION_SYM'!'
#defineSCROLL_SYM'?'
#defineWAND_SYM'/'
#defineRING_SYM'='
#defineGEM_SYM'*'
/* Other places with explicit knowledge of object symbols:
* ....shk.c:char shtypes[] = "=/)%?![";
* mklev.c:"=/)%?![<>"
* hack.mkobj.c:char mkobjstr[] = "))[[!!!!????%%%%/=**";
 * hack.apply.c:   otmp = getobj("0#%", "put in");
 * hack.eat.c:     otmp = getobj("%", "eat");
 * hack.invent.c:          if(index("!%?[)=*(0/\"", sym)){
 * hack.invent.c:    || index("%?!*",otmp->olet))){
 */
