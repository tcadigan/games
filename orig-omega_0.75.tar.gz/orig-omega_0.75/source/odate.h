/* omega copyright (C) by Laurence Raphael Brothers, 1987,1988,1989 */
/* odate.h */

#define LAST_OMEGA_EDIT_DATE "Thu May  4 14:38:33 EST 1989"

