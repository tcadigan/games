/* omega copyright (c) 1987,1988,1989 by Laurence Raphael Brothers */

/* oinit.c */

#include "odefs.h"

#include "oiinit.h"

#include "ominit.h"

/* This file contains all the object and monster definitions */