#ifndef _VERSION_H__
#define _VERSION_H__

#define OPENGLAD_VERSION_STRING "1.1.1"

#endif
