/*
 * PhysicsFS - ruby interface
 * 
 * Author::  Ed Sinjiashvili (slimb@vlinkmail.com)
 * License:: LGPL
 */

#ifndef __RB__PHYSFS__H__
#define __RB__PHYSFS__H__

extern VALUE modulePhysfs;

#endif
