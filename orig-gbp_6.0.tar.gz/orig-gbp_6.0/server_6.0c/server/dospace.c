/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)dospace.c        1.10 12/1/93  
 */

#include <math.h>
#include <ctype.h>
#include <strings.h>
#include <string.h>
#include <stdlib.h>

#include "GB_copyright.h"
#define EXTERN
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "doturn.h"
#include "power.h"
#include "buffers.h"
#include "tweakables.h"

extern char    *Commod[];
extern long     Shipdata[NUMSTYPES][NUMABILS];

void            do_turn(int);
int             APadd(int, int, racetype *);
int             governed(racetype *);
void            fix_stability(startype *);
void            do_reset(int);
void            handle_victory(void);
void            make_discoveries(racetype *);

#ifdef MARKET
void            maintain(racetype *, int, int);
#endif
int             attack_planet(shiptype *);
void            output_ground_attacks(void);
int             planet_points(planettype *);
int             vp_planet_points(planettype *);

#include "proto.h"

#define ALIVE(i)    (ships[i] != NULL && ships[i]->alive && ships[i]->owner)

void
doOrbit(int shipNo)
{
  shiptype       *sh;
  planettype     *pl;
  int             i, damage = COMBAT_ORBIT_DAMAGE;
  char            buf2[255];

  if (!valid_ship(shipNo))
    return;
  sh = ships[shipNo];

  if (!ALIVE(shipNo))
    return;

  if (sh->whatorbits != LEVEL_PLAN)
    return;

  pl = planets[sh->storbits][sh->pnumorbits];

  /* if they own it do nothing */
  if (pl->info[sh->owner - 1].numsectsowned > 0)
    return;

  for (i = 1; i <= Num_races; i++)
  {
    if (i != sh->owner && pl->info[i - 1].numsectsowned > 0 &&
        (!isset(races[sh->owner - 1]->allied, i) ||
         !isset(races[i - 1]->allied, sh->owner)))
    {
      /* orbiting inhabited planet - do damage */
      sh->damage += damage;
      sprintf(buf, "Ship #[%d] orbiting inhabited planet before \
combat update [%d], incurred [%d%%] damage.\n", shipNo, CombatUpdate, damage);

      if (sh->damage >= 100)
        kill_ship(sh->owner, sh);

      if (!sh->alive)
      {
        strcat(buf, "Damage incurred destroyed ship.\n");
      }
      warn((int)sh->owner, (int)sh->governor, buf);
      sprintf(buf2, "[%d,%d]", sh->owner, sh->governor);
      strcat(buf2, buf);
      post(buf2, COMBAT);

      sh->build_cost = (int)cost(sh);
    }
  }
  return;
}

void
doUniv(int shipNo)
{
  shiptype       *sh;
  unsigned short  damage;
  double          dmg;
  char            buf2[512];

  if (!valid_ship(shipNo))
    return;

  sh = ships[shipNo];

  memset(buf2, 0, sizeof (buf2));

  if (!ALIVE(shipNo))
    return;

  if (sh->whatorbits != LEVEL_UNIV)
    return;

  if (sh->type == OTYPE_PROBE)
    return;

  dmg = 20 / (1 + (sh->tech / 50));

  if (int_rand(1, 100) <= (dmg + sh->damage))
  {
    damage = dmg;

    if (damage < 1)
      damage = 1;
    else if (damage > 100)
      damage = 100;

    sh->damage += damage;

    if (sh->damage >= 100.0)
    {
      sprintf(buf2,
              "Ship [#%d] headed for %s, in trouble in deep space. %d%% damage incurred. Damage incurred destroyed ship.",
              shipNo, prin_ship_dest(sh->owner, sh->governor, sh), damage);

      kill_ship(sh->owner, sh);

      push_telegram((int)sh->owner, (int)sh->governor, buf2);
    }
    else if ((damage > 10.0 || sh->damage > 70.0) && sh->wants_reports)
    {
      sprintf(buf2,
              "Ship [#%d] headed for %s, in trouble in deep space. %d%% damage incurred.",
              shipNo, prin_ship_dest(sh->owner, sh->governor, sh), damage);

      push_telegram((int)sh->owner, (int)sh->governor, buf2);
    }
  }
}
