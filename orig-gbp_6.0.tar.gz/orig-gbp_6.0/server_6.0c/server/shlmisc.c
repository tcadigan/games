/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)shlmisc.c  1.12 12/3/93 "
 * 
 * miscellaneous stuff included in the shell
 
 $Header: /var/cvs/gbp/GB+/server/shlmisc.c,v 1.5 2007/07/06 17:30:26 gbp Exp $
 
 static char *ver = "@(#)  $RCSfile: shlmisc.c,v $ $Revision: 1.5 $";
 */

#include <stdlib.h>
#include <string.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "races.h"
#include "power.h"
#include "ships.h"
#include "buffers.h"
#include "ranks.h"
#include "tweakables.h"
#include <curses.h>
#include <signal.h>
#include <ctype.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

char           *Ship(shiptype * s);
void            grant(int, int, int);
void            governors(int, int, int);
void            do_revoke(racetype *, int, int);
int             do_shiplist(shiptype **, int *);
int             in_list(int, char *, shiptype *, int *);
void            fix(int, int);
void            DontOwnErr(int, int, int);

#ifdef CHAP_AUTH
int             Getracenum(char *, char *, int *, int *, char *, int);
#else
int             Getracenum(char *, char *, int *, int *);
#endif
int             GetPlayer(char *);
void            allocateAPs(int, int, int);
void            deductAPs(int, int, int, int, int);
void            list(int, int);
double          morale_factor(double);
EXTERN int      authorized(int, shiptype *);
EXTERN int      authorized_in_star(int, int, startype *);

#include "proto.h"

char           *
Ship(shiptype * s)
{
  adr = !adr;                   /* switch between 0 and 1 - adr is a global *
                                 * variable */
  sprintf(junk[adr], "%c%d %s [%d]", Shipltrs[s->type], s->number, s->name,
          s->owner);
  return junk[adr];             /* junk is a global buffer */
}

void
grant(int Playernum, int Governor, int APcount)
{
  racetype       *Race;
  int             gov, nextshipno, shipno;
  shiptype       *ship;

  /* 
   * int warned = 0; */

  Race = races[Playernum - 1];
  if (argn < 3)
  {
    notify(Playernum, Governor, "Syntax: grant <governor> star\n");
    notify(Playernum, Governor, "        grant <governor> ship <shiplist>\n");
    notify(Playernum, Governor, "        grant <governor> money <amount>\n");
    return;
  }
  if ((gov = atoi(args[1])) < 0 || gov > MAXGOVERNORS)
  {
    notify(Playernum, Governor, "Bad governor number.\n");
    return;
  }
  else if (!Race->governor[gov].active)
  {
    notify(Playernum, Governor, "That governor is not active.\n");
    return;
  }
  else if (match(args[2], "star"))
  {
    int             snum;

    if (Dir[Playernum - 1][Governor].level != LEVEL_STAR)
    {
      notify(Playernum, Governor, "Please cs to the star system first.\n");
      return;
    }
    snum = Dir[Playernum - 1][Governor].snum;
    Stars[snum]->governor[Playernum - 1] = gov;
    sprintf(buf, "\"%s\" has granted you control of the /%s star system.\n",
            Race->governor[Governor].name, Stars[snum]->name);
    warn(Playernum, gov, buf);
    putstar(Stars[snum], snum);
  }
  else if (match(args[2], "ship"))
  {
    nextshipno = start_shiplist(Playernum, Governor, args[3]);
    while ((shipno = do_shiplist(&ship, &nextshipno)))
      if (in_list(Playernum, args[3], ship, &nextshipno))
      {

        ship->governor = gov;
        sprintf(buf, "\"%s\" granted you %s at %s\n",
                Race->governor[Governor].name, Ship(ship),
                prin_ship_orbits(ship));
        warn(Playernum, gov, buf);
        putship(ship);
        sprintf(buf, "%s granted to \"%s\"\n", Ship(ship),
                Race->governor[gov].name);
        notify(Playernum, Governor, buf);
        free((char *)ship);
      }
      else
        free((char *)ship);
  }
  else if (match(args[2], "money"))
  {
    int             amount;

    if (argn < 4)
    {
      notify(Playernum, Governor, "Indicate the amount of money.\n");
      return;
    }
    amount = atoi(args[3]);
    if ((long)amount > MONEY(Race, Governor) &&
        (long)-amount > -(MONEY(Race, Governor)))
    {
      notify(Playernum, Governor, "Illegal amount\n");
      return;
    }

    if (amount > 0)
    {                           /* add to a gov */
      sprintf(buf, "\"%s\" granted you %d money.\n",
              Race->governor[Governor].name, amount);
      warn(Playernum, gov, buf);
      MONEY(Race, Governor) -= abs(amount);
      MONEY(Race, gov) += abs(amount);
    }
    else if (amount < 0)
    {                           /* deduct from a gov */
      sprintf(buf, "\"%s\" docked you %d money.\n",
              Race->governor[Governor].name, -amount);
      warn(Playernum, gov, buf);
      MONEY(Race, Governor) += abs(amount);
      MONEY(Race, gov) -= abs(amount);

    }
    putrace(Race);
    return;
  }
  else
    notify(Playernum, Governor, "You can't grant that.\n");

}

void
governors(int Playernum, int Governor, int APcount)
{
  racetype       *Race;
  reg int         i;
  char            rank[9];
  int             gov;

  Race = races[Playernum - 1];

  if (Governor || argn < 3)     /* the only thing governors can do with this */
  {
    for (i = 0; i <= MAXGOVERNORS; i++)
    {
      if (Race->governor[i].active)
      {
        switch (Race->governor[i].rank)
        {
          case LEADER:
            strcpy(rank, "LEADER ");
            break;
          case GENERAL:
            strcpy(rank, "GENERAL");
            break;
          case CAPTAIN:
            strcpy(rank, "CAPTAIN");
            break;
          case PRIVATE:
            strcpy(rank, "PRIVATE");
            break;
          case NOVICE:
            strcpy(rank, "NOVICE ");
            break;
          default:
            strcpy(rank, "UNKNOWN");
            break;
        }
      }
      else
      {
        /* governor isnt active */
        strcpy(rank, "        ");
      }

      if (Governor)
      {
        sprintf(buf, "%d %-15.15s %8s %8s %10ld %s", i, Race->governor[i].name,
                Race->governor[i].active ? "ACTIVE" : "INACTIVE", rank,
#ifndef COLLECTIVE_MONEY
                MONEY(Race, i),
#else
                (i != 0) ? 0 : MONEY(Race, 0),
#endif
                ctime(&Race->governor[i].last_login));
      }
      else
      {
        sprintf(buf, "%d %-12.12s %-10.10s %8s %8s %10ld %s", i,
                Race->governor[i].name, Race->governor[i].password, rank,
                Race->governor[i].active ? "ACTIVE" : "INACTIVE", MONEY(Race,
                                                                        i),
                ctime(&Race->governor[i].last_login));
      }

      notify(Playernum, Governor, buf);
    }
  }
  else if ((gov = atoi(args[1])) < 0 || gov > MAXGOVERNORS)
  {
    notify(Playernum, Governor, "No such governor.\n");
    return;
  }
  else if (match(args[0], "appoint"))
  {
    /* Syntax: 'appoint <govnum> <govname> <password> <level>' */

    if (Race->governor[gov].active)
    {
      notify(Playernum, Governor, "That governor is already appointed.\n");
      return;
    }

    if (argn < 4)
    {
      notify(Playernum, Governor, "Invalid number of arguments.\n");
      return;
    }

    if (0 == strlen(args[2]))
    {
      notify(Playernum, Governor, "Bad governor name, try again.\n");
      return;
    }
    else
    {
      strncpy(Race->governor[gov].name, args[2], RNAMESIZE - 1);
    }

    if (argn < 5)
      Race->governor[gov].rank = PRIVATE;
    else
    {
      if (match(args[4], "general"))
        Race->governor[gov].rank = GENERAL;
      else if (match(args[4], "captain"))
        Race->governor[gov].rank = CAPTAIN;
      else if (match(args[4], "private"))
        Race->governor[gov].rank = PRIVATE;
      else if (match(args[4], "novice"))
        Race->governor[gov].rank = NOVICE;
      else
      {
        notify(Playernum, Governor, "Invalid level for governor\n");
        return;
      }
    }

    if (Race->Guest)
      Race->governor[gov].rank = GUEST_RANK;

    Race->governor[gov].active = 1;
    Race->governor[gov].homelevel = Race->governor[gov].deflevel =
      Race->governor[0].deflevel;
    Race->governor[gov].homesystem = Race->governor[gov].defsystem =
      Race->governor[0].defsystem;
    Race->governor[gov].homeplanetnum = Race->governor[gov].defplanetnum =
      Race->governor[0].defplanetnum;
#ifndef COLLECTIVE_MONEY
    MONEY(Race, gov) = 0;
#endif
    Race->governor[gov].toggle.highlight = Playernum;
    Race->governor[gov].toggle.inverse = 1;
    strncpy(Race->governor[gov].password, args[3], RNAMESIZE - 1);
    putrace(Race);
    notify(Playernum, Governor, "Governor activated.\n");
    return;
  }
  else if (match(args[0], "promote") || match(args[0], "demote"))
  {
    if (!Race->governor[gov].active)
    {
      notify(Playernum, Governor, "That governor isn't active!\n");
      return;
    }

    if (Race->Guest)
    {
      notify(Playernum, Governor,
             "You cannot promote or demote a guest race!\n");
      return;
    }

    if (gov == 0)
    {
      notify(Playernum, Governor, "You cannot promote or demote the leader!\n");
      return;
    }

    if (match(args[2], "leader"))
    {
      notify(Playernum, Governor,
             "Only governor 0 can be designated a leader, PUTZ!\n");
      return;
    }
    else if (match(args[2], "general"))
      Race->governor[gov].rank = GENERAL;
    else if (match(args[2], "captain"))
      Race->governor[gov].rank = CAPTAIN;
    else if (match(args[2], "private"))
      Race->governor[gov].rank = PRIVATE;
    else if (match(args[2], "novice"))
      Race->governor[gov].rank = NOVICE;
    else
    {
      notify(Playernum, Governor, "Invalid level for governor\n");
      return;
    }
    putrace(Race);
  }
  else if (match(args[0], "revoke"))
  {
    reg int         j;

    if (!gov)
    {
      notify(Playernum, Governor, "You can't revoke your leadership!\n");
      return;
    }

    if (!Race->governor[gov].active)
    {
      notify(Playernum, Governor, "That governor is not active.\n");
      return;
    }

    if (argn < 4)
      j = 0;
    else
      j = atoi(args[3]);        /* who gets this governors * stuff */
    if (j < 0 || j > MAXGOVERNORS)
    {
      notify(Playernum, Governor, "You can't give stuff to that governor!\n");
      return;
    }
    if (!strcmp(Race->governor[gov].password, args[2]))
    {
      notify(Playernum, Governor, "Incorrect password.\n");
      return;
    }
    if (!Race->governor[j].active || j == gov)
    {
      notify(Playernum, Governor, "Bad target governor.\n");
      return;
    }
    do_revoke(Race, gov, j);    /* give stuff from gov to j */
    putrace(Race);
    notify(Playernum, Governor, "Done.\n");
    return;
  }
  else if (match(args[2], "password"))
  {
    if (Race->Guest)
    {
      notify(Playernum, Governor, "Guest races cannot change passwords.\n");
      return;
    }
    if (argn < 4)
    {
      notify(Playernum, Governor, "You must give a password.\n");
      return;
    }
    if (!Race->governor[gov].active)
    {
      notify(Playernum, Governor, "That governor is inactive.\n");
      return;
    }
    strncpy(Race->governor[gov].password, args[3], RNAMESIZE - 1);
    putrace(Race);
    notify(Playernum, Governor, "Password changed.\n");
    return;
  }
  else
    notify(Playernum, Governor, "Bad option.\n");
}

void
do_revoke(racetype * Race, int gov, int j)
{
  register int    i;
  char            revoke_buf[1024];
  shiptype       *ship;

  sprintf(revoke_buf, "*** Transferring [%d,%d]'s ownings to [%d,%d] ***\n\n",
          Race->Playernum, gov, Race->Playernum, j);
  notify(Race->Playernum, 0, revoke_buf);

  /* First do stars....  */

  for (i = 0; i < Sdata.numstars; i++)
    if (Stars[i]->governor[Race->Playernum - 1] == gov)
    {
      Stars[i]->governor[Race->Playernum - 1] = j;
      sprintf(revoke_buf, "Changed jurisdiction of /%s...\n", Stars[i]->name);
      notify(Race->Playernum, 0, revoke_buf);
      putstar(Stars[i], i);
    }
  /* Now do ships....  */
  Num_ships = Numships();
  for (i = 1; i <= Num_ships; i++)
  {
    (void)getship(&ship, i);
    if (ship->alive && (ship->owner == Race->Playernum) &&
        (ship->governor == gov))
    {
      ship->governor = j;
      sprintf(revoke_buf, "Changed ownership of %c%d...\n",
              Shipltrs[ship->type], i);
      notify(Race->Playernum, 0, revoke_buf);
      putship(ship);
    }
    free((char *)ship);
  }

  /* And money too....  */

#ifndef COLLECTIVE_MONEY
  sprintf(revoke_buf, "Transferring %ld money...\n", MONEY(Race, gov));
  notify(Race->Playernum, 0, revoke_buf);
  MONEY(Race, j) = MONEY(Race, j) + MONEY(Race, gov);
  MONEY(Race, gov) = 0;
#endif

  /* And last but not least, flag the governor as inactive.... */

  Race->governor[gov].active = 0;
  strcpy(Race->governor[gov].password, "");
  strcpy(Race->governor[gov].name, "");
  sprintf(revoke_buf, "\n*** Governor [%d,%d]'s powers have been REVOKED ***\n",
          Race->Playernum, gov);
  notify(Race->Playernum, 0, revoke_buf);
  sprintf(revoke_buf, "rm %s.%d.%d", TELEGRAMFL, Race->Playernum, gov);
  system(revoke_buf);           /* Remove the telegram file too....  */

  return;
}

int
start_shiplist(int Playernum, int Governor, const char *string)
{
  const char     *p;
  planettype     *planet;
  shiptype       *ship;
  int             st, pl, sh, fl;
  char           *c;

  p = string;

  if (*p == '#')
    return (atoi(++p));
  if (isdigit((unsigned char)*p))
    return (atoi(p));

  if (*p == '%')
  {
    /* We're talking about a fleet! -mfw */

    c = (char *)++p;

    fl = fctofi(*c);

    if (fl > 0 && races[Playernum - 1]->fleet[fl].admiral != Governor &&
        races[Playernum - 1]->fleet[fl].flagship != 0)
    {
      notify(Playernum, Governor, "You're not admiral of the source fleet.\n");
      return 0;
    }

    if (fl > MAXFLEETS || fl < 1)
      return 0;
    else
      return races[Playernum - 1]->fleet[fl].flagship;
  }

  /* ship number not given */
  st = Dir[Playernum - 1][Governor].snum;
  pl = Dir[Playernum - 1][Governor].pnum;
  switch (Dir[Playernum - 1][Governor].level)
  {
    case LEVEL_UNIV:
      getsdata(&Sdata);
      return Sdata.ships;
    case LEVEL_STAR:
      getstar(&Stars[st], st);  /* Stars doesn't need to be * freed */
      return Stars[st]->ships;
    case LEVEL_PLAN:
      getplanet(&planet, st, pl);
      sh = planet->ships;
      free((char *)planet);
      return sh;
    case LEVEL_SHIP:
      (void)getship(&ship, Dir[Playernum - 1][Governor].shipno);
      sh = ship->ships;
      free((char *)ship);
      return sh;
    default:
      break;
  }
  return 0;
}

/* Step through linked list at current player scope */
int
do_shiplist(shiptype ** s, int *nextshipno)
{
  int             shipno;

  /* HUTm (kse) now we should be able to go through all ship lists even if
   * there were some dead ships */
  do
  {
    /* nextshipno should be index of next ship in the list */
    if (!(shipno = *nextshipno))
      /* if index is 0 list is at end */
      return 0;

    if (!getship(s, shipno))    /* allocate memory, free in loop */
      /* if we can't get that ship there must be some error */
      return 0;

    if (!(*s)->alive)           /* this prevents it from returning a dead ship */
      return 0;                 /* ie: try to scrap a dead ship JPD */

    /* new head of list is next of current ship */
    *nextshipno = (*s)->nextship;

    /* if current ship is alive return it's index */
    if ((*s)->alive)
      return shipno;
  }
  /* if ships was not alive iterate next list item */
  while (!(*s)->alive);

  /* we should not get here (?) */
  return 0;
}

int
in_list(int Playernum, char *list, shiptype * s, int *nextshipno)
{
  char           *p, q;
  char           *c;

  if ((!races[Playernum - 1]->God && s->owner != Playernum) || !s->alive)
    return 0;

  q = Shipltrs[s->type];
  p = list;
  if (*p == '#' || isdigit((unsigned char)*p))
  {
    if ((!races[Playernum - 1]->God && s->owner != Playernum) || !s->alive)
      return 0;
    *nextshipno = 0;
    return s->number;
  }

  if (*p == '%')
  {
    c = (char *)++p;

    /* Is the ship in this fleet? -mfw */
    if ((*c == fitofc(s->fleetmember)) || (*c == (fitofc(s->fleetmember) + 32)))
    {
      *nextshipno = s->nextinfleet;
      return s->number;
    }
    else
    {
      return 0;
    }
  }

  for (; *p; p++)
    if (*p == q || *p == '*')
      return s->number;         /* '*' is a wildcard */
  return 0;
}

/* Deity fix-it utilities */
void
fix(int Playernum, int Governor)
{
  planettype     *p;
  shiptype       *s;
  int             x, y;

  if (match(args[1], "sector"))
  {
    char           *what;
    long            amt;
    sectortype     *sect;

    if (Dir[Playernum - 1][Governor].level != LEVEL_PLAN)
    {
      notify(Playernum, Governor, "Change scope to the planet first.\n");
      return;
    }

    /* fix sector routines */
    if (argn < 6)
    {
      /* error */
      notify(Playernum, Governor, "Not enough args\n");
      return;
    }

    x = atoi(args[2]);
    y = atoi(args[3]);
    what = args[4];
    amt = atoi(args[5]);

    getplanet(&p, Dir[Playernum - 1][Governor].snum,
              Dir[Playernum - 1][Governor].pnum);

    getsector(&sect, p, x, y);

    sprintf(buf, "Owner=%d\n", sect->owner);
    notify(Playernum, Governor, buf);

    /* now what? */
    if (match(what, "res"))
    {
      sect->resource = amt;
      sprintf(buf, "Sector resource set to %d\n", sect->resource);
    }
    else if (match(what, "mob"))
    {
      sect->mobilization = amt;
      sprintf(buf, "Sector mobility set to %d\n", sect->mobilization);
    }
    else if (match(what, "owner"))
    {
      sect->owner = amt;
      sprintf(buf, "Sector owner set to %d\n", sect->owner);
    }
    else if (match(what, "popn"))
    {
      sect->popn = amt;
      sprintf(buf, "sector population set to %d\n", sect->popn);
    }
    else if (match(what, "eff"))
    {
      sect->eff = amt;
      sprintf(buf, "sector efficiency set to %d\n", sect->eff);
    }
    else if (match(what, "mil"))
    {
      sect->troops = amt;
      sprintf(buf, "sector military set to %d\n", sect->troops);
    }
    else if (match(what, "fert"))
    {
      sect->fert = amt;
      sprintf(buf, "sector fertility set to %d\n", sect->fert);
    }
    else if (match(what, "cond"))
    {
      sect->condition = amt;
      sprintf(buf, "sector condition set to %d\n", sect->condition);
    }
    else if (match(what, "type"))
    {
      sect->type = amt;
      sprintf(buf, "sector type set to %d\n", sect->type);
    }
    else if (match(what, "xtals"))
    {
      sect->crystals = amt;
      sprintf(buf, "sector crystals set to %d\n", sect->crystals);
    }
    else
    {
      notify(Playernum, Governor, "No such option for 'fix sector'.\n");
      free(sect);
      free(p);
      return;
    }

    putsector(sect, p, x, y);
    free(sect);
    free(p);

    notify(Playernum, Governor, buf);

    return;
  }
  else if (match(args[1], "planet"))
  {
    if (Dir[Playernum - 1][Governor].level != LEVEL_PLAN)
    {
      notify(Playernum, Governor, "Change scope to the planet first.\n");
      return;
    }

    getplanet(&p, Dir[Playernum - 1][Governor].snum,
              Dir[Playernum - 1][Governor].pnum);

    if (match(args[2], "Maxx"))
    {
      if (argn > 3)
        p->Maxx = atoi(args[3]);

      sprintf(buf, "Maxx = %d\n", p->Maxx);
    }
    else if (match(args[2], "Maxy"))
    {
      if (argn > 3)
        p->Maxy = atoi(args[3]);

      sprintf(buf, "Maxy = %d\n", p->Maxy);
    }
    else if (match(args[2], "xpos"))
    {
      if (argn > 3)
        p->xpos = (double)atoi(args[3]);

      sprintf(buf, "xpos = %f\n", p->xpos);
    }
    else if (match(args[2], "ypos"))
    {
      if (argn > 3)
        p->ypos = (double)atoi(args[3]);

      sprintf(buf, "ypos = %f\n", p->ypos);
    }
    else if (match(args[2], "ships"))
    {
      if (argn > 3)
        p->ships = atoi(args[3]);

      sprintf(buf, "ships = %d\n", p->ships);
    }
    else if (match(args[2], "sectormappos"))
    {
      if (argn > 3)
        p->sectormappos = atoi(args[3]);

      sprintf(buf, "sectormappos = %d\n", p->sectormappos);
    }
    else if (match(args[2], "rtemp"))
    {
      if (argn > 3)
        p->conditions[RTEMP] = atoi(args[3]);

      sprintf(buf, "RTEMP = %d\n", p->conditions[RTEMP]);
    }
    else if (match(args[2], "temperature"))
    {
      if (argn > 3)
        p->conditions[TEMP] = atoi(args[3]);

      sprintf(buf, "TEMP = %d\n", p->conditions[TEMP]);
    }
    else if (match(args[2], "methane"))
    {
      if (argn > 3)
        p->conditions[METHANE] = atoi(args[3]);

      sprintf(buf, "METHANE = %d\n", p->conditions[METHANE]);
    }
    else if (match(args[2], "oxygen"))
    {
      if (argn > 3)
        p->conditions[OXYGEN] = atoi(args[3]);

      sprintf(buf, "OXYGEN = %d\n", p->conditions[OXYGEN]);
    }
    else if (match(args[2], "co2"))
    {
      if (argn > 3)
        p->conditions[CO2] = atoi(args[3]);

      sprintf(buf, "CO2 = %d\n", p->conditions[CO2]);
    }
    else if (match(args[2], "hydrogen"))
    {
      if (argn > 3)
        p->conditions[HYDROGEN] = atoi(args[3]);

      sprintf(buf, "HYDROGEN = %d\n", p->conditions[HYDROGEN]);
    }
    else if (match(args[2], "nitrogen"))
    {
      if (argn > 3)
        p->conditions[NITROGEN] = atoi(args[3]);

      sprintf(buf, "NITROGEN = %d\n", p->conditions[NITROGEN]);
    }
    else if (match(args[2], "sulfur"))
    {
      if (argn > 3)
        p->conditions[SULFUR] = atoi(args[3]);

      sprintf(buf, "SULFUR = %d\n", p->conditions[SULFUR]);
    }
    else if (match(args[2], "helium"))
    {
      if (argn > 3)
        p->conditions[HELIUM] = atoi(args[3]);

      sprintf(buf, "HELIUM = %d\n", p->conditions[HELIUM]);
    }
    else if (match(args[2], "other"))
    {
      if (argn > 3)
        p->conditions[OTHER] = atoi(args[3]);

      sprintf(buf, "OTHER = %d\n", p->conditions[OTHER]);
    }
    else if (match(args[2], "toxic"))
    {
      if (argn > 3)
        p->conditions[TOXIC] = atoi(args[3]);

      sprintf(buf, "TOXIC = %d\n", p->conditions[TOXIC]);
    }
    else if (match(args[2], "population"))
    {
      if (argn > 3)
        p->popn = atoi(args[3]);

      sprintf(buf, "population = %ld\n", p->popn);
    }
    else
    {
      notify(Playernum, Governor, "No such option for 'fix planet'.\n");
      free((char *)p);
      return;
    }

    notify(Playernum, Governor, buf);
    if (argn > 3)
      putplanet(p, Dir[Playernum - 1][Governor].snum,
                Dir[Playernum - 1][Governor].pnum);

    free((char *)p);
    return;
  }
  else if (match(args[1], "ship"))
  {
    if (Dir[Playernum - 1][Governor].level != LEVEL_SHIP)
    {
      notify(Playernum, Governor,
             "Change scope to the ship you wish to fix.\n");
      return;
    }

    (void)getship(&s, Dir[Playernum - 1][Governor].shipno);

    if (match(args[2], "fuel"))
    {
      if (argn > 3)
        s->fuel = (double)atoi(args[3]);

      sprintf(buf, "fuel = %f\n", s->fuel);
    }
    else if (match(args[2], "max_fuel"))
    {
      if (argn > 3)
        s->max_fuel = atoi(args[3]);

      sprintf(buf, "fuel = %d\n", s->max_fuel);
    }
    else if (match(args[2], "destruct"))
    {
      if (argn > 3)
        s->destruct = atoi(args[3]);

      sprintf(buf, "destruct = %d\n", s->destruct);
    }
    else if (match(args[2], "max_destruct"))
    {
      if (argn > 3)
        s->max_destruct = atoi(args[3]);

      sprintf(buf, "max_destruct = %d\n", s->max_destruct);
    }
    else if (match(args[2], "resource"))
    {
      if (argn > 3)
        s->resource = atoi(args[3]);

      sprintf(buf, "resource = %d\n", s->resource);
    }
    else if (match(args[2], "max_resource"))
    {
      if (argn > 3)
        s->max_resource = atoi(args[3]);

      sprintf(buf, "max_resource = %d\n", s->max_resource);
    }
    else if (match(args[2], "damage"))
    {
      if (argn > 3)
        s->damage = atoi(args[3]);

      sprintf(buf, "damage = %d\n", s->damage);
    }
    else if (match(args[2], "alive"))
    {
      s->alive = 1;
      s->damage = 0;
      sprintf(buf, "%s resurrected\n", Ship(s));
    }
    else if (match(args[2], "dead"))
    {
      s->alive = 0;
      s->damage = 100;
      sprintf(buf, "%s destroyed\n", Ship(s));
    }
    else if (match(args[2], "owner"))
    {
      if (argn > 3)
        s->owner = atoi(args[3]);

      sprintf(buf, "owner = %d\n", s->owner);
    }
    else if (match(args[2], "ships"))
    {
      if (argn > 3)
        s->ships = atoi(args[3]);

      sprintf(buf, "ships = %d\n", s->ships);
    }
    else if (match(args[2], "nextship"))
    {
      if (argn > 3)
        s->nextship = atoi(args[3]);

      sprintf(buf, "nextship = %d\n", s->nextship);
    }
    else if (match(args[2], "popn"))
    {
      if (argn > 3)
        s->popn = atoi(args[3]);

      sprintf(buf, "popn = %d\n", s->popn);
    }
    else if (match(args[2], "troops"))
    {
      if (argn > 3)
        s->troops = atoi(args[3]);

      sprintf(buf, "troops = %d\n", s->troops);
    }
    else if (match(args[2], "hanger"))
    {
      if (argn > 3)
        s->hanger = atoi(args[3]);

      sprintf(buf, "hanger = %d\n", s->hanger);
    }
    else if (match(args[2], "primary"))
    {
      if (argn > 3)
        s->primary = atoi(args[3]);

      sprintf(buf, "primary = %d\n", s->primary);
    }
    else if (match(args[2], "secondary"))
    {
      if (argn > 3)
        s->secondary = atoi(args[3]);

      sprintf(buf, "secondary = %d\n", s->secondary);
    }
    else if (match(args[2], "armor"))
    {
      if (argn > 3)
        s->armor = atoi(args[3]);

      sprintf(buf, "armor = %d\n", s->armor);
    }
    else if (match(args[2], "tech"))
    {
      if (argn > 3)
        s->tech = atof(args[3]);

      sprintf(buf, "tech = %lf\n", s->tech);
    }
    else if (match(args[2], "whatdest"))
    {
      if (argn > 3)
        s->whatdest = atoi(args[3]);

      sprintf(buf, "whatdest = %d\n", s->whatdest);
    }
    else
    {
      notify(Playernum, Governor, "No such option for 'fix ship'.\n");
      free((char *)s);
      return;
    }

    notify(Playernum, Governor, buf);
    putship(s);
    free((char *)s);
    return;
  }
  else if (match(args[1], "star"))
  {
    if (Dir[Playernum - 1][Governor].level != LEVEL_STAR)
    {
      notify(Playernum, Governor, "Change scope to the star first.\n");
      return;
    }

    getstar(&Stars[Dir[Playernum - 1][Governor].snum],
            Dir[Playernum - 1][Governor].snum);

    if (match(args[2], "ships"))
    {
      if (argn > 3)
        Stars[Dir[Playernum - 1][Governor].snum]->ships = atoi(args[3]);

      sprintf(buf, "ships = %d\n",
              Stars[Dir[Playernum - 1][Governor].snum]->ships);
    }
    else if (match(args[2], "stab"))
    {
      if (argn > 3)
        Stars[Dir[Playernum - 1][Governor].snum]->stability = atoi(args[3]);

      sprintf(buf, "stability = %d\n",
              Stars[Dir[Playernum - 1][Governor].snum]->stability);
    }
    else if (match(args[2], "nova"))
    {
      if (argn > 3)
        Stars[Dir[Playernum - 1][Governor].snum]->nova_stage = atoi(args[3]);

      sprintf(buf, "nova_stage = %d\n",
              Stars[Dir[Playernum - 1][Governor].snum]->nova_stage);
    }
    else if (match(args[2], "temp"))
    {
      if (argn > 3)
        Stars[Dir[Playernum - 1][Governor].snum]->temperature = atoi(args[3]);

      sprintf(buf, "temperature = %d\n",
              Stars[Dir[Playernum - 1][Governor].snum]->temperature);
    }
    else if (match(args[2], "grav"))
    {
      if (argn > 3)
        Stars[Dir[Playernum - 1][Governor].snum]->gravity = atof(args[3]);

      sprintf(buf, "gravity = %lf\n",
              Stars[Dir[Playernum - 1][Governor].snum]->gravity);
    }
    else
    {
      notify(Playernum, Governor, "No such option for 'fix star'.\n");
      return;
    }

    notify(Playernum, Governor, buf);
    putstar(Stars[Dir[Playernum - 1][Governor].snum],
            Dir[Playernum - 1][Governor].snum);
    return;
  }
  else
  {
    notify(Playernum, Governor, "Fix what?\n");
  }
}

int
match(char *p, const char *q)
{
  return (!strncmp(p, q, strlen(p)));
}

/* Case insensitive version of match -mfw */
int
matchic(char *p, const char *q)
{
  return (!strncasecmp(p, q, strlen(p)));
}

void
DontOwnErr(int Playernum, int Governor, int shipno)
{
  sprintf(buf, "You don't own ship #%d.\n", shipno);
  notify(Playernum, Governor, buf);
}

int
enufAP(int Playernum, int Governor, unsigned int AP, int x)
{
  reg int         blah;

  if ((blah = (AP < x)))
  {
    sprintf(buf, "You don't have %d action points there.\n", x);
    notify(Playernum, Governor, buf);
  }
  return (!blah);
}

#ifdef CHAP_AUTH
int
Getracenum(char *racename, char *govname, int *racenum, int *govnum,
           char *client_hash, int which)
{
  reg int         i, j;
  char            server_hash[33];
  char            hashbuf[MAX_COMMAND_LEN];

  // Initialize server_hash
  for (i = 0; i < 33; i++)
    server_hash[i] = '\0';

  for (i = 1; i <= Num_races; i++)
  {
    if (!strcmp(racename, races[i - 1]->name))
    {
      *racenum = i;

      for (j = 0; j <= MAXGOVERNORS; j++)
      {
        if (*races[i - 1]->governor[j].name &&
            !strcmp(govname, races[i - 1]->governor[j].name))
        {
          *govnum = j;

          /* md5 check here */
          sprintf(hashbuf, "%s%s%s", races[i - 1]->password,
                  races[i - 1]->governor[j].password, des[which].key);

          MD5String(hashbuf, server_hash);

          /* Helpful debug output -mfw fprintf(stderr, "race_name: %s\n",
           * races[i -1]->name); fprintf(stderr, "race_pass: %s\n", races[i
           * -1]->password); fprintf(stderr, "gov_name: %s\n", races[i
           * -1]->governor[j].name); fprintf(stderr, "gov_pass: %s\n", races[i
           * -1]->governor[j].password); fprintf(stderr, "key: %s\n",
           * des[which].key); fprintf(stderr, "server_hash: %s\n",
           * server_hash); fprintf(stderr, "client_hash: %s\n", client_hash); */

          if (!strcmp(server_hash, client_hash))
          {
            return 1;
          }
        }
      }
    }
  }
  *racenum = *govnum = 0;
  return 0;
}

#else

int
Getracenum(char *racepass, char *govpass, int *racenum, int *govnum)
{
  reg int         i, j;

#if DEBUG
#endif

  for (i = 1; i <= Num_races; i++)
  {
    if (!strcmp(racepass, races[i - 1]->password))
    {
      *racenum = i;

      for (j = 0; j <= MAXGOVERNORS; j++)
      {
        if (*races[i - 1]->governor[j].password &&
            !strcmp(govpass, races[i - 1]->governor[j].password))
        {
          *govnum = j;
          return 1;
        }
      }
    }
  }
  *racenum = *govnum = 0;
  return 0;
}

#endif

/* returns player # from string containing that players name or #. */

int
GetPlayer(char *name)
{
  int             rnum;
  reg int         i;

  rnum = 0;

  if (isdigit((unsigned char)*name))
  {
    if ((rnum = atoi(name)) < 1 || rnum > Num_races)
      return 0;
    return rnum;
  }
  else
  {
    for (i = 1; i <= Num_races; i++)
      if (match(name, races[i - 1]->name))
        return i;
    return 0;
  }
}

void
allocateAPs(int Playernum, int Governor, int APcount)
{
  int             maxalloc;
  int             alloc;

  if (Dir[Playernum - 1][Governor].level == LEVEL_UNIV)
  {
    sprintf(buf,
            "Change scope to the system you which to transfer global APs to.\n");
    notify(Playernum, Governor, buf);
    return;
  }
  alloc = atoi(args[1]);
  if (alloc <= 0)
  {
    notify(Playernum, Governor,
           "You must specify a positive amount of APs to allocate.\n");
    return;
  }
  getsdata(&Sdata);
  maxalloc =
    MIN(Sdata.AP[Playernum - 1],
        LIMIT_APs - Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum -
                                                                 1]);
  if (alloc > maxalloc)
  {
    sprintf(buf, "Illegal value (%d) - maximum = %d\n", alloc, maxalloc);
    notify(Playernum, Governor, buf);
    return;
  }
  Sdata.AP[Playernum - 1] -= alloc;
  putsdata(&Sdata);
  getstar(&Stars[Dir[Playernum - 1][Governor].snum],
          Dir[Playernum - 1][Governor].snum);
  Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1] =
    MIN(LIMIT_APs,
        Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1] + alloc);
  putstar(Stars[Dir[Playernum - 1][Governor].snum],
          Dir[Playernum - 1][Governor].snum);
  sprintf(buf, "Allocated\n");
  notify(Playernum, Governor, buf);
}

void
deductAPs(int Playernum, int Governor, int n, int snum, int sdata)
{
  if (n)
  {

    if (!sdata)
    {
      getstar(&Stars[snum], snum);

      if (Stars[snum]->AP[Playernum - 1] >= n)
        Stars[snum]->AP[Playernum - 1] -= n;
      else
      {
        Stars[snum]->AP[Playernum - 1] = 0;
        sprintf(buf,
                "WHOA!  You cheater!  Oooohh!  OOOOH!\n  I'm tellllllllliiiiiiinnnnnnnnnggggggggg!!!!!!!\n");
        notify(Playernum, Governor, buf);
      }

      putstar(Stars[snum], snum);

      if (Dir[Playernum - 1][Governor].level != LEVEL_UNIV &&
          Dir[Playernum - 1][Governor].snum == snum)
      {
        /* fix the prompt */
        sprintf(Dir[Playernum - 1][Governor].prompt + 5, "%02d",
                Stars[snum]->AP[Playernum - 1]);
        Dir[Playernum - 1][Governor].prompt[7] = ']';   /* fix bracket (made *
                                                         * '\0' by sprintf) */
      }
    }
    else
    {
      getsdata(&Sdata);
      Sdata.AP[Playernum - 1] = MAX(0, Sdata.AP[Playernum - 1] - n);
      putsdata(&Sdata);

      if (Dir[Playernum - 1][Governor].level == LEVEL_UNIV)
      {
        sprintf(Dir[Playernum - 1][Governor].prompt + 2, "%02d",
                Sdata.AP[Playernum - 1]);
        Dir[Playernum - 1][Governor].prompt[3] = ']';
      }
    }
  }
}

/* lists all ships in current scope for debugging purposes */
void
list(int Playernum, int Governor)
{

  shiptype       *ship;
  planettype     *p;
  int             sh = -1;

  switch (Dir[Playernum - 1][Governor].level)
  {
    case LEVEL_UNIV:
      sh = Sdata.ships;
      break;
    case LEVEL_STAR:
      getstar(&Stars[Dir[Playernum - 1][Governor].snum],
              Dir[Playernum - 1][Governor].snum);
      sh = Stars[Dir[Playernum - 1][Governor].snum]->ships;
      break;
    case LEVEL_PLAN:
      getplanet(&p, Dir[Playernum - 1][Governor].snum,
                Dir[Playernum - 1][Governor].pnum);
      sh = p->ships;
      free((char *)p);
      break;
    case LEVEL_SHIP:
      sh = Dir[Playernum - 1][Governor].shipno;
      break;
  }

  while (sh)
  {
    if (getship(&ship, sh))
    {
      sprintf(buf, "%15s #%d '%s' (pl %d) -> #%d %s\n", Shipnames[ship->type],
              sh, ship->name, ship->owner, ship->nextship,
              ship->alive ? "" : "(dead)");
      notify(Playernum, Governor, buf);
      sh = nextship(ship);
      free((char *)ship);
    }
    else
    {
      sh = 0;
    }
  }

}

double
morale_factor(double x)
{
  return ((atan((double)x / 10000.) / 3.14159565) + .5);
}

#define FNAMESIZE 20
struct allocated
{
  char           *addr;
  char            fname[FNAMESIZE + 1];
  int             lineno;
};

void
no_permission(int Playernum, int Governor, const char *order, int level)
{
  char            rank[9];

  switch (level)
  {
    case LEADER:
      strcpy(rank, "leader");
      break;
    case GENERAL:
      strcpy(rank, "general");
      break;
    case CAPTAIN:
      strcpy(rank, "captain");
      break;
    case PRIVATE:
      strcpy(rank, "private");
      break;
    case NOVICE:
      strcpy(rank, "novice");
      break;
  }
  sprintf(buf, "The \"%s\" command requires a minimum level of %s to run.\n",
          order, rank);
  notify(Playernum, Governor, buf);
}

void
no_permission_thing(int Playernum, int Governor, const char *order, int level)
{
  char            rank[9];

  switch (level)
  {
    case LEADER:
      strcpy(rank, "leader");
      break;
    case GENERAL:
      strcpy(rank, "general");
      break;
    case CAPTAIN:
      strcpy(rank, "captain");
      break;
    case PRIVATE:
      strcpy(rank, "private");
      break;
    case NOVICE:
      strcpy(rank, "novice");
      break;
  }
  sprintf(buf, "The \"%s\" command requires a minimum level of %s,\n", order,
          rank);
  notify(Playernum, Governor, buf);
  sprintf(buf, "or control of that ship/star to run.\n");
  notify(Playernum, Governor, buf);
}

int
authorized(int Governor, shiptype * ship)
{
  /* return (!Governor || ship->governor == Governor); */
  /* return (ship->governor == Governor); */
  return ((ship->governor == Governor) ||
          ((races[(ship->owner) - 1]->governor[Governor].rank) <= GENERAL));
}

int
authorized_in_star(int Playernum, int Governor, startype * star)
{
  if (Governor && star->governor[Playernum - 1] != Governor)
    return (0);
  else
    return (1);
}

int
match2(char *a, const char *b, int n)
{
  return (!strncasecmp(a, b, strlen(a)) && (strlen(a) >= n));
}
