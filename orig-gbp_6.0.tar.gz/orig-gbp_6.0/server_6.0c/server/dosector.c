/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)dosector.c      1.6 11/5/93 "
 *
 * dosector.c
 * produce() -- produce, stuff like that, on a sector.
 * spread()  -- spread population around.
 * explore() -- mark sector and surrounding sectors as having been explored.
 
 $Header: /var/cvs/gbp/GB+/server/dosector.c,v 1.5 2007/07/06 17:30:26 gbp Exp $
 
 static char *ver = "@(#)       $RCSfile: dosector.c,v $ $Revision: 1.5 $";
 */

#include <math.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "power.h"
#include "races.h"
#include "ships.h"
#include "doturn.h"

extern int      Defensedata[];

/* produce stuff in sector */

void            produce(startype *, planettype *, sectortype *);
void            spread(planettype *, sectortype *, int, int);
void            Migrate2(planettype *, int, int, sectortype *, int *);
void            explore(planettype *, sectortype *, int, int, int);
void            plate(sectortype *);

#include "proto.h"

void
produce(startype * star, planettype * planet, sectortype * s)
{
  reg int         ss;
  reg int         maxsup;
  reg int         pfuel = 0, pdes = 0, pres = 0;
  reg struct plinfo *pinf;
  reg int         prod, diff;
  racetype       *Race;

  if (!s->owner)
    return;

  Race = races[s->owner - 1];

  if (s->resource && success(s->eff))
  {
    prod = round_rand(Race->metabolism) * int_rand(1, s->eff);
    prod = MIN(prod, s->resource);

    if (LIMITED_RESOURCES)
      s->resource -= prod;

    /* added this from treehouse -mfw */
    if (s->resource == 0)
      s->resource = TRICKLE_RESOURCES;

    pfuel = prod * (1 + (s->condition == GAS)) * FUEL_PROD_FACTOR;
    if (success((s->mobilization * DEST_PROD_FACTOR)))
      pdes = prod;
    else
      pres = prod;
    prod_fuel[s->owner - 1] += pfuel;
    prod_res[s->owner - 1] += pres;
    prod_destruct[s->owner - 1] += pdes;
  }
  /* try to find crystals */
  /* chance of digging out a crystal depends on efficiency */
  if (s->crystals && Crystal(Race) && success(s->eff))
  {
    prod_crystals[s->owner - 1]++;
    s->crystals--;
  }
  pinf = &planet->info[s->owner - 1];

  /* increase mobilization to planetary quota */
  if (s->mobilization < pinf->mob_set)
  {
    /* HUTm (kse) civilians are needed to rise mob */
    if (s->popn)
      if (pinf->resource + prod_res[s->owner - 1] > 0)
      {
        s->mobilization++;
        prod_res[s->owner - 1] -= round_rand(MOB_COST);
        prod_mob++;
      }
  }
  else if (s->mobilization > pinf->mob_set)
  {
    s->mobilization--;
    prod_mob--;
  }
  avg_mob[s->owner - 1] += s->mobilization;

  /* do efficiency */
  if (s->eff < 100)
  {
    /* HUTm (kse) civilians are needed to rise eff */
    if (s->popn)
    {
      reg int         chance;

      chance =
        round_rand((100.0 -
                    (double)planet->info[s->owner -
                                         1].tax) * Race->likes[s->condition]);
      if (success(chance))
      {
        s->eff += round_rand(Race->metabolism);
        if (s->eff >= 100)
          plate(s);
      }
    }
  }
  else
    plate(s);

  if ((s->condition != WASTED) && Race->fertilize && (s->fert < 100))
    s->fert += (int_rand(0, 100) < Race->fertilize);
  if (s->fert > 100)
    s->fert = 100;

  if (s->condition == WASTED && success(NATURAL_REPAIR))
    s->condition = s->type;

  maxsup = maxsupport(Race, s, Compat[s->owner - 1], planet->conditions[TOXIC]);
  if ((diff = s->popn - maxsup) < 0)
  {
    if (s->popn >= Race->number_sexes)
      ss = round_rand(-(double)diff * Race->birthrate);
    else
      ss = 0;
  }
  else
    ss = -int_rand(0, MIN(2 * diff, s->popn));

#ifdef NOMADS
  if (ss < 0 && s->popn == Race->number_sexes)
    ss = 0;
#endif

  s->popn += ss;

  if (s->troops)
#ifdef COLLECTIVE_MONEY
    Race->governor[0].maintain
#else
    Race->governor[(unsigned)star->governor[s->owner - 1]].maintain
#endif
      += UPDATE_TROOP_COST * s->troops;
  else if (!s->popn)
    s->owner = 0;
}

int             x_adj[] = { -1, 0, 1, -1, 1, -1, 0, 1 };
int             y_adj[] = { 1, 1, 1, 0, 0, -1, -1, -1 };

void
spread(reg planettype * pl, reg sectortype * s, reg int x, reg int y)
{
  int             people;
  reg int         x2, y2, j;
  reg int         check;
  racetype       *Race;

  if (!s->owner)
    return;
  if (pl->sheep || (pl->slaved_to && pl->slaved_to != s->owner))
    return;                     /* no one wants to go anywhere */

  Race = races[s->owner - 1];

  /* New code by Kharush. More power to adventurism. At least race's number of
   * sexes moves -> no need to hunt sectors that have too few people. 120
   * instead of 100 balances adventurism between dese/fore races. */

  /* Code cleared by Gardan 4.3.97. Comments cleared by Kharush 10.3.97 Next
   * version would have an adjustable parameter for adventurism, that is, how
   * powerful adverturism's effect is. */

  /* Old code returned to effect since new code works funny Gardan 4.6.97 */

  /* new code starts */
  /* 
   * 
   * if(double_rand() < (double) (Race->adventurism * (120.0 - (double)
   * s->fert) / 120.0)) { if(s->popn >= 2 * Race->number_sexes) { people =
   * s->popn - Race->number_sexes; j = int_rand(0, 7); x2 = x_adj[j]; y2 =
   * y_adj[j]; Migrate2(pl, x + x2, y + y2, s, &people); } } */
  /* new code ends */

  /* old code */
  if (s->popn >= 2 * Race->number_sexes)
  {
    /* the higher the fertility, the less people like to leave */
    people =
      round_rand((double)Race->adventurism * (double)s->popn *
                 (100. - (double)s->fert) / 100.) - Race->number_sexes;
    /* how many people want to move - one family stays behind */

    check = round_rand(6.0 * Race->adventurism);        /* more rounds for high
                                                         * advent */

    while (people > 0 && check)
    {
      j = int_rand(0, 7);
      x2 = x_adj[j];
      y2 = y_adj[j];
      Migrate2(pl, x + x2, y + y2, s, &people);
      check--;
    }
  }
  /* end of old code */
}

void
Migrate2(planettype * planet, reg int xd, reg int yd, sectortype * ps,
         int *people)
{
  reg sectortype *pd;
  reg int         move;

  /* attempt to migrate beyond screen, or too many people */
  if (yd > planet->Maxy - 1 || yd < 0)
    return;

  if (xd < 0)
    xd = planet->Maxx - 1;
  else if (xd > planet->Maxx - 1)
    xd = 0;

  pd = &Sector(*planet, xd, yd);

  if (!pd->owner)
  {

    /* New code by Kharush. Planet's compability's effect to adventurism is
     * removed. Also some other changes.  */
    /* 
     * if(double_rand() > (double) races[ps->owner - 1]->likes[ps->condition])
     * return; *//* No adventurism to unsuitable sectors. */

    move =
      (int)((double)(*people) * races[ps->owner - 1]->likes[pd->condition]);

    /* old code move = (int) ((double) (*people) * Compat[ps->owner - 1] *
     * races[ps->owner - 1]->likes[pd->condition] / 100.0); */

    if (!move)
      return;

    /* New code next three rows. */
    pd->popn += races[ps->owner - 1]->number_sexes;
    ps->popn -= races[ps->owner - 1]->number_sexes;
    *people -= races[ps->owner - 1]->number_sexes;

    /* old code people -= move; pd->popn += move; ps->popn -= move; */

    pd->owner = ps->owner;
    tot_captured++;
    Claims = 1;
  }
}

/* 
 * mark sectors on the planet as having been "explored." for sea exploration
 * on earthtype planets.
 */

void
explore(reg planettype * planet, reg sectortype * s, reg int x, reg int y,
        reg int p)
{
  reg int         d;

  /* explore sectors surrounding sectors currently explored. */
  if (Sectinfo[x][y].explored)
  {
    Sectinfo[mod(x - 1, planet->Maxx, d)][y].explored = p;
    Sectinfo[mod(x + 1, planet->Maxx, d)][y].explored = p;
    if (y == 0)
    {
      Sectinfo[x][1].explored = p;
    }
    else if (y == planet->Maxy - 1)
    {
      Sectinfo[x][y - 1].explored = p;
    }
    else
    {
      Sectinfo[x][y - 1].explored = Sectinfo[x][y + 1].explored = p;
    }

  }
  else if (s->owner == p)
    Sectinfo[x][y].explored = p;

}

void
plate(sectortype * s)
{
  s->eff = 100;
  if (s->condition != GAS)
    s->condition = PLATED;
}
