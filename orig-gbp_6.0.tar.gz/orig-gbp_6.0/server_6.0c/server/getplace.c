/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)getplace.c      1.9 11/5/93 "
 * 
 * Getplace -- returns directory level from string and current Dir
 * Dispplace -- returns string from directory level
 * testship(ship) -- tests various things for the ship.
 *
 * $Header: /var/cvs/gbp/GB+/server/getplace.c,v 1.3 2007/07/06 17:30:26 gbp Exp $
 
 static char *ver = "@(#)       $RCSfile: getplace.c,v $ $Revision: 1.3 $";
 */

#include <ctype.h>
#include <strings.h>
#include <string.h>
#include <stdlib.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "races.h"
#include "ships.h"
#include "power.h"
#include "buffers.h"

char            Disps[PLACENAMESIZE];
char           *Dispshiploc_brief(shiptype *);
char           *Dispshiploc(shiptype *);
int             testship(int, int, shiptype *);

#include "proto.h"

placetype                       /* ignore explored */
Getplace(int Playernum, int Governor, const char *string, int ignoreexpl)
{
  placetype       where;        /* return value */
  racetype       *Race;
  int             God;
  int             scnt, star, plan;
  planettype     *pl;

  Bzero(where);

  Race = races[Playernum - 1];
  God = Race->God;

  where.err = 0;

  /* handy 'cs next' command to go to the next colony -mfw */
  if (!strcmp(string, "next"))
  {
    star = Dir[Playernum - 1][Governor].snum;
    plan = Dir[Playernum - 1][Governor].pnum + 1;

    for (scnt = 0; scnt <= Sdata.numstars; star++, scnt++)
    {
      if (star == Sdata.numstars)
      {
        /* hop back to the beggining of the star list */
        star = -1;
        scnt--;
        continue;
      }

      getstar(&(Stars[star]), star);

      if (!isset(Stars[star]->explored, Playernum))
        continue;

      for (; plan < Stars[star]->numplanets; plan++)
      {
        getplanet(&pl, star, plan);

        if (pl->info[Playernum - 1].explored &&
            pl->info[Playernum - 1].numsectsowned && (!Governor ||
                                                      Stars[star]->
                                                      governor[Playernum - 1] ==
                                                      Governor ||
                                                      Race->governor[Governor].
                                                      rank == GENERAL))
        {
          where.level = LEVEL_PLAN;
          where.snum = star;
          where.pnum = plan;
          where.shipno = 0;
          return where;
        }
      }
      plan = 0;
    }
  }

  if (!strcmp(string, "prev"))
  {
    star = Dir[Playernum - 1][Governor].snum;
    plan = Dir[Playernum - 1][Governor].pnum - 1;

    for (scnt = 0; scnt <= Sdata.numstars; star--, scnt++)
    {
      if (star == -1)
      {
        /* hop to the end of the star list */
        star = Sdata.numstars;
        scnt--;
        continue;
      }

      getstar(&(Stars[star]), star);

      if (!isset(Stars[star]->explored, Playernum))
        continue;

      for (; plan >= 0; plan--)
      {
        getplanet(&pl, star, plan);

        if (pl->info[Playernum - 1].explored &&
            pl->info[Playernum - 1].numsectsowned && (!Governor ||
                                                      Stars[star]->
                                                      governor[Playernum - 1] ==
                                                      Governor ||
                                                      Race->governor[Governor].
                                                      rank == GENERAL))
        {
          where.level = LEVEL_PLAN;
          where.snum = star;
          where.pnum = plan;
          where.shipno = 0;
          return where;
        }
      }
      plan = Stars[star]->numplanets;
    }
  }

  switch (*string)
  {
    case '/':
      where.level = LEVEL_UNIV; /* scope = root (universe) */
      where.snum = 0;
      where.pnum = where.shipno = 0;
      return (Getplace2
              (Playernum, Governor, string + 1, &where, ignoreexpl, God));
    case '#':
      sscanf(++string, "%hd", &where.shipno);
      if (!getship(&where.shipptr, where.shipno))
      {
        DontOwnErr(Playernum, Governor, where.shipno);
        where.err = 1;
        return where;
      }
      if ((where.shipptr->owner == Playernum || ignoreexpl || God) &&
          (where.shipptr->alive || God))
      {
        where.level = LEVEL_SHIP;
        where.snum = where.shipptr->storbits;
        where.pnum = where.shipptr->pnumorbits;
        if (!where.shipptr->alive)
          notify(Playernum, Governor, "NOTICE: Ship is flagged as dead.\n");
        free((char *)where.shipptr);
        return where;
      }
      else
      {
        where.err = 1;
        free((char *)where.shipptr);
        return where;
      }
    case '-':
      /* no destination */
      where.level = LEVEL_UNIV;
      return where;
    default:
      /* copy current scope to scope */
      where.level = Dir[Playernum - 1][Governor].level;
      where.snum = Dir[Playernum - 1][Governor].snum;
      where.pnum = Dir[Playernum - 1][Governor].pnum;
      if (where.level == LEVEL_SHIP)
        where.shipno = Dir[Playernum - 1][Governor].shipno;
      if (*string == CHAR_CURR_SCOPE)
        return where;
      else
        return Getplace2(Playernum, Governor, string, &where, ignoreexpl, God);
  }
}

placetype
Getplace2(int Playernum, int Governor, const char *string, placetype * where,
          int ignoreexpl, int God)
{
  char            substr[NAMESIZE];
  planettype     *p;
  register unsigned int l;
  int             tick, i;

  if (where->err || *string == '\0' || *string == '\n')
  {
    /* base cases */
    return (*where);
  }
  else if (*string == '.')
  {
    if (where->level == LEVEL_UNIV)
    {
      sprintf(buf, "Can't go higher.\n");
      notify(Playernum, Governor, buf);
      where->err = 1;
      return (*where);
    }
    else
    {
      if (where->level == LEVEL_SHIP)
      {
        (void)getship(&where->shipptr, where->shipno);
        where->level = where->shipptr->whatorbits;

        /* Fix 'cs .' for ships within ships. Maarten */
        if (where->level == LEVEL_SHIP)
        {
          where->shipno = where->shipptr->destshipno;
        }

        free((char *)where->shipptr);
      }
      else
      {
        where->level--;
      }

      while (*string == '.')
        string++;

      while (*string == '/')
        string++;

      return (Getplace2(Playernum, Governor, string, where, ignoreexpl, God));
    }
  }
  else
  {
    while (*string == '/')
      string++;

    strcpy(substr, "");

    /* is a char string, name of something */
    sscanf(string, "%[^/ \n]", substr);

    do
    {
      /* 
       * if (isupper(*string) ) (*string) =
       * tolower(*string);
       */
      string++;
    }
    while (*string != '/' && *string != '\n' && *string != '\0');

    l = strlen(substr);

    if (where->level == LEVEL_UNIV)
    {
      for (i = 0; i < Sdata.numstars; i++)
      {
        if (l &&
            ((!strncmp(substr, Stars[i]->name, l)) || atoi(substr) == i + 1))
        {
          where->level = LEVEL_STAR;
          where->snum = i;

          if (ignoreexpl || isset(Stars[where->snum]->explored, Playernum) ||
              God)
          {
            tick = (*string == '/');
            return (Getplace2
                    (Playernum, Governor, string + tick, where, ignoreexpl,
                     God));
          }

          sprintf(buf, "You have not explored %s yet.\n",
                  Stars[where->snum]->name);
          notify(Playernum, Governor, buf);
          where->err = 1;
          return (*where);
        }
      }

      if (i >= Sdata.numstars)
      {
        sprintf(buf, "No such star %s.\n", substr);
        notify(Playernum, Governor, buf);
        where->err = 1;
        return (*where);
      }
    }
    else if (where->level == LEVEL_STAR)
    {
      for (i = 0; i < Stars[where->snum]->numplanets; i++)
        if ((!strncmp(substr, Stars[where->snum]->pnames[i], l)) || atoi(substr) == i + 1)      /* JPD 
                                                                                                 * && 
                                                                                                 * SKF 
                                                                                                 */
        {
          where->level = LEVEL_PLAN;
          where->pnum = i;
          getplanet(&p, (int)where->snum, i);
          if (ignoreexpl || p->info[Playernum - 1].explored || God)
          {
            free((char *)p);
            tick = (*string == '/');
            return (Getplace2
                    (Playernum, Governor, string + tick, where, ignoreexpl,
                     God));
          }
          sprintf(buf, "You have not explored %s yet.\n",
                  Stars[where->snum]->pnames[i]);
          notify(Playernum, Governor, buf);
          where->err = 1;
          free((char *)p);
          return (*where);
        }
      if (i >= Stars[where->snum]->numplanets)
      {
        if (isset(Stars[where->snum]->explored, Playernum))
        {
          sprintf(buf, "No such planet %s.\n", substr);
          notify(Playernum, Governor, buf);
        }
        where->err = 1;
        return (*where);
      }
    }
    else
    {
      sprintf(buf, "Can't descend to %s.\n", substr);
      notify(Playernum, Governor, buf);
      where->err = 1;
      return (*where);
    }
  }

  return (*where);
}

char           *
Dispshiploc_brief(shiptype * ship)
{
  int             i;

  memset(Disps, 0, sizeof (Disps));
  switch (ship->whatorbits)
  {
    case LEVEL_STAR:
      sprintf(Disps, "/%-4.4s", Stars[ship->storbits]->name);
      return (Disps);
    case LEVEL_PLAN:
      sprintf(Disps, "/%s", Stars[ship->storbits]->name);
      for (i = 2; (Disps[i] && (i < 5)); i++) ;
      sprintf(Disps + i, "/%-4.4s",
              Stars[ship->storbits]->pnames[ship->pnumorbits]);
      return (Disps);
    case LEVEL_SHIP:
      sprintf(Disps, "#%d", ship->destshipno);
      return (Disps);
    case LEVEL_UNIV:
      strcat(Disps, "/");
      return (Disps);
    default:
      strcat(Disps, "error");
      return (Disps);
  }
}

char           *
Dispshiploc(shiptype * ship)
{

  memset(Disps, 0, sizeof (Disps));
  switch (ship->whatorbits)
  {
    case LEVEL_STAR:
      sprintf(Disps, "/%s", Stars[ship->storbits]->name);
      return (Disps);
    case LEVEL_PLAN:
      sprintf(Disps, "/%s/%s", Stars[ship->storbits]->name,
              Stars[ship->storbits]->pnames[ship->pnumorbits]);
      return (Disps);
    case LEVEL_SHIP:
      sprintf(Disps, "#%d", ship->destshipno);
      return (Disps);
    case LEVEL_UNIV:
      sprintf(Disps, "/");
      return (Disps);
    default:
      sprintf(Disps, "error");
      return (Disps);
  }
}

const char     *
Dispplace(int Playernum, int Governor, placetype * where)
{

  memset(Disps, 0, sizeof (Disps));
  switch (where->level)
  {
    case LEVEL_STAR:
      sprintf(Disps, "/%s", Stars[where->snum]->name);
      return (Disps);
    case LEVEL_PLAN:
      sprintf(Disps, "/%s/%s", Stars[where->snum]->name,
              Stars[where->snum]->pnames[where->pnum]);
      return (Disps);
    case LEVEL_SHIP:
      sprintf(Disps, "#%d", where->shipno);
      return (Disps);
    case LEVEL_UNIV:
      return ("/");
    default:
      sprintf(buf, "illegal Dispplace val = %d\n", where->level);
      notify(Playernum, Governor, buf);
      where->err = 1;
      return ("/");
  }
}

int
testship(int Playernum, int Governor, shiptype * s)
{
  reg int         r;

  r = 0;

  if (!s->alive)
  {
    sprintf(buf, "%s has been destroyed.\n", Ship(s));
    notify(Playernum, Governor, buf);
    r = 1;
  }
  else if (s->owner != Playernum)       /* || !authorized(Governor, s)) */
  {
    DontOwnErr(Playernum, Governor, (int)s->number);
    r = 1;
  }
  else if (!s->active)
  {
    sprintf(buf, "%s is irradiated %d%% and inactive.\n", Ship(s), s->rad);
    notify(Playernum, Governor, buf);
    r = 1;
  }
  return r;
}

const char     *
Dispplace_brief(int Playernum, int Governor, placetype * where)
{

  memset(Disps, 0, sizeof (Disps));
  switch (where->level)
  {
    case LEVEL_STAR:
      sprintf(Disps, "/%4.4s", Stars[where->snum]->name);
      return (Disps);
    case LEVEL_PLAN:
      sprintf(Disps, "/%4.4s/%-4.4s", Stars[where->snum]->name,
              Stars[where->snum]->pnames[where->pnum]);
      return (Disps);
    case LEVEL_SHIP:
      sprintf(Disps, "#%d", where->shipno);
      return (Disps);
    case LEVEL_UNIV:
      return ("/");
    default:
      sprintf(buf, "illegal Dispplace val = %d\n", where->level);
      notify(Playernum, Governor, buf);
      where->err = 1;
      return ("/");
  }
}
