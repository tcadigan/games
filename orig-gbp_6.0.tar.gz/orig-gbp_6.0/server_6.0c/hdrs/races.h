/*
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)races.h 1.9 11/5/93 "
 *
 $Header: /var/cvs/gbp/GB+/hdrs/races.h,v 1.3 2007/07/06 16:55:26 gbp Exp $
 */

typedef struct
{
  char            invisible;
  char            standby;
  char            color;        /* 1 if you are using a color client */
  char            double_digits;
  char            inverse;
  char            geography;
  char            autoload;
  char            gag;
  char            highlight;    /* which race to highlight */
  char            compat;
  // char autopurge Add this in for next run
} toggletype;

struct race
{
  int             Playernum;
  char            name[RNAMESIZE];      /* Racial name. */
  char            password[RNAMESIZE];
  char            info[PERSONALSIZE];   /* personal information */
  char            motto[MOTTOSIZE];     /* for a cute message */
  unsigned char   absorb;       /* Does this race absorb enemies in combat? */
  unsigned char   collective_iq;        /* Does this race have collective IQ? */
  unsigned char   pods;         /* Can this race use pods? */
  unsigned char   fighters;     /* Fight rating of this race. */
  unsigned char   IQ;
  unsigned char   IQ_limit;     /* Asymtotic IQ for collective IQ races. */
  unsigned char   number_sexes;
  unsigned char   fertilize;    /* Chance that this race will increase the
                                 * fertility of its sectors by 1 each update */
  double          adventurism;
  double          birthrate;
  double          mass;
  double          metabolism;
  double          likes[WASTED + 1];    /* Sector condition compats. */
  short           conditions[OTHER + 1];        /* Atmosphere/temperature this
                                                 * race likes. */
  unsigned char   likesbest;    /* 100% compat sector condition for this race. */

  char            dissolved;    /* Player has quit. */
  char            God;          /* Player is a God race. */
  char            Guest;        /* Player is a guest race. */
  char            Metamorph;    /* Player is a morph; (for printing). */
  char            monitor;      /* God is monitering this race. */

  char            translate[MAXPLAYERS];        /* translation mod for each
                                                 * player */

  unsigned long   atwar[2];     /* war 64 bits */
  unsigned long   allied[2];    /* allies 64 bits */
  long            morale;       /* race's morale level */

  unsigned int    points[MAXPLAYERS];   /* keep track of war status against
                                         * another player - for short reports */
  unsigned short  Gov_ship;     /* Shipnumber of government ship. */
  unsigned short  controlled_planets;   /* Number of planets under control. */
  unsigned short  victory_turns;
  unsigned short  turn;

  double          tech;
  unsigned char   discoveries[80];      /* Tech discoveries. */
  unsigned long   victory_score;        /* Number of victory points. */
  unsigned long   votes;
  unsigned long   planet_points;        /* For the determination of global APs */

  char            governors;
  struct gov
  {
    char            name[RNAMESIZE];
    char            password[RNAMESIZE];
    unsigned char   rank;
    unsigned char   active;
    unsigned char   deflevel;
    unsigned char   defsystem;
    unsigned char   defplanetnum;       /* current default */
    unsigned char   homelevel;
    unsigned char   homesystem;
    unsigned char   homeplanetnum;      /* home place */
    unsigned long   newspos[4]; /* news file pointers */
    toggletype      toggle;
    unsigned long   money;
    unsigned long   income;
    unsigned long   maintain;
    unsigned long   cost_tech;
    unsigned long   cost_market;
    unsigned long   profit_market;
    unsigned long   channel[2]; /* the channel we are communicating on */
    time_t          last_login; /* last login for this governor */
    char            last_ip[16];
    struct
    {
      unsigned        csp_user:1;
      unsigned        empty:7;
      unsigned int    csp_client_vers;
    } CSP_client_info;
  } governor[MAXGOVERNORS + 1];

  struct flt
  {                             /* Fleet Struct -mfw */
    char            name[FLEET_NAMESIZE + 1];   /* Name of this fleet */
    unsigned short  flagship;   /* first ship in the fleet list */
    unsigned short  admiral;    /* gov in control of this fleet */
  } fleet[MAXFLEETS + 1];
};

/* vote bits: */
#define	VOTE_UPDATE_GO	0x01    /* On - Go, Off - Wait */

/* special discoveries */
#define D_HYPER_DRIVE	  0     /* hyper-space capable */
#define D_LASER		  1     /* can construct/operate combat lasers */
#define D_CEW		  2     /* can construct/operate cews */
#ifdef USE_VN
#define D_VN            3       /* can construct Von Neumann machines */
#endif
#define D_TRACTOR_BEAM    4     /* tractor/repulsor beam */
#define D_TRANSPORTER     5     /* tractor beam (local) */
#define D_AVPM	          6     /* AVPM transporter */
#define D_CLOAK	          7     /* cloaking device */
#define D_WORMHOLE        8     /* worm-hole */
#define D_CRYSTAL	  9     /* crystal power */
#define D_ATMOS    10           /* atmospheric processor */

#define Hyper_drive(r) 	((r)->discoveries[D_HYPER_DRIVE])
#define Crystal(r)	((r)->discoveries[D_CRYSTAL])
#define Atmos(r)        ((r)->discoveries[D_ATMOS])
#define Laser(r)	((r)->discoveries[D_LASER])
#define Wormhole(r)	((r)->discoveries[D_WORMHOLE])
#ifdef USE_VN
#define Vn(r)		((r)->discoveries[D_VN])
#else
#define Vn(r)		(0)
#endif
#define Cew(r)		((r)->discoveries[D_CEW])
#define Cloak(r)	((r)->discoveries[D_CLOAK])
#define Avpm(r)		((r)->discoveries[D_AVPM])
#define Tractor_beam(r)	((r)->discoveries[D_TRACTOR_BEAM])
#define Transporter(r)	((r)->discoveries[D_TRANSPORTER])

#define TECH_ATMOS              80.0
#define TECH_HYPER_DRIVE	50.0
#define TECH_LASER	       100.0
#define TECH_CEW	       150.0
#ifdef USE_VN
#define TECH_VN       120.0
#endif
#define TECH_TRACTOR_BEAM      999.0
#define TECH_TRANSPORTER       999.0
#define TECH_AVPM	       200.0    /* was 250:Changed by Gardan 20.12.1996 
                                         */
#define TECH_CLOAK	       170.0
#define TECH_WORMHOLE	       100.0
#define TECH_CRYSTAL		80.0    /* was 50:Changed by Gardan 20.12.1996 */

struct block
{
  int             Playernum;
  char            name[RNAMESIZE];
  char            motto[MOTTOSIZE];
  unsigned long   invite[2];
  unsigned long   pledge[2];
  unsigned long   atwar[2];
  unsigned long   allied[2];
  unsigned short  next;
  unsigned short  systems_owned;
  unsigned long   VPs;
  unsigned long   money;

  unsigned long   dummy[2];
};

struct power_blocks
{
  char            time[128];
  unsigned long   members[MAXPLAYERS];
  unsigned long   troops[MAXPLAYERS];   /* total troops */
  unsigned long   popn[MAXPLAYERS];     /* total population */
  unsigned long   resource[MAXPLAYERS]; /* total resource in stock */
  unsigned long   fuel[MAXPLAYERS];
  unsigned long   destruct[MAXPLAYERS]; /* total dest in stock */
  unsigned short  ships_owned[MAXPLAYERS];      /* # of ships owned */
  unsigned short  systems_owned[MAXPLAYERS];
  unsigned long   sectors_owned[MAXPLAYERS];
  unsigned long   money[MAXPLAYERS];
  unsigned short  VPs[MAXPLAYERS];
  unsigned long   planets_owned[MAXPLAYERS];
};

typedef struct race racetype;
typedef struct block blocktype;
EXTERN struct block Blocks[MAXPLAYERS];
EXTERN struct power_blocks Power_blocks;

EXTERN racetype *races[MAXPLAYERS];
