/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)csp_map.c       1.2 12/3/93 "
 * 
 * CSP_MAP Copyright (c) 1993 GBDT, John P. Deragon
 * Portions copyright Robert Chansky
 * 
 * $Header: /var/cvs/gbp/GB+/user/csp_map.c,v 1.4 2007/07/06 18:09:34 gbp Exp $
 */

#include <stdlib.h>
#include <string.h>
#include <curses.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"
#include "csp.h"
#include "csp_types.h"
#include "proto.h"

static racetype *Race;
extern char    *Planet_types[];

int             getowner(planettype *, int, int);
char            getsymbol(planettype *, int, int, racetype *, int);
int             gettype(planettype *, int, int);

void
CSP_map(int Playernum, int Governor, int snum, int pnum, planettype * p)
{
  register int    i, y, x;
  int             sh, iq;
  shiptype       *s;
  int             shiplocs[MAX_X][MAX_Y];

  Race = races[Playernum - 1];
  if (!getsmap(Smap, p))
  {
    notify(Playernum, Governor, "MAP Aborted: Error in getsmap\n");
    loginfo(ERRORLOG, WANTERRNO, "CSP_map(): Error in getsmap\n");
    return;
  }

  iq = !!p->info[Playernum - 1].numsectsowned;
  sh = p->ships;

  memset(shiplocs, 0, sizeof (shiplocs));

  while (sh)
  {
    if (!getship(&s, sh))
    {
      sh = 0;
      continue;
    }
    if (s->owner == Playernum && authorized(Governor, s) &&
        (s->popn || (s->type == OTYPE_PROBE)))
      iq = 1;
    if (s->alive && landed(s))
      shiplocs[s->land_x][s->land_y] = Shipltrs[s->type];

    sh = nextship(s);
    free((char *)s);
  }

  /* > t CSP_INTRO Star# StarName Plan# PlanName Comp Tox Ens X Y Geo Inv DD s */
  /* > t CSP_INTRO %d %s %d %s %d %d %d %d %d %d %d %d */

  sprintf(buf, "%c %d %d %s %d %s %f %d %d %d %d %d %d %d %d\n", CSP_CLIENT,
          CSP_MAP_INTRO, snum + 1, Stars[snum]->name, pnum + 1,
          Stars[snum]->pnames[pnum], compatibility(p, Race),
          p->conditions[TOXIC], p->slaved_to ? p->slaved_to : 0, p->Maxx,
          p->Maxy, Race->governor[Governor].toggle.geography,
          Race->governor[Governor].toggle.inverse,
          Race->governor[Governor].toggle.double_digits,
          Race->governor[Governor].toggle.color);
  notify(Playernum, Governor, buf);

  /* > t CSP_DYNAMIC1 Type Sects Guns MobPoints Res Des Fuel Xtals */
  /* > t CSP_DYNAMIC1 %d %d %d %d %d %d %d %d */
  /* > t CSP_DYNAMIC2 Mob AMob Pop ^Pop TPop Mil TMil Tax ATax Dep EstPro */
  /* > t CSP_DYNAMIC2 %d %d %d %d %d %d %d %f %f %d %f */
  /* > t CSP_ALIENS ALIEN1 ALIEN2 .. ALIENn */
  /* > t CSP_ALIENS %s */

  sprintf(buf, "%c %d %d %d %d %ld %d %d %d %d\n", CSP_CLIENT,
          CSP_MAP_DYNAMIC_1, p->type, p->info[Playernum - 1].numsectsowned,
          p->info[Playernum - 1].guns, p->info[Playernum - 1].mob_points,
          p->info[Playernum - 1].resource, p->info[Playernum - 1].destruct,
          p->info[Playernum - 1].fuel, p->info[Playernum - 1].crystals);
  notify(Playernum, Governor, buf);

  sprintf(buf, "%c %d %d %d %ld %ld %d %ld %ld %d %d %ld %d\n", CSP_CLIENT,
          CSP_MAP_DYNAMIC_2, p->info[Playernum - 1].mob_set,
          p->info[Playernum - 1].comread, p->info[Playernum - 1].popn, p->popn,
          round_rand(.01 * (100. - p->conditions[TOXIC]) * p->maxpopn),
          p->info[Playernum - 1].troops, p->troops,
          (int)p->info[Playernum - 1].tax, (int)p->info[Playernum - 1].newtax,
          p->total_resources, (int)p->info[Playernum - 1].est_production);
  notify(Playernum, Governor, buf);

  sprintf(buf, "%c %d ", CSP_CLIENT, CSP_MAP_ALIENS);
  if (p->explored || Race->tech >= TECH_EXPLORE)
  {
    for (i = 1; i < MAXPLAYERS; i++)
      if (p->info[i - 1].numsectsowned && i != Playernum)
      {
        sprintf(temp, "%d ", i);
        strcat(buf, temp);
      }
    strcat(buf, "\n");
  }
  else
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_MAP_ALIENS, FALSE);
  notify(Playernum, Governor, buf);

  for (y = 0; y < p->Maxy; y++)
  {
    sprintf(buf, "%c %d ", CSP_CLIENT, CSP_MAP_DATA);
    notify(Playernum, Governor, buf);
    for (x = 0; x < p->Maxx; x++)
    {
      if (shiplocs[x][y] && iq)
        sprintf(buf, "%d%c%d;", gettype(p, x, y), shiplocs[x][y],
                getowner(p, x, y));
      else
      {
        sprintf(buf, "%d%c%d;", gettype(p, x, y),
                getsymbol(p, x, y, Race, Playernum), getowner(p, x, y));
      }
      notify(Playernum, Governor, buf);
    }
    notify(Playernum, Governor, "\n");
  }

  sprintf(buf, "%c %d\n", CSP_CLIENT, CSP_MAP_END);
  notify(Playernum, Governor, buf);
}

int
gettype(planettype * p, int x, int y)
{
  return (Sector(*p, x, y).condition);
}

int
getowner(planettype * p, int x, int y)
{
  return (Sector(*p, x, y).owner);
}

char
getsymbol(planettype * p, int x, int y, racetype * r, int Playernum)
{
  reg sectortype *s;
  char            retval;

  s = &Sector(*p, x, y);

  if (s->crystals && (r->discoveries[D_CRYSTAL] || r->God))
  {
    retval = CSPD_XTAL_SYMBOL;
  }
  else if (s->troops)
  {
    if (s->owner == Playernum)
      retval = CSPD_TROOP_MINE_SYMBOL;
    else if (isset(r->allied, s->owner))
      retval = CSPD_TROOP_ALLIED_SYMBOL;
    else if (isset(r->atwar, s->owner))
      retval = CSPD_TROOP_ENEMY_SYMBOL;
    else
      retval = CSPD_TROOP_NEUTRAL_SYMBOL;
  }
  else
    switch (s->condition)
    {
      case WASTED:
        retval = CHAR_WASTED;
        break;
      case SEA:
        retval = CHAR_SEA;
        break;
      case LAND:
        retval = CHAR_LAND;
        break;
      case MOUNT:
        retval = CHAR_MOUNT;
        break;
      case GAS:
        retval = CHAR_GAS;
        break;
      case PLATED:
        retval = CHAR_PLATED;
        break;
      case ICE:
        retval = CHAR_ICE;
        break;
      case DESERT:
        retval = CHAR_DESERT;
        break;
      case FOREST:
        retval = CHAR_FOREST;
        break;
      case WORM:
        retval = CHAR_WORM;
        break;
      default:
        retval = '?';
        break;
    }

  return retval;
}
