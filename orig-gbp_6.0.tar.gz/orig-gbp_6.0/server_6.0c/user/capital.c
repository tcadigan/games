/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)capital.c       1.8 12/3/93 "
 * 
 * capital.c -- designate a capital
 *
 * $Header: /var/cvs/gbp/GB+/user/capital.c,v 1.4 2007/07/06 18:09:34 gbp Exp $
 */

#include <stdlib.h>             /* added for atoi() & free() (kse) */

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"
#include "proto.h"

void
capital(int Playernum, int Governor, int APcount)
{
  int             shipno, stat, snum;
  shiptype       *s;
  racetype       *Race;

  Race = races[Playernum - 1];

  if (argn != 2)
    shipno = Race->Gov_ship;
  else
    shipno = atoi(args[1] + (args[1][0] == '#'));

  if (shipno <= 0)
  {
    notify(Playernum, Governor, "Change the capital to be what ship?\n");
    return;
  }
  stat = getship(&s, shipno);

  if (argn == 2)
  {
    snum = s->storbits;
    if (!stat || testship(Playernum, Governor, s))
    {
      notify(Playernum, Governor, "You can't do that!\n");
      free((char *)s);
      return;
    }
    if (!landed(s))
    {
      notify(Playernum, Governor, "Try landing this ship first!\n");
      free((char *)s);
      return;
    }
    if (!enufAP(Playernum, Governor, Stars[snum]->AP[Playernum - 1], APcount))
    {
      free((char *)s);
      return;
    }
    if (s->type != OTYPE_GOV)
    {
      sprintf(buf, "That ship is not a %s.\n", Shipnames[OTYPE_GOV]);
      (void)notify(Playernum, Governor, buf);
      free((char *)s);
      return;
    }
    deductAPs(Playernum, Governor, APcount, snum, 0);
    Race->Gov_ship = shipno;
    putrace(Race);
  }
  sprintf(buf, "Efficiency of governmental center: %.0f%%.\n",
          ((double)s->popn / (double)Max_crew(s)) * (100 - (double)s->damage));
  notify(Playernum, Governor, buf);
  free((char *)s);
}
