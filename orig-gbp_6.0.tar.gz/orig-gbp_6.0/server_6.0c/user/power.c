/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)power.c 1.10 12/3/93 "
 * 
 * power.c -- display power report
 *
 * $Header: /var/cvs/gbp/GB+/user/power.c,v 1.3 2007/07/06 18:09:34 gbp Exp $
 */

#include <errno.h>
#include <time.h>
#include <string.h>
#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"

extern int      errno;
extern struct tm *update_tm;

EXTERN void     block(int, int, int);
EXTERN void     power(int, int, int);
EXTERN void     prepare_output_line(racetype *, racetype *, int, int);

#include "proto.h"

void
block(int Playernum, int Governor, int APcount)
{
  register int    i, n;
  int             p;
  racetype       *r, *Race;
  int             dummy_, dummy[2];

  n = Num_races;

  Race = races[Playernum - 1];

  if (argn == 3 && match(args[1], "player"))
  {
    if (!(p = GetPlayer(args[2])))
    {
      notify(Playernum, Governor, "No such player.\n");
      return;
    }
    r = races[p - 1];
    dummy_ = 0;                 /* Used as flag for finding a block */
    sprintf(buf, "Race #%d [%s] is a member of ", p, r->name);
    notify(Playernum, Governor, buf);
    for (i = 1; i <= n; i++)
    {
      if (isset(Blocks[i - 1].pledge, p) && isset(Blocks[i - 1].invite, p))
      {
        sprintf(buf, "%s%d", (dummy_ == 0) ? " " : ", ", i);
        notify(Playernum, Governor, buf);
        dummy_ = 1;
      }
    }
    if (dummy_ == 0)
      notify(Playernum, Governor, "no blocks\n");
    else
      notify(Playernum, Governor, "\n");

    dummy_ = 0;                 /* Used as flag for finding a block */
    sprintf(buf, "Race #%d [%s] has been invited to join ", p, r->name);
    notify(Playernum, Governor, buf);
    for (i = 1; i <= n; i++)
    {
      if (!isset(Blocks[i - 1].pledge, p) && isset(Blocks[i - 1].invite, p))
      {
        sprintf(buf, "%s%d", (dummy_ == 0) ? " " : ", ", i);
        notify(Playernum, Governor, buf);
        dummy_ = 1;
      }
    }
    if (dummy_ == 0)
      notify(Playernum, Governor, "no blocks\n");
    else
      notify(Playernum, Governor, "\n");

    dummy_ = 0;                 /* Used as flag for finding a block */
    sprintf(buf, "Race #%d [%s] has pledged ", p, r->name);
    notify(Playernum, Governor, buf);
    for (i = 1; i <= n; i++)
    {
      if (isset(Blocks[i - 1].pledge, p) && !isset(Blocks[i - 1].invite, p))
      {
        sprintf(buf, "%s%d", (dummy_ == 0) ? " " : ", ", i);
        notify(Playernum, Governor, buf);
        dummy_ = 1;
      }
    }
    if (!dummy_)
      notify(Playernum, Governor, "no blocks\n");
    else
      notify(Playernum, Governor, "\n");
  }
  else if (argn > 1)
  {
    if (!(p = GetPlayer(args[1])))
    {
      notify(Playernum, Governor, "No such player,\n");
      return;
    }
    r = races[p - 1];
    /* list the players who are in this alliance block */
    dummy[0] = (Blocks[p - 1].invite[0] & Blocks[p - 1].pledge[0]);
    dummy[1] = (Blocks[p - 1].invite[1] & Blocks[p - 1].pledge[1]);
    sprintf(buf, "         ========== %s Power Report ==========\n",
            Blocks[p - 1].name);
    notify(Playernum, Governor, buf);
    sprintf(buf, "         	       %-64.64s\n", Blocks[p - 1].motto);
    notify(Playernum, Governor, buf);
    sprintf(buf,
            "  #  Name              troops  pop  money ship  plan  res fuel dest know\n");
    notify(Playernum, Governor, buf);

    for (i = 1; i <= n; i++)
      if (isset(dummy, i))
      {
        r = races[i - 1];
        if (!r->dissolved)
        {
          sprintf(buf, "%2d %-20.20s ", i, r->name);
          sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].troops, Race, i));
          strcat(buf, temp);
          sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].popn, Race, i));
          strcat(buf, temp);
          sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].money, Race, i));
          strcat(buf, temp);
          sprintf(temp, "%5s",
                  Estimate_i((int)Power[i - 1].ships_owned, Race, i));
          strcat(buf, temp);
          sprintf(temp, "%5s",
                  Estimate_i((int)Power[i - 1].planets_owned, Race, i));
          strcat(buf, temp);
          sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].resource, Race, i));
          strcat(buf, temp);
          sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].fuel, Race, i));
          strcat(buf, temp);
          sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].destruct, Race, i));
          strcat(buf, temp);
          sprintf(temp, " %3d%%\n", Race->translate[i - 1]);
          strcat(buf, temp);
          notify(Playernum, Governor, buf);
        }
      }
  }
  else
  {                             /* list power report for all the alliance
                                 * blocks (as of the last update) */
    sprintf(buf, "                    ========== Alliance Blocks ==========\n");
    notify(Playernum, Governor, buf);
    sprintf(buf,
            " # Name             memb money popn ship  sys  res fuel dest  VPs know\n");
    notify(Playernum, Governor, buf);
    for (i = 1; i <= n; i++)
      if (Power_blocks.members[i - 1] > 1)
      {
        sprintf(buf, "%2d %-19.19s%3ld", i, Blocks[i - 1].name,
                Power_blocks.members[i - 1]);
        sprintf(temp, "%5s",
                Estimate_i((int)(Power_blocks.money[i - 1]), Race, i));
        strcat(buf, temp);
        sprintf(temp, "%5s",
                Estimate_i((int)(Power_blocks.popn[i - 1]), Race, i));
        strcat(buf, temp);
        sprintf(temp, "%5s",
                Estimate_i((int)(Power_blocks.ships_owned[i - 1]), Race, i));
        strcat(buf, temp);
        sprintf(temp, "%5s",
                Estimate_i((int)(Power_blocks.systems_owned[i - 1]), Race, i));
        strcat(buf, temp);
        sprintf(temp, "%5s",
                Estimate_i((int)(Power_blocks.resource[i - 1]), Race, i));
        strcat(buf, temp);
        sprintf(temp, "%5s",
                Estimate_i((int)(Power_blocks.fuel[i - 1]), Race, i));
        strcat(buf, temp);
        sprintf(temp, "%5s",
                Estimate_i((int)(Power_blocks.destruct[i - 1]), Race, i));
        strcat(buf, temp);
        sprintf(temp, "%5s",
                Estimate_i((int)(Power_blocks.VPs[i - 1]), Race, i));
        strcat(buf, temp);
        sprintf(temp, " %3d%%\n", Race->translate[i - 1]);
        strcat(buf, temp);
        notify(Playernum, Governor, buf);
      }
  }
}

void
power(int Playernum, int Governor, int APcount)
{
  register int    i, n;
  int             p;
  racetype       *r, *Race;
  struct vic      vic[MAXPLAYERS];

  n = Num_races;
  p = -1;

  if (argn >= 2)
  {
    if (!(p = GetPlayer(args[1])))
    {
      notify(Playernum, Governor, "No such player,\n");
      return;
    }
    r = races[p - 1];
  }
  Race = races[Playernum - 1];

  sprintf(buf,
          "         ========== Galactic Bloodshed Power Report ==========\n");
  notify(Playernum, Governor, buf);

  if (Race->God)
#ifdef USE_VN
    sprintf(buf,
            "%s  #  Name          VP  mil  civ cash ship pl  res fuel dest morl  VNhl\n",
            argn < 2 ? "rank" : "");
#else
    sprintf(buf,
            "%s  #  Name          VP  mil  civ cash ship pl  res fuel dest morl\n",
            argn < 2 ? "rank" : "");
#endif
  else
    sprintf(buf,
            "%s  #  Name          VP  mil  civ cash ship pl  res fuel dest morl know\n",
            argn < 2 ? "rank" : "");
  notify(Playernum, Governor, buf);

  if (argn < 2)
  {
    create_victory_list(vic);
    for (i = 1; i <= n; i++)
    {
      p = vic[i - 1].racenum;
      r = races[p - 1];
      if ((!r->dissolved) && (Race->translate[p - 1] >= 10) && (!r->God) &&
          (!r->Guest))
      {
        prepare_output_line(Race, r, p, i);
        notify(Playernum, Governor, buf);
      }
    }
  }
  else
  {
    r = races[p - 1];
    prepare_output_line(Race, r, p, 0);
    notify(Playernum, Governor, buf);
  }
}

void
prepare_output_line(racetype * Race, racetype * r, int i, int rank)
{
  if (rank)
    sprintf(buf, "%2d ", rank);
  else
    buf[0] = '\0';

  sprintf(temp, "[%2d]%s%s%-10.10s %5s", i,
          isset(Race->allied, i) ? "+" : (isset(Race->atwar, i) ? "-" : " "),
          isset(r->allied,
                Race->Playernum) ? "+" : (isset(r->atwar,
                                                Race->Playernum) ? "-" : " "),
          r->name, Estimate_i((int)r->victory_score, Race, i));
  strcat(buf, temp);
  sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].troops, Race, i));
  strcat(buf, temp);
  sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].popn, Race, i));
  strcat(buf, temp);
  sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].money, Race, i));
  strcat(buf, temp);
  sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].ships_owned, Race, i));
  strcat(buf, temp);
  sprintf(temp, "%3s", Estimate_i((int)Power[i - 1].planets_owned, Race, i));
  strcat(buf, temp);
  sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].resource, Race, i));
  strcat(buf, temp);
  sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].fuel, Race, i));
  strcat(buf, temp);
  sprintf(temp, "%5s", Estimate_i((int)Power[i - 1].destruct, Race, i));
  strcat(buf, temp);
  sprintf(temp, "%5s", Estimate_i((int)r->morale, Race, i));
  strcat(buf, temp);

#ifdef USE_VN
  if (Race->God)
  {
    sprintf(temp, " %4d", Sdata.VN_hitlist[i - 1]);
    strcat(buf, temp);
  }
#endif

  if (!Race->God)
  {
    sprintf(temp, " %3d%%\n", Race->translate[i - 1]);
    strcat(buf, temp);
  }
  else
    strcat(buf, "\n");
}
