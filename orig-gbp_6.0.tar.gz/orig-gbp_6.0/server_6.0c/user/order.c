/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 *  #ident  "@(#)order.c        1.16 12/3/93 "
 * 
 * order.c -- give orders to ship
 
 $Header: /var/cvs/gbp/GB+/user/order.c,v 1.8 2007/07/06 18:09:34 gbp Exp $
 */

#include <curses.h>
#include <ctype.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"
#include "proto.h"
#include "orders.h"

void            order(int, int, int);
void            mk_expl_aimed_at(int, int, shiptype *);
void            DispOrdersHeader(int, int);
void            DispOrders(int, int, shiptype *);
void            route(int, int, int);
int             get_order_type(char *);

void
order(int Playernum, int Governor, int APcount)
{
  int             shipno, nextshipno, hdrshown = 0, ordertype = ORD_NULL;
  shiptype       *ship;

  // char tmp[15];

  if (argn == 1)                /* display all ship orders */
  {
    /* Modification to show current orders of ship if at the ship scope -mfw */
    if (Dir[Playernum - 1][Governor].level == LEVEL_SHIP)
    {
      // changed mind for now, would have to account for giving order too. -mfw
      // sprintf(tmp, "#%d", Dir[Playernum - 1][Governor].shipno);
      // nextshipno = start_shiplist(Playernum, Governor, tmp);
    }
    else
    {
      nextshipno = start_shiplist(Playernum, Governor, "");
    }

    while ((shipno = do_shiplist(&ship, &nextshipno)))
    {
      if (((ship->owner == Playernum) && (authorized(Governor, ship))) ||
          races[Playernum - 1]->God)
      {
        if (!hdrshown)
        {
          DispOrdersHeader(Playernum, Governor);
          hdrshown = 1;
        }
        DispOrders(Playernum, Governor, ship);
        free((char *)ship);
      }
      else
      {
        free((char *)ship);
      }
    }
  }
  else if (argn >= 2)
  {
    nextshipno = start_shiplist(Playernum, Governor, args[1]);

    if (argn > 2)
    {
      ordertype = get_order_type(args[2]);
    }

    while ((shipno = do_shiplist(&ship, &nextshipno)))
    {
      if (in_list(Playernum, args[1], ship, &nextshipno) &&
          (authorized(Governor, ship) || races[Playernum - 1]->God))
      {
        if (!hdrshown)
        {
          DispOrdersHeader(Playernum, Governor);
          hdrshown = 1;
        }

        if (argn > 2)
          give_orders(Playernum, Governor, APcount, ship, ordertype);

        DispOrders(Playernum, Governor, ship);
        free((char *)ship);
      }
      else
      {
        free((char *)ship);
      }
    }
  }
  else
  {
    notify(Playernum, Governor, "I don't understand what you mean.\n");
  }

  if (!hdrshown)                /* no ships found */
  {
    notify(Playernum, Governor, "No applicable ships.\n");
  }
}

void
do_inf_ord(int Playernum, int Governor, shiptype * ship)
{
  int             maxx, maxy, x, y, i, f;
  struct inf_setting *infs;
  planettype     *planet;

  if (match(args[3], "usage") || match(args[3], "help"))
  {
    inf_usage(Playernum, Governor, "report");
    inf_usage(Playernum, Governor, "eff");
    inf_usage(Playernum, Governor, "fert");
    inf_usage(Playernum, Governor, "atmos");
    return;
  }
  else if (match(args[3], "report"))
  {
    if (argn < 4)
    {
      inf_usage(Playernum, Governor, "report");
      return;
    }
    if (match(args[4], "on"))
      ship->inf.wants_reports = 1;
    else
      ship->inf.wants_reports = 0;

    sprintf(buf, "%s\n",
            (char *)(ship->inf.
                     wants_reports ? "Reporting enabled" : "Reports disabled"));
    notify(Playernum, Governor, buf);
    return;
  }
  else if (match(args[3], "eff"))
  {
    if (argn < 4)
    {
      inf_usage(Playernum, Governor, "eff");
      return;
    }
    if (match(args[4], "limit"))
    {
      if (argn < 7)
      {
        inf_usage(Playernum, Governor, "eff");
        return;
      }
      if (!isdigit((unsigned char)args[5][0]))
      {
        inf_usage(Playernum, Governor, "eff");
        return;
      }

      /* check bounds */
      sscanf(args[5], "%d,%d", &x, &y);
      getplanet(&planet, (int)ship->deststar, (int)ship->destpnum);
      maxx = planet->Maxx;
      maxy = planet->Maxy;
      free(planet);
      if (x > maxx || y > maxy)
      {
        sprintf(buf, "Invalid x,y for sector (%d,%d)\n", x, y);
        notify(Playernum, Governor, buf);
        return;
      }

      f = 0;
      for (i = 0; i < INF_MAX_TARGETS; i++)
      {
        infs = &(ship->inf.eff_targets[i]);
        if (infs->x == x && infs->y == y)
        {
          f = 1;
          infs->max = atoi(args[6]);
          if (infs->max < 0)
            infs->max = 0;
          if (infs->max > INF_MAX)
            infs->max = INF_MAX;
          return;
        }
      }
      sprintf(buf, "No such target [%s]\n", args[5]);
      notify(Playernum, Governor, buf);
      return;
    }

    if (match(args[4], "target"))
    {
      if (argn < 6)
      {
        inf_usage(Playernum, Governor, "eff");
        return;
      }
      if (!isdigit((unsigned char)args[5][0]))
      {
        inf_usage(Playernum, Governor, "eff");
        return;
      }

      sscanf(args[5], "%d,%d", &x, &y);
      getplanet(&planet, (int)ship->deststar, (int)ship->destpnum);
      maxx = planet->Maxx;
      maxy = planet->Maxy;
      free(planet);
      if (x > maxx || y > maxy)
      {
        sprintf(buf, "Invalid x,y for sector (%d,%d)\n", x, y);
        notify(Playernum, Governor, buf);
        return;
      }

      f = 0;
      for (i = 0; i < INF_MAX_TARGETS; i++)
      {
        infs = &(ship->inf.eff_targets[i]);

        /* check for dup if(x == infs->x && y == infs->y) { sprintf(buf, "That
         * target already set\n"); notify(Playernum, Governor, buf); return; } */

        if (infs->x == 999)
        {
          /* need to get sectors and check range */
          infs->x = x;
          infs->y = y;
          if (argn >= 7)
          {
            infs->max = atoi(args[6]);
            if (infs->max > INF_MAX)
              infs->max = INF_MAX;
          }
          else
            infs->max = INF_MAX;

          f = 1;
          return;
        }
      }
      if (f)
        sprintf(buf, "Eff Target set to %d,%d and eff limit set to %d%%\n",
                infs->x, infs->y, infs->max);
      else
        sprintf(buf, "Max targets of %d already set\n", INF_MAX_TARGETS);
    }
    else
    {
      ship->inf.eff_setting = atoi(args[4]);
      sprintf(buf, "Eff setting: %d\n", ship->inf.eff_setting);
    }
    notify(Playernum, Governor, buf);
    return;
  }
  else if (match(args[3], "fert"))
  {

    if (match(args[4], "limit"))
    {
      if (argn < 7)
      {
        inf_usage(Playernum, Governor, "fert");
        return;
      }
      sscanf(args[5], "%d,%d", &x, &y);
      getplanet(&planet, (int)ship->deststar, (int)ship->destpnum);
      maxx = planet->Maxx;
      maxy = planet->Maxy;
      free(planet);
      if (x > maxx || y > maxy)
      {
        sprintf(buf, "Invalid x,y for sector (%d,%d)\n", x, y);
        notify(Playernum, Governor, buf);
        return;
      }

      f = 0;
      for (i = 0; i < INF_MAX_TARGETS; i++)
      {
        infs = &(ship->inf.eff_targets[i]);
        if (infs->x == x && infs->y == y)
        {
          f = 1;
          infs->max = atoi(args[6]);
          if (infs->max < 0)
            infs->max = 0;
          if (infs->max > INF_MAX)
            infs->max = INF_MAX;
          return;
        }
      }
      sprintf(buf, "No such target [%s]\n", args[5]);
      notify(Playernum, Governor, buf);
      return;
    }

    if (match(args[4], "target"))
    {
      if (argn < 6)
      {
        inf_usage(Playernum, Governor, "fert");
        return;
      }
      sscanf(args[5], "%d,%d", &x, &y);
      getplanet(&planet, (int)ship->deststar, (int)ship->destpnum);
      maxx = planet->Maxx;
      maxy = planet->Maxy;
      free(planet);
      if (x > maxx || y > maxy)
      {
        sprintf(buf, "Invalid x,y for sector (%d,%d)\n", x, y);
        notify(Playernum, Governor, buf);
        return;
      }

      f = 0;
      for (i = 0; i < INF_MAX_TARGETS; i++)
      {
        infs = &(ship->inf.fert_targets[i]);
        /* check for dup if(x == infs->x && y == infs->y) { sprintf(buf, "That
         * target already set\n"); notify(Playernum, Governor, buf); return; } */
        if (infs->x == 999)
        {
          infs->x = x;
          infs->y = y;
          if (argn >= 7)
          {
            infs->max = atoi(args[6]);
            if (infs->max > INF_MAX)
              infs->max = INF_MAX;
          }
          else
            infs->max = INF_MAX;
          f = 1;
          break;
        }
      }
      if (f)
        sprintf(buf, "Fert Target set to %d,%d and fert limit set to %d%%\n",
                infs->x, infs->y, infs->max);
      else
        sprintf(buf, "Max targets of %d already set\n", INF_MAX_TARGETS);
    }
    else
    {
      ship->inf.fert_setting = atoi(args[4]);
      sprintf(buf, "Fert setting: %d\n", ship->inf.fert_setting);
    }
    notify(Playernum, Governor, buf);
    return;
  }
  else if (match(args[3], "atmosphere"))
  {
    if (!Atmos(races[Playernum - 1]))
    {
      sprintf(buf, "You need [%d] tech to turn this on\n", (int)TECH_ATMOS);
      notify(Playernum, Governor, buf);
      return;
    }

    if (argn < 4)
    {
      inf_usage(Playernum, Governor, "atmos");
      return;
    }

    if (!isdigit((unsigned char)args[4][0]))
    {
      sprintf(buf, "Invalid number: %s\n", args[4]);
      notify(Playernum, Governor, buf);
      return;
    }

    if (atoi(args[4]) > INF_MAX_ATMO_SETTING)
    {
      sprintf(buf, "Setting to high, maximum is %d.\n", INF_MAX_ATMO_SETTING);
    }
    else
    {
      ship->inf.atmos_setting = atoi(args[4]);
      sprintf(buf, "Atmosphere setting: %d\n", ship->inf.atmos_setting);
    }
    notify(Playernum, Governor, buf);
    return;
  }
  inf_usage(Playernum, Governor, "eff");
  inf_usage(Playernum, Governor, "fert");
  inf_usage(Playernum, Governor, "atmos");
}

void
inf_usage(int Playernum, int Governor, char *which)
{
  /* usage for report, eff , fert and atmos */
  if (match(which, "report"))
  {
    sprintf(buf, "USAGE: order <ship> inf report on/off\n");
  }
  else if (match(which, "eff"))
  {
    sprintf(buf, "USAGE: order <ship> inf eff <setting>\n\
or order <ship> inf eff limit <x>,<y> <limit>\n\
or order <ship> inf eff target <x>,<y> [limit]\n");
  }
  else if (match(which, "fert"))
  {
    sprintf(buf, "USAGE: order <ship> inf fert <setting>\n\
or order <ship> inf fert limit <x>,<y> <limit>\n\
or order <ship> inf fert target <x>,<y> [limit]\n");
  }
  else if (match(which, "atmos"))
  {
    sprintf(buf, "USAGE: order <ship> inf atmos <setting>\n");
  }
  notify(Playernum, Governor, buf);

}

void
give_orders(int Playernum, int Governor, int APcount, shiptype * ship,
            int ordertype)
{
  int             i = 0, j = 0, x, y;
  placetype       where, pl;
  planettype     *planet;
  shiptype       *tmpship;

  if (!ship->active)
  {
    sprintf(buf, "%s is irradiated (%d); it cannot be given orders.\n",
            Ship(ship), ship->rad);
    notify(Playernum, Governor, buf);
    return;
  }
#ifdef USE_AMOEBA
  if (ship->type != OTYPE_TRANSDEV && ship->type != OTYPE_AMOEBA && !ship->popn
      && Max_crew(ship))
  {
#else
  if (ship->type != OTYPE_TRANSDEV && !ship->popn && Max_crew(ship))
  {
#endif
    sprintf(buf, "%s has no crew and is not a robotic ship.\n", Ship(ship));
    notify(Playernum, Governor, buf);
    return;
  }

  switch (ordertype)
  {
    case ORD_INF:
      if (argn < 3)
      {
        sprintf(buf, "Not enough args\n");
        notify(Playernum, Governor, buf);
        return;
      }
      do_inf_ord(Playernum, Governor, ship);
      break;
    case ORD_REPORT:
      ship->wants_reports = (ship->wants_reports ? 0 : 1);
      break;
    case ORD_CLOAK:
      if (can_cloak(ship))
      {
        if (!Cloak(races[Playernum - 1]))
        {
          sprintf(buf, "You need [%d] tech to cloak\n", (int)TECH_CLOAK);
          notify(Playernum, Governor, buf);
          break;
        }

        if (match(args[3], "on"))
        {
          if (!ship->cloaked)
          {
            /* use some fuel */
            if (ship->fuel < (ship->size * .1))
            {
              sprintf(buf, "Ship [%d] doesn't have enough fuel to cloak [%f]\n",
                      ship->number, ship->size * .1);
              notify(Playernum, Governor, buf);
            }
          }
          ship->cloaking = 1;
        }
        else
          ship->cloaking = 0;

        sprintf(buf, "Ship [%d] ordered to %s.\n", ship->number,
                (char *)(ship->cloaking ? "cloak" : "decloak"));
        notify(Playernum, Governor, buf);
      }
      else
      {
        sprintf(buf, "%s\n",
                (char *)(can_cloak(ship) ? "Ship has no cloaking device" :
                         "This ship cannot cloak"));
        notify(Playernum, Governor, buf);
      }
      break;
    case ORD_DEFE:
      if (can_bombard(ship))
      {
        if (match(args[3], "off"))
          ship->protect.planet = 0;
        else
          ship->protect.planet = 1;
      }
      else
        notify(Playernum, Governor,
               "That ship cannot be assigned those orders.\n");
      break;
    case ORD_SCAT:
      if (ship->type != STYPE_MISSILE)
        notify(Playernum, Governor, "Only missiles can be given this order.\n");
      else
        ship->special.impact.scatter = 1;
      break;
    case ORD_IMPA:
      if (ship->type != STYPE_MISSILE)
        notify(Playernum, Governor,
               "Only missiles can be designated for this.\n");
      else
      {
        sscanf(args[3], "%d,%d", &x, &y);
        ship->special.impact.x = x;
        ship->special.impact.y = y;
        ship->special.impact.scatter = 0;
      }
      break;
    case ORD_JUMP:
      if (ship->docked)
      {
        notify(Playernum, Governor,
               "That ship is docked. Use 'launch' or 'undock' first.\n");
      }
      else
      {
        if (ship->hyper_drive.has)
        {
          if (match(args[3], "off"))
          {
            ship->hyper_drive.on = 0;
          }
          else
          {
            if (ship->whatdest != LEVEL_STAR && ship->whatdest != LEVEL_PLAN)
            {
              notify(Playernum, Governor,
                     "Destination must be star or planet.\n");
            }
            else
            {
              if (isclr(Stars[ship->deststar]->explored, ship->owner))
              {
                notify(Playernum, Governor,
                       "You have not explored that system, cannot jump.\n");
              }
              else
              {
                ship->hyper_drive.on = 1;
                ship->navigate.on = 0;

                if (ship->mounted)
                {
                  ship->hyper_drive.charge = 1;

                  /* comment out to delay jump -mfw */
                  ship->hyper_drive.ready = 1;
                }
              }
            }
          }
        }
        else
        {
          notify(Playernum, Governor,
                 "This ship does not have hyper drive capability.\n");
        }

        break;
#ifdef THRESHLOADING
    case ORD_THRE:
        /* CWL threshold loading */
        if (argn == 3)
        {                       /* Clear all thresholds */
          int             i;

          for (i = 0; i <= TH_CRYSTALS; i++)
            ship->threshload[i] = 0;
          notify(Playernum, Governor, "All threshloads cleared.\n");
        }
        else if (argn == 4 || argn == 5)
        {                       /* Clear one threshold */
          unsigned        amount;
          char           *c;

          amount = (argn == 5) ? (unsigned)atoi(args[4]) : 1000;
          c = args[3];
          while (*c)
          {
            switch (*c)
            {
              case 'r':
                ship->threshload[TH_RESOURCE] = MIN(ship->max_resource, amount);
                break;
              case 'd':
                ship->threshload[TH_DESTRUCT] = MIN(ship->max_destruct, amount);
                break;
              case 'f':
                ship->threshload[TH_FUEL] = MIN(ship->max_fuel, amount);
                break;
              case 'x':
                ship->threshload[TH_CRYSTALS] = MIN(Max_crystals(s), amount);
                break;
              default:
                notify(Playernum, Governor, "Unknown commodity; use rdfx.\n");
                break;
            }
            c++;
          }                     /* end while */
        }
        else
          notify(Playernum, Governor, "threshold <rdfx> [amount]\n");
        break;
#endif
#ifdef AUTOSCRAP
    case ORD_AUTO:
        if (argn >= 4)
        {
          if (match(args[3], "on"))
            ship->autoscrap = 1;
          else
            ship->autoscrap = 0;
        }
        else
          ship->autoscrap = !ship->autoscrap;
        break;
#endif
    case ORD_PROT:
        if (argn > 3)
          sscanf(args[3] + (args[3][0] == '#'), "%d", &j);
        else
          j = 0;
        if (j == ship->number)
          notify(Playernum, Governor, "You can't do that.\n");
        else
        {
          if (can_bombard(ship))
          {
            if (!j)
            {
              ship->protect.on = 0;
            }
            else
            {
              ship->protect.on = 1;
              ship->protect.ship = j;
            }
          }
          else
            notify(Playernum, Governor, "That ship cannot protect.\n");
        }
        break;
    case ORD_NAVI:
        if (argn >= 5)
        {
          ship->navigate.on = 1;
          ship->navigate.bearing = atoi(args[3]);
          ship->navigate.turns = atoi(args[4]);
        }
        else
          ship->navigate.on = 0;
        if (ship->hyper_drive.on)
          ship->hyper_drive.on = 0;
      }
      break;
    case ORD_SWIT:
      if (ship->type == OTYPE_FACTORY)
        notify(Playernum, Governor, "Use \"on\" to bring factory online.\n");
      else
      {
        if (has_switch(ship))
        {
          if (ship->whatorbits == LEVEL_SHIP)
            notify(Playernum, Governor, "That ship is being transported.\n");
          else
          {
            ship->on = !ship->on;
            if (ship->on)
            {
              switch (ship->type)
              {
                case STYPE_MINEF:
                  notify(Playernum, Governor, "Minefield armed and ready.\n");
                  break;
                case OTYPE_TRANSDEV:
                  notify(Playernum, Governor,
                         "Transporter ready to receive.\n");
                  break;
                default:
                  break;
              }
            }
            else
            {
              switch (ship->type)
              {
                case STYPE_MINEF:
                  notify(Playernum, Governor, "Minefield disarmed.\n");
                  break;
                case OTYPE_TRANSDEV:
                  notify(Playernum, Governor, "No longer receiving.\n");
                  break;
                default:
                  break;
              }
            }
          }
        }
        else
          notify(Playernum, Governor,
                 "That ship does not have an on/off setting.\n");
      }
      break;
    case ORD_DEST:
      if (speed_rating(ship))
      {
        if (ship->docked)
          notify(Playernum, Governor,
                 "That ship is docked; use undock or launch first.\n");
        else
        {
          where = Getplace(Playernum, Governor, args[3], 1);
          if (!where.err)
          {
            if (where.level == LEVEL_SHIP)
            {
              getship(&tmpship, where.shipno);
              if (!followable(ship, tmpship))
              {
                notify(Playernum, Governor,
                       "Warning: that ship is out of range.\n");
                free((char *)tmpship);
                return;
              }
              free((char *)tmpship);
              ship->destshipno = where.shipno;
              ship->whatdest = LEVEL_SHIP;
            }
            else
            {
              /* to foil cheaters */
              if (where.level != LEVEL_UNIV &&
                  ((ship->storbits != where.snum) && where.level != LEVEL_STAR)
                  && isclr(Stars[where.snum]->explored, ship->owner))
              {
                notify(Playernum, Governor,
                       "You haven't explored this system.\n");
                return;
              }

              if (ship->hyper_drive.on &&
                  isclr(Stars[where.snum]->explored, ship->owner))
              {
                notify(Playernum, Governor,
                       "Unexplored system, deactivating hyperdrive.\n");
                ship->hyper_drive.on = 0;
              }

              /* stop pods from changing destination -mfw */
              if (SISAPOD(ship) && ship->special.pod.navlock)
              {
                notify(Playernum, Governor,
                       "You cannot change the destination of a pod.\n");
                return;
              }

              ship->whatdest = where.level;
              ship->deststar = where.snum;
              ship->destpnum = where.pnum;
            }
          }
          else
            return;
        }
      }
      else
        notify(Playernum, Governor, "That ship cannot be launched.\n");
      break;
    case ORD_EVAD:
      if (Max_crew(ship) && Max_speed(ship))
      {
        if (match(args[3], "on"))
          ship->protect.evade = 1;
        else if (match(args[3], "off"))
          ship->protect.evade = 0;
      }
      break;
    case ORD_BOMB:
      if (ship->type != OTYPE_OMCL)
      {
        if (can_bombard(ship))
        {
          if (match(args[3], "off"))
            ship->bombard = 0;
          else if (match(args[3], "on"))
            ship->bombard = 1;
        }
        else
          notify(Playernum, Governor,
                 "This type of ship cannot be ordered to bombard.\n");
      }
      break;

    case ORD_SMART:
      /* smart gun orders from Hap -mfw */
      if (!strncmp(args[3], "strength", strlen(args[3])))
      {
        int             smart_str = atoi(args[4]);

        if (smart_str < 0)
        {
          notify(Playernum, Governor, "The strength must be greater than 0.\n");
        }
        else
        {
          ship->smart_strength = smart_str;
        }
      }
      else if (!strncmp(args[3], "list", strlen(args[3])))
      {
        char            cc;
        char           *slp;
        int             cp, sp, l4, ip = 0, isinthere;

        l4 = strlen(args[4]);

        for (cp = 0; cp < l4; cp++)
        {
          cc = args[4][cp];

          for (sp = 0; sp < NUMSTYPES; sp++)
          {
            if (cc == Shipltrs[sp])
            {
              slp = ship->smart_list;
              isinthere = 0;

              while (!isinthere && *slp)
                isinthere = (cc == *slp++);

              if (!isinthere)
              {
                if (ip < SMART_LIST_SIZE)
                {
                  ship->smart_list[ip] = cc;
                  ip++;
                }
                else
                  cp = l4;      /* break out simply */
              }
              sp = NUMSTYPES;   /* break out simply */
            }                   /* if cc is a ship letter */
          }                     /* looking through ship letters */
        }                       /* for cp is less then l4 */
        ship->smart_list[ip] = (char)0;
      }
      else if (!strncmp(args[3], "gun", strlen(args[3])))
      {
        if (!strncmp(args[4], "primary", strlen(args[4])))
        {
          ship->smart_gun = PRIMARY;
          ship->smart_strength = ship->primary;
          notify(Playernum, Governor, "Smart gun set to primary.\n");
        }
        else if (!strncmp(args[4], "secondary", strlen(args[4])))
        {
          ship->smart_gun = SECONDARY;
          ship->smart_strength = ship->secondary;
          notify(Playernum, Governor, "Smart gun set to secondary.\n");
        }
        else
        {
          ship->smart_gun = NONE;
          ship->smart_strength = 0;
          notify(Playernum, Governor, "Smart gun turned off.\n");
        }
      }
      else
      {
        notify(Playernum, Governor,
               "Enter smart strength <number>, smart list <list> or smart gun <primary|secondary|off>.\n");
      }
      break;                    /* end ORD_SMART */

    case ORD_RETA:
      if (ship->type != OTYPE_OMCL && ship->type != STYPE_MINEF)
      {
        if (can_bombard(ship))
        {
          if (match(args[3], "off"))
            ship->protect.self = 0;
          else if (match(args[3], "on"))
            ship->protect.self = 1;
        }
        else
          notify(Playernum, Governor,
                 "This type of ship cannot be set to retaliate.\n");
      }
      break;
    case ORD_FOCU:
      if (ship->laser)
      {
        if (match(args[3], "on"))
          ship->focus = 1;
        else
          ship->focus = 0;
      }
      else
        notify(Playernum, Governor, "No laser.\n");
      break;
    case ORD_LASE:
      if (ship->laser)
      {
        if (can_bombard(ship))
        {
          if (ship->mounted)
          {
            if (match(args[3], "on"))
              /* set laser strenght to given value or max. safe value */
              ship->fire_laser =
                (argn >
                 4) ? atoi(args[4]) : (int)((1.0 -
                                             .01 * ship->damage) * ship->tech /
                                            4.0);
            else
              ship->fire_laser = 0;
          }
          else
            notify(Playernum, Governor, "You do not have a crystal mounted.\n");
        }
        else
          notify(Playernum, Governor, "This ship is not able to use lasers.\n");
      }
      else
        notify(Playernum, Governor,
               "This ship is not equipped with combat lasers.\n");
      break;
    case ORD_MERC:
      if (match(args[3], "off"))
        ship->merchant = 0;
      else
      {
        j = atoi(args[3]);
        if (j < 0 || j > MAX_ROUTES)
          notify(Playernum, Governor, "Bad route number.\n");
        else
          ship->merchant = j;
      }
      break;
    case ORD_SPEE:
      if (speed_rating(ship))
      {
        j = atoi(args[3]);
        if (j < 0)
          notify(Playernum, Governor, "Specify a positive speed.\n");
        else
        {
          if (j > speed_rating(ship))
            j = speed_rating(ship);
          ship->speed = j;
        }
      }
      else
        notify(Playernum, Governor,
               "This ship does not have a speed rating.\n");
      break;
    case ORD_SALV:
      if (can_bombard(ship))
      {
        j = atoi(args[3]);
        if (j < 0)
          notify(Playernum, Governor, "Specify a positive number of guns.\n");
        else
        {
          if (ship->guns == PRIMARY && j > ship->primary)
            j = ship->primary;
          else if (ship->guns == SECONDARY && j > ship->secondary)
            j = ship->secondary;
          else if (ship->guns == NONE)
            j = 0;
          ship->retaliate = j;
        }
      }
      else
        notify(Playernum, Governor, "This ship cannot be set a salvo.\n");
      break;
    case ORD_PRIM:
      if (ship->primary)
      {
        if (argn < 4)
        {
          ship->guns = PRIMARY;
          if (ship->retaliate > ship->primary)
            ship->retaliate = ship->primary;
        }
        else
        {
          j = atoi(args[3]);
          if (j < 0)
            notify(Playernum, Governor,
                   "Specify a nonnegative number of guns.\n");
          else
          {
            if (j > ship->primary)
              j = ship->primary;
            ship->retaliate = j;
            ship->guns = PRIMARY;
          }
        }
      }
      else
        notify(Playernum, Governor, "This ship does not have primary guns.\n");
      break;
    case ORD_SECO:
      if (ship->secondary)
      {
        if (argn < 4)
        {
          ship->guns = SECONDARY;
          if (ship->retaliate > ship->secondary)
            ship->retaliate = ship->secondary;
        }
        else
        {
          j = atoi(args[3]);
          if (j < 0)
            notify(Playernum, Governor,
                   "Specify a nonnegative number of guns.\n");
          else
          {
            if (j > ship->secondary)
              j = ship->secondary;
            ship->retaliate = j;
            ship->guns = SECONDARY;
          }
        }
      }
      else
        notify(Playernum, Governor,
               "This ship does not have secondary guns.\n");
      break;
    case ORD_EXPL:
      switch (ship->type)
      {
        case STYPE_MINEF:
        case OTYPE_GR:
          ship->mode = 0;
          break;
        default:
          return;
      }
      break;
    case ORD_RADI:
      switch (ship->type)
      {
        case STYPE_MINEF:
        case OTYPE_GR:
          ship->mode = 1;
          break;
        default:
          return;
      }
      break;
    case ORD_MOVE:
      if ((ship->type == OTYPE_TERRA) || (ship->type == OTYPE_PLOW))
      {
        i = 0;
        while (args[3][i])
        {
          /* 
           * Make sure the list of moves is short
           * enough.
           */
          if (i == SHIP_NAMESIZE - 1)
          {
            sprintf(buf, "Warning: that is more than %d moves.\n",
                    SHIP_NAMESIZE - 1);
            notify(Playernum, Governor, buf);
            notify(Playernum, Governor,
                   "These move orders have been truncated.\n");
            args[3][i] = '\0';
            break;
          }
          /* Make sure this move is OK. */
          if ((args[3][i] == 'c') || (args[3][i] == 's'))
          {
            if ((i == 0) && (args[3][0] == 'c'))
            {
              notify(Playernum, Governor,
                     "Cycling move orders can not be empty!\n");
              return;
            }
            if (args[3][i + 1])
            {
              sprintf(buf,
                      "Warning: '%c' should be the last character in the move order.\n",
                      args[3][i]);
              notify(Playernum, Governor, buf);
              notify(Playernum, Governor,
                     "These move orders have been truncated.\n");
              args[3][++i] = '\0';
              break;
            }
          }
          else if ((args[3][i] < '1') || ('9' < args[3][i]))
          {
            sprintf(buf, "'%c' is not a valid move direction.\n", args[3][i]);
            notify(Playernum, Governor, buf);
            return;
          }
          i++;
        }
        if (i == 0)             /* The move list might be empty.. */
          strcpy(ship->class, "5");
        else
          strcpy(ship->class, args[3]);
        /* 
         * This is the index keeping track of which order in
         * class is next.
         */
        ship->special.terraform.index = 0;
      }
      else
        notify(Playernum, Governor,
               "That ship is not a terraformer or a space plow.\n");
      break;
    case ORD_TRIG:
      if (ship->type == STYPE_MINEF)
      {
        if (atoi(args[3]) < 0)
          ship->special.trigger.radius = 0;
        else
          ship->special.trigger.radius = atoi(args[3]);
      }
      else
        notify(Playernum, Governor,
               "This ship cannot be assigned a trigger radius.\n");
      break;
    case ORD_DISP:
      if (ship->type == STYPE_MINEF)
      {
        if (ship->special.trigger.disperse)
          ship->special.trigger.disperse = FALSE;
        else if (!ship->special.trigger.disperse)
          ship->special.trigger.disperse = TRUE;
      }
      break;
    case ORD_TRAN:
      if (ship->type == OTYPE_TRANSDEV)
      {
        ship->special.transport.target = atoi(args[3]);
        if (ship->special.transport.target == ship->number)
        {
          notify(Playernum, Governor,
                 "A transporter cannot transport to itself.");
          ship->special.transport.target = 0;
        }
        else
        {
          sprintf(buf, "Target ship is %d.\n", ship->special.transport.target);
          notify(Playernum, Governor, buf);
        }
      }
      else
        notify(Playernum, Governor, "This ship is not a transporter.\n");
      break;
    case ORD_AIM:
      /* any ship that flys can aim now. Tim Brown */
      /* there was no point, nothing was coded for it, changed back -mfw */
      if (can_aim(ship))
      {
        if (ship->type == OTYPE_GTELE || ship->type == OTYPE_TRACT ||
            ship->fuel >= FUEL_MANEUVER)
        {
          if (ship->type == STYPE_MIRROR && ship->docked)
          {
            notify(Playernum, Governor,
                   "docked; use undock or launch first.\n");
          }
          else
          {
            pl = Getplace(Playernum, Governor, args[3], 1);
            if (pl.err)
            {
              notify(Playernum, Governor, "Error in destination.\n");
            }
            else
            {
              if (get_num_updates() < CombatUpdate && ship->type == STYPE_MIRROR
                  && pl.level == LEVEL_SHIP)
              {
                sprintf(buf,
                        "You may not aim this type of ship at another ship until after the COMBAT UPDATE [%d]\n",
                        CombatUpdate);
                notify(Playernum, Governor, buf);
              }
              else
              {
                ship->special.aimed_at.level = pl.level;
                ship->special.aimed_at.pnum = pl.pnum;
                ship->special.aimed_at.snum = pl.snum;
                ship->special.aimed_at.shipno = pl.shipno;

                if (ship->type != OTYPE_TRACT && ship->type != OTYPE_GTELE)
                  use_fuel(ship, FUEL_MANEUVER);

                if (ship->type == OTYPE_GTELE || ship->type == OTYPE_STELE)
                  mk_expl_aimed_at(Playernum, Governor, ship);

                sprintf(buf, "Aimed at %s\n",
                        prin_aimed_at(Playernum, Governor, ship));
                notify(Playernum, Governor, buf);
              }                 /* if mirror */
            }
          }
        }
        else
        {
          sprintf(buf, "Not enough maneuvering fuel (%.2f).\n", FUEL_MANEUVER);
          notify(Playernum, Governor, buf);
          return;
        }
      }
      else
      {
        notify(Playernum, Governor, "You can't aim that kind of ship.\n");
      }
      break;

    case ORD_INTE:
      if (ship->type == STYPE_MIRROR)
        ship->special.aimed_at.intensity = MAX(0, MIN(100, atoi(args[3])));
      break;
    case ORD_ON:
      if (!has_switch(ship))
      {
        notify(Playernum, Governor,
               "This ship does not have an on/off setting.\n");
      }
      else
      {
        if (ship->damage && ship->type != OTYPE_FACTORY)
        {
          notify(Playernum, Governor, "Damaged ships cannot be activated.\n");
          return;
        }
        if (ship->on)
        {
          notify(Playernum, Governor, "This ship is already activated.\n");
          return;
        }
        if (ship->type == OTYPE_FACTORY)
        {
          unsigned int    oncost;

          /* HUTm (kse) if ship type to build is not specified factory should
           * not be turned on */
          if (!ship->build_type || ship->build_type == OTYPE_FACTORY)
          {
            notify(Playernum, Governor, "No ship type specified.\n");
            return;
          }
          else
          {
            if (ship->whatorbits == LEVEL_SHIP)
            {
              shiptype       *s2;
              int             hangerneeded;

              getship(&s2, (int)ship->destshipno);
              if (s2->type == STYPE_HABITAT)
              {
                oncost = HAB_FACT_ON_COST * ship->build_cost;
                if (s2->resource < oncost)
                {
                  sprintf(buf,
                          "You don't have %d resources on Habitat #%d to activate this factory.\n",
                          oncost, ship->destshipno);
                  notify(Playernum, Governor, buf);
                  free((char *)s2);
                  return;
                }
                hangerneeded =
                  (1 + (int)(HAB_FACT_SIZE * (double)ship_size(ship))) -
                  ((s2->max_hanger - s2->hanger) + ship->size);
                if (hangerneeded > 0)
                {
                  sprintf(buf,
                          "Not enough hanger space free on Habitat #%d. Need %d more.\n",
                          ship->destshipno, hangerneeded);
                  notify(Playernum, Governor, buf);
                  free((char *)s2);
                  return;
                }
                s2->resource -= oncost;
                s2->hanger -= (unsigned short)ship->size;
                ship->size = 1 + (int)(HAB_FACT_SIZE * (double)ship_size(ship));
                s2->hanger += (unsigned short)ship->size;
                putship(s2);
                free((char *)s2);
              }
              else
              {
                notify(Playernum, Governor,
                       "The factory is currently being transported.\n");
                free((char *)s2);
                return;
              }
            }
            else if (!landed(ship))
            {
              notify(Playernum, Governor,
                     "You cannot activate the factory here.\n");
              return;
            }
            else
            {
              getplanet(&planet, (int)ship->deststar, (int)ship->destpnum);
              oncost = 2 * ship->build_cost;
              if (planet->info[Playernum - 1].resource < oncost)
              {
                sprintf(buf,
                        "You don't have %d resources on the planet to activate this factory.\n",
                        oncost);
                notify(Playernum, Governor, buf);
                free((char *)planet);
                return;
              }
              if (!ship->build_type)
              {
                sprintf(buf, "Ship has not been told what to build yet\n");
                notify(Playernum, Governor, buf);
                free((char *)planet);
                return;
              }
              else
              {
                planet->info[Playernum - 1].resource -= oncost;
                putplanet(planet, (int)ship->deststar, (int)ship->destpnum);
                free((char *)planet);
              }
            }
            sprintf(buf, "Factory activated at a cost of %d resources.\n",
                    oncost);
            notify(Playernum, Governor, buf);
          }
        }
        ship->on = 1;
      }
      break;
    case ORD_OFF:
      if (ship->type == OTYPE_FACTORY && ship->on)
      {
        notify(Playernum, Governor,
               "You can't deactivate a factory once it's online. Consider using 'scrap'.\n");
      }
#ifdef USE_VN
      else if (ship->type == OTYPE_VN && ship->on)
      {
        notify(Playernum, Governor,
               "VNs may not be switched off once activated.\n");
      }
#endif
      else
      {
        ship->on = 0;
      }
      break;
    case ORD_LIMI:
      if (argn >= 4)
        ship->limit = MAX(0, MIN(100, atoi(args[3])));
      else
        ship->limit = 100;
      break;
    case ORD_STOC:
      if (argn >= 4)
      {
        if (match(args[3], "on"))
          ship->use_stock = 1;
        else
          ship->use_stock = 0;
      }
      else
        ship->use_stock = ship->use_stock ? 0 : 1;
      break;
    case ORD_HOP:
      if (argn >= 4)
      {
        if (match(args[3], "on"))
          ship->hop = 1;
        else
          ship->hop = 0;
      }
      else
        ship->hop = ship->hop ? 0 : 1;
      break;

    case ORD_FLEET:            /* Handle fleet orders -mfw */
      if (argn >= 4)
      {
        char            cf;
        int             fl;

        if (args[3][0] == '%')
          cf = args[3][1];
        else
          cf = args[3][0];

        fl = fctofi(cf);

        if (fl > 0 && races[Playernum - 1]->fleet[fl].admiral != Governor &&
            races[Playernum - 1]->fleet[fl].flagship != 0)
        {
          notify(Playernum, Governor,
                 "You're not admiral of the destination fleet.\n");
          break;
        }

        if (fl < 1 || fl > MAXFLEETS)
        {
          /* arg 0, remove from fleet */
          remove_sh_fleet(Playernum, Governor, ship);
        }
        else
        {
          if (ship->fleetmember)
          {
            /* It's already in a fleet, remove it first */
            remove_sh_fleet(Playernum, Governor, ship);
          }

          /* Add ship to fleet */
          insert_sh_fleet(Playernum, Governor, ship, fl);
        }
      }
      else
      {
        /* No arguements, remove it. */
        remove_sh_fleet(Playernum, Governor, ship);
      }
      break;
  }

  ship->notified = 0;
  putship(ship);
}

const char     *
prin_aimed_at(int Playernum, int Governor, shiptype * ship)
{
  placetype       targ;

  targ.level = ship->special.aimed_at.level;
  targ.snum = ship->special.aimed_at.snum;
  targ.pnum = ship->special.aimed_at.pnum;
  targ.shipno = ship->special.aimed_at.shipno;

  return Dispplace(Playernum, Governor, &targ);
}

const char     *
prin_ship_dest(int Playernum, int Governor, shiptype * ship)
{
  placetype       dest;

  dest.level = ship->whatdest;
  dest.snum = ship->deststar;
  dest.pnum = ship->destpnum;
  dest.shipno = ship->destshipno;

  return Dispplace(Playernum, Governor, &dest);
}

/* 
 * mark wherever the ship is aimed at, as explored by the owning player.
 */
void
mk_expl_aimed_at(int Playernum, int Governor, shiptype * s)
{
  double          dist;
  startype       *str;
  planettype     *p;
  double          xf, yf;

  str = Stars[s->special.aimed_at.snum];

  xf = s->xpos;
  yf = s->ypos;

  switch (s->special.aimed_at.level)
  {
    case LEVEL_UNIV:
      sprintf(buf, "There is nothing out here to aim at.");
      notify(Playernum, Governor, buf);
      break;
    case LEVEL_STAR:
      sprintf(buf, "Star %s ", prin_aimed_at(Playernum, Governor, s));
      notify(Playernum, Governor, buf);
      if ((dist =
           sqrt(Distsq(xf, yf, str->xpos, str->ypos))) <=
          tele_range((int)s->type, s->tech))
      {
        getstar(&str, (int)s->special.aimed_at.snum);
        setbit(str->explored, Playernum);
        putstar(str, (int)s->special.aimed_at.snum);
        sprintf(buf, "Surveyed, distance %g.\n", dist);
        notify(Playernum, Governor, buf);
        free((char *)str);
      }
      else
      {
        sprintf(buf, "Too far to see (%g, max %g).\n", dist,
                tele_range((int)s->type, s->tech));
        notify(Playernum, Governor, buf);
      }
      break;
    case LEVEL_PLAN:
      sprintf(buf, "Planet %s ", prin_aimed_at(Playernum, Governor, s));
      notify(Playernum, Governor, buf);
      getplanet(&p, (int)s->special.aimed_at.snum,
                (int)s->special.aimed_at.pnum);
      if ((dist =
           sqrt(Distsq(xf, yf, str->xpos + p->xpos, str->ypos + p->ypos))) <=
          tele_range((int)s->type, s->tech))
      {
        setbit(str->explored, Playernum);
        p->info[Playernum - 1].explored = 1;
        putplanet(p, (int)s->special.aimed_at.snum,
                  (int)s->special.aimed_at.pnum);
        sprintf(buf, "Surveyed, distance %g.\n", dist);
        notify(Playernum, Governor, buf);
      }
      else
      {
        sprintf(buf, "Too far to see (%g, max %g).\n", dist,
                tele_range((int)s->type, s->tech));
        notify(Playernum, Governor, buf);
      }
      free((char *)p);
      break;
    case LEVEL_SHIP:
      sprintf(buf, "You can't see anything of use there.\n");
      notify(Playernum, Governor, buf);
      break;
  }
}

void
DispOrdersHeader(int Playernum, int Governor)
{
  notify(Playernum, Governor,
         "    #       name   gov sp orbits     destin     options\n");
}

void
DispOrders(int Playernum, int Governor, shiptype * ship)
{
#ifdef THRESHLOADING
  int             i;
#endif
  struct inf_setting *infs;
  char            mtemp[2048], itemp[256];
  planettype     *p;

  if ((!races[Playernum - 1]->God && ship->owner != Playernum) ||
      (!races[Playernum - 1]->God && !authorized(Governor, ship)) ||
      !ship->alive)
    return;

  if (ship->docked)
    if (ship->whatdest == LEVEL_SHIP)
      sprintf(temp, "D#%d", ship->destshipno);
    else
      sprintf(temp, "L%2d,%-2d", ship->land_x, ship->land_y);
  else
    strcpy(temp, prin_ship_dest_brief(Playernum, Governor, ship));

  sprintf(buf, "%5d %c %11.11s %d %c%1u %-10s %-10.10s ", ship->number,
          Shipltrs[ship->type], ship->name, ship->governor,
          ship->hyper_drive.has ? (ship->
                                   mount ? (ship->
                                            mounted ? '+' : '-') : '*') : ' ',
          ship->speed, Dispshiploc_brief(ship), temp);
  notify(Playernum, Governor, buf);

  memset(buf, 0, sizeof (buf));
  buf[0] = '\0';

  if (ship->fleetmember)
  {
    sprintf(temp, "/fleet %c", fitofc(ship->fleetmember));
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->hyper_drive.on)
  {
    sprintf(temp, "/jump %s %d",
            (ship->hyper_drive.ready ? "ready" : "charging"),
            ship->hyper_drive.charge);
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->cloaked)
  {
    if (!ship->cloaking)
    {
      sprintf(temp, "/decloaking");
      AddOrderToString(Playernum, Governor, temp);
    }
    else
    {
      sprintf(temp, "/cloaked");
      AddOrderToString(Playernum, Governor, temp);
    }
  }
  else if (ship->cloaking)
  {
    sprintf(temp, "/cloaking");
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->wants_reports)
  {
    sprintf(temp, "/report");
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->protect.self)
  {
    sprintf(temp, "/retal");
    AddOrderToString(Playernum, Governor, temp);
  }
  /* smart gun from Hap -mfw */
  if (ship->smart_gun && ship->smart_list[0])
  {
    sprintf(temp, "/smartgun %s %d %s", ship->smart_list, ship->smart_strength,
            (ship->smart_gun == PRIMARY) ? "primary" : "secondary");
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->guns == PRIMARY)
  {
    switch (ship->primtype)
    {
      case LIGHT:
        sprintf(temp, "/lgt primary");
        break;
      case MEDIUM:
        sprintf(temp, "/med primary");
        break;
      case HEAVY:
        sprintf(temp, "/hvy primary");
        break;
      default:
        sprintf(temp, "/none");
    }
    AddOrderToString(Playernum, Governor, temp);
  }
  else if (ship->guns == SECONDARY)
  {
    switch (ship->sectype)
    {
      case LIGHT:
        sprintf(temp, "/lgt secondary");
        break;
      case MEDIUM:
        sprintf(temp, "/med secndry");
        break;
      case HEAVY:
        sprintf(temp, "/hvy secndry");
        break;
      default:
        sprintf(temp, "/none");
    }
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->fire_laser)
  {
    sprintf(temp, "/laser %d", ship->fire_laser);
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->focus)
  {
    sprintf(temp, "/focus");
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->retaliate)
  {
    sprintf(temp, "/salvo %d", ship->retaliate);
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->protect.planet)
  {
    sprintf(temp, "/defense");
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->protect.on)
  {
    sprintf(temp, "/prot %d", ship->protect.ship);
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->navigate.on)
  {
    sprintf(temp, "/nav %d (%d)", ship->navigate.bearing, ship->navigate.turns);
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->merchant)
  {
    sprintf(temp, "/merchant %d", ship->merchant);
    AddOrderToString(Playernum, Governor, temp);
  }
  if (has_switch(ship))
  {
    if (ship->on)
      sprintf(temp, "/on");
    else
      sprintf(temp, "/off");
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->protect.evade)
  {
    sprintf(temp, "/evade");
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->bombard)
  {
    sprintf(temp, "/bomb");
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->limit != 100)
  {
    sprintf(temp, "/limit %d", ship->limit);
    AddOrderToString(Playernum, Governor, temp);
  }
  if (!ship->use_stock)
  {
    sprintf(temp, "/no stockpile");
    AddOrderToString(Playernum, Governor, temp);
  }
  if (!ship->hop)
  {
    sprintf(temp, "/no hop");
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->type == STYPE_MINEF || ship->type == OTYPE_GR)
  {
    if (ship->mode)
      sprintf(temp, "/radiate");
    else
      sprintf(temp, "/explode");
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->type == OTYPE_TERRA || ship->type == OTYPE_PLOW)
  {
    int             i;

    sprintf(temp, "/move %s", &(ship->class[ship->special.terraform.index]));
    if (temp[i = (strlen(temp) - 1)] == 'c')
    {
      char            c = ship->class[ship->special.terraform.index];

      ship->class[ship->special.terraform.index] = '\0';
      sprintf(temp + i, "%sc", ship->class);
      ship->class[ship->special.terraform.index] = c;
    }
    temp[27] = '+';
    temp[28] = '\0';
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->type == STYPE_MISSILE && ship->whatdest == LEVEL_PLAN)
  {
    if (ship->special.impact.scatter)
    {
      sprintf(temp, "/scatter");
      AddOrderToString(Playernum, Governor, temp);
    }
    else
    {
      sprintf(temp, "/impact %d,%d", ship->special.impact.x,
              ship->special.impact.y);
      AddOrderToString(Playernum, Governor, temp);
    }
  }
  if (ship->type == STYPE_MINEF)
  {
    sprintf(temp, "/trigger %d", ship->special.trigger.radius);
    AddOrderToString(Playernum, Governor, temp);
    if (ship->special.trigger.disperse)
    {
      sprintf(temp, "/disperse");
      AddOrderToString(Playernum, Governor, temp);
    }
  }
  if (ship->type == OTYPE_TRANSDEV)
  {
    sprintf(temp, "/target %d", ship->special.transport.target);
    AddOrderToString(Playernum, Governor, temp);
  }
  if (ship->type == STYPE_MIRROR)
  {
    sprintf(temp, "/aim %s/int %d", prin_aimed_at(Playernum, Governor, ship),
            ship->special.aimed_at.intensity);
    AddOrderToString(Playernum, Governor, temp);
  }
#ifdef AUTOSCRAP
  if (ship->autoscrap)
  {
    sprintf(temp, "%s", "/autoscrap");
    AddOrderToString(Playernum, Governor, temp);
  }
#endif
#ifdef THRESHLOADING
  for (i = 0; i <= TH_CRYSTALS; i++)
  {
    if (ship->threshload[i])
    {
      char            c;

      if (i == TH_RESOURCE)
        c = 'r';
      else if (i == TH_DESTRUCT)
        c = 'd';
      else if (i == TH_FUEL)
        c = 'f';
      else
        c = 'x';
      sprintf(temp, "/%c%d", c, ship->threshload[i]);
      AddOrderToString(Playernum, Governor, temp);
    }
  }
#endif

  strcat(buf, "/\n");
  notify(Playernum, Governor, buf);

  if (ship->type == OTYPE_INF)
  {
    getplanet(&p, (int)ship->storbits, (int)ship->pnumorbits);

    sprintf(mtemp, "\nInfrastructure Settings:\n\
Eff Setting: %d, Fert Setting: %d, Atmos Setting: %d\n\
Reports: %c, Switch: %s\n\
Planet resource reserve: %d\n\
Planet fuel reserve:     %d\n", ship->inf.eff_setting, ship->inf.fert_setting, ship->inf.atmos_setting, (char)(ship->inf.wants_reports ? 'Y' : 'N'), (char *)(ship->on ? "ON" : "OFF"), p->info[ship->owner - 1].res_reserve, p->info[ship->owner - 1].fuel_reserve);

    for (i = 0; i < INF_MAX_TARGETS; i++)
    {
      infs = &(ship->inf.eff_targets[i]);

      if (infs->x != 999)
      {
        sprintf(itemp, "Eff Target: %d,%d and limit:%d%%\n", infs->x, infs->y,
                infs->max);
        strcat(mtemp, itemp);
      }
    }

    for (i = 0; i < INF_MAX_TARGETS; i++)
    {
      infs = &(ship->inf.fert_targets[i]);

      if (infs->x != 999)
      {
        sprintf(itemp, "Fert Target: %d,%d and limit:%d%%\n", infs->x, infs->y,
                infs->max);
        strcat(mtemp, itemp);
      }
    }

    free((char *)p);
    notify(Playernum, Governor, mtemp);
  }

  /* 
   * if hyper space is on estimate how much fuel it will cost to get to
   * the destination
   */
  if (ship->hyper_drive.on)
  {
    double          dist, fuse;

    dist =
      sqrt(Distsq
           (ship->xpos, ship->ypos, Stars[ship->deststar]->xpos,
            Stars[ship->deststar]->ypos));

    fuse = calc_fuse(ship, dist);

    sprintf(buf, "  *** distance %.0f - jump will cost at least %.1ff ***\n",
            dist, fuse);
    notify(Playernum, Governor, buf);
    if (ship->max_fuel < fuse)
      notify(Playernum, Governor,
             "Your ship cannot carry enough fuel to do this jump.\n");
  }
}

int
AddOrderToString(int Playernum, int Governor, char *str2add)
{
  char            buf9[80];

  sprintf(buf9, "%s%s", buf, str2add);
  if (strlen(buf9) > 30)
  {
    strcat(buf, "/\n                                                ");
    notify(Playernum, Governor, buf);
    memset(buf, 0, sizeof (buf));
    sprintf(buf, "%s", str2add);
  }
  else
    strcat(buf, str2add);

  return 1;
}

void
route(int Playernum, int Governor, int APcount)
{
  int             i, x, y;
  unsigned char   star, planet, load, unload;
  char           *c;
  planettype     *p;
  placetype       where;

  if (Dir[Playernum - 1][Governor].level != LEVEL_PLAN)
  {
    notify(Playernum, Governor,
           "You have to 'cs' to a planet to examine routes.\n");
    return;
  }
  getplanet(&p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);
  if (argn == 1)
  {                             /* display all shipping routes that are *
                                 * active */
    for (i = 1; i <= MAX_ROUTES; i++)
      if (p->info[Playernum - 1].route[i - 1].set)
      {
        star = p->info[Playernum - 1].route[i - 1].dest_star;
        planet = p->info[Playernum - 1].route[i - 1].dest_planet;
        load = p->info[Playernum - 1].route[i - 1].load;
        unload = p->info[Playernum - 1].route[i - 1].unload;
        sprintf(buf, "%2d  land %2d,%2d   ", i,
                p->info[Playernum - 1].route[i - 1].x,
                p->info[Playernum - 1].route[i - 1].y);
        strcat(buf, "load: ");
        if (Fuel(load))
          strcat(buf, "f");
        else
          strcat(buf, " ");
        if (Destruct(load))
          strcat(buf, "d");
        else
          strcat(buf, " ");
        if (Resources(load))
          strcat(buf, "r");
        else
          strcat(buf, " ");
        if (Crystals(load))
          strcat(buf, "x");
        else
          strcat(buf, " ");
        if (Military(load))
          strcat(buf, "m");
        else
          strcat(buf, " ");

        strcat(buf, "  unload: ");
        if (Fuel(unload))
          strcat(buf, "f");
        else
          strcat(buf, " ");
        if (Destruct(unload))
          strcat(buf, "d");
        else
          strcat(buf, " ");
        if (Resources(unload))
          strcat(buf, "r");
        else
          strcat(buf, " ");
        if (Crystals(unload))
          strcat(buf, "x");
        else
          strcat(buf, " ");
        if (Military(unload))
          strcat(buf, "m");
        else
          strcat(buf, " ");

        sprintf(temp, "  -> %s/%s\n", Stars[star]->name,
                Stars[star]->pnames[planet]);
        strcat(buf, temp);
        notify(Playernum, Governor, buf);
      }
    notify(Playernum, Governor, "Done.\n");
    free((char *)p);
    return;
  }
  else if (argn == 2)
  {
    sscanf(args[1], "%d", &i);
    if (i > MAX_ROUTES || i < 1)
    {
      notify(Playernum, Governor, "Bad route number.\n");
      free((char *)p);
      return;
    }
    if (p->info[Playernum - 1].route[i - 1].set)
    {
      star = p->info[Playernum - 1].route[i - 1].dest_star;
      planet = p->info[Playernum - 1].route[i - 1].dest_planet;
      load = p->info[Playernum - 1].route[i - 1].load;
      unload = p->info[Playernum - 1].route[i - 1].unload;
      sprintf(buf, "%2d  land %2d,%2d   ", i,
              p->info[Playernum - 1].route[i - 1].x,
              p->info[Playernum - 1].route[i - 1].y);
      if (load)
      {
        sprintf(temp, "load: ");
        strcat(buf, temp);
        if (Fuel(load))
          strcat(buf, "f");
        if (Destruct(load))
          strcat(buf, "d");
        if (Resources(load))
          strcat(buf, "r");
        if (Crystals(load))
          strcat(buf, "x");
        if (Military(load))
          strcat(buf, "m");
      }
      if (unload)
      {
        sprintf(temp, "  unload: ");
        strcat(buf, temp);
        if (Fuel(unload))
          strcat(buf, "f");
        if (Destruct(unload))
          strcat(buf, "d");
        if (Resources(unload))
          strcat(buf, "r");
        if (Crystals(unload))
          strcat(buf, "x");
        if (Military(unload))
          strcat(buf, "m");
      }
      sprintf(temp, "  ->  %s/%s\n", Stars[star]->name,
              Stars[star]->pnames[planet]);
      strcat(buf, temp);
      notify(Playernum, Governor, buf);
    }
    notify(Playernum, Governor, "Done.\n");
    free((char *)p);
    return;
  }
  else if (argn == 3)
  {
    sscanf(args[1], "%d", &i);
    if (i > MAX_ROUTES || i < 1)
    {
      notify(Playernum, Governor, "Bad route number.\n");
      free((char *)p);
      return;
    }
    if (match(args[2], "activate"))
      p->info[Playernum - 1].route[i - 1].set = 1;
    else if (match(args[2], "deactivate"))
      p->info[Playernum - 1].route[i - 1].set = 0;
    else
    {
      where = Getplace(Playernum, Governor, args[2], 1);
      if (!where.err)
      {
        if (where.level != LEVEL_PLAN)
        {
          notify(Playernum, Governor, "You have to designate a planet.\n");
          free((char *)p);
          return;
        }
        p->info[Playernum - 1].route[i - 1].dest_star = where.snum;
        p->info[Playernum - 1].route[i - 1].dest_planet = where.pnum;
        notify(Playernum, Governor, "Set.\n");
      }
      else
      {
        notify(Playernum, Governor, "Illegal destination.\n");
        free((char *)p);
        return;
      }
    }
  }
  else
  {
    sscanf(args[1], "%d", &i);
    if (i > MAX_ROUTES || i < 1)
    {
      notify(Playernum, Governor, "Bad route number.\n");
      free((char *)p);
      return;
    }
    if (match(args[2], "land"))
    {
      sscanf(args[3], "%d,%d", &x, &y);
      if (x < 0 || x > p->Maxx - 1 || y < 0 || y > p->Maxy - 1)
      {
        notify(Playernum, Governor, "Bad sector coordinates.\n");
        free((char *)p);
        return;
      }
      p->info[Playernum - 1].route[i - 1].x = x;
      p->info[Playernum - 1].route[i - 1].y = y;
    }
    else if (match(args[2], "load"))
    {
      p->info[Playernum - 1].route[i - 1].load = 0;
      c = args[3];
      while (*c)
      {
        if (*c == 'f')
          p->info[Playernum - 1].route[i - 1].load |= M_FUEL;
        if (*c == 'd')
          p->info[Playernum - 1].route[i - 1].load |= M_DESTRUCT;
        if (*c == 'r')
          p->info[Playernum - 1].route[i - 1].load |= M_RESOURCES;
        if (*c == 'x')
          p->info[Playernum - 1].route[i - 1].load |= M_CRYSTALS;
        if (*c == 'm')
          p->info[Playernum - 1].route[i - 1].load |= M_MILITARY;
        c++;
      }
    }
    else if (match(args[2], "unload"))
    {
      p->info[Playernum - 1].route[i - 1].unload = 0;
      c = args[3];
      while (*c)
      {
        if (*c == 'f')
          p->info[Playernum - 1].route[i - 1].unload |= M_FUEL;
        if (*c == 'd')
          p->info[Playernum - 1].route[i - 1].unload |= M_DESTRUCT;
        if (*c == 'r')
          p->info[Playernum - 1].route[i - 1].unload |= M_RESOURCES;
        if (*c == 'x')
          p->info[Playernum - 1].route[i - 1].unload |= M_CRYSTALS;
        if (*c == 'm')
          p->info[Playernum - 1].route[i - 1].unload |= M_MILITARY;
        c++;
      }
    }
    else
    {
      notify(Playernum, Governor, "What are you trying to do?\n");
      free((char *)p);
      return;
    }
    notify(Playernum, Governor, "Set.\n");
  }

  putplanet(p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);
  free((char *)p);
}

const char     *
prin_ship_dest_brief(int Playernum, int Governor, shiptype * ship)
{
  placetype       dest;

  dest.level = ship->whatdest;
  dest.snum = ship->deststar;
  dest.pnum = ship->destpnum;
  dest.shipno = ship->destshipno;

  return Dispplace_brief(Playernum, Governor, &dest);
}

int
get_order_type(char *ord)
{
  if (match(ord, "inf"))
    return ORD_INF;
  if (match(ord, "report"))
    return ORD_REPORT;
  if (match(ord, "cloak"))
    return ORD_CLOAK;
  if (match(ord, "defense"))
    return ORD_DEFE;
  if (match(ord, "scatter"))
    return ORD_SCAT;
  if (match(ord, "impact"))
    return ORD_IMPA;
  if (match(ord, "jump"))
    return ORD_JUMP;
  if (match(ord, "threshload"))
    return ORD_THRE;
  if (match(ord, "autoscrap"))
    return ORD_AUTO;
  if (match(ord, "protect"))
    return ORD_PROT;
  if (match(ord, "navigate"))
    return ORD_NAVI;
  if (match(ord, "switch"))
    return ORD_SWIT;
  if (match(ord, "destination"))
    return ORD_DEST;
  if (match(ord, "evade"))
    return ORD_EVAD;
  if (match(ord, "bombard"))
    return ORD_BOMB;
  if (match(ord, "retaliate"))
    return ORD_RETA;
  if (match(ord, "focus"))
    return ORD_FOCU;
  if (match(ord, "laser"))
    return ORD_LASE;
  if (match(ord, "merchant"))
    return ORD_MERC;
  if (match(ord, "speed"))
    return ORD_SPEE;
  if (match(ord, "salvo"))
    return ORD_SALV;
  if (match(ord, "primary"))
    return ORD_PRIM;
  if (match(ord, "secondary"))
    return ORD_SECO;
  if (match(ord, "explosive"))
    return ORD_EXPL;
  if (match(ord, "radiative"))
    return ORD_RADI;
  if (match(ord, "move"))
    return ORD_MOVE;
  if (match(ord, "trigger"))
    return ORD_TRIG;
  if (match(ord, "disperse"))
    return ORD_DISP;
  if (match(ord, "transport"))
    return ORD_TRAN;
  if (match(ord, "aim"))
    return ORD_AIM;
  if (match(ord, "intensity"))
    return ORD_INTE;
  if (match(ord, "on"))
    return ORD_ON;
  if (match(ord, "off"))
    return ORD_OFF;
  if (match(ord, "stockpile"))
    return ORD_STOC;
  if (match(ord, "limit"))
    return ORD_LIMI;
  if (match(ord, "hop"))
    return ORD_HOP;
  if (match(ord, "fleet"))
    return ORD_FLEET;
  if (match(ord, "smart"))
    return ORD_SMART;

  return ORD_NULL;
}
