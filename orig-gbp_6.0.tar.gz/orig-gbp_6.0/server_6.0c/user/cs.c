/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)cs.c  1.8 12/3/93 "
 * 
 * cs.c -- change scope (directory)
 *
 * $Header: /var/cvs/gbp/GB+/user/cs.c,v 1.4 2007/07/06 18:09:34 gbp Exp $
 */

#include <stdlib.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"
#include "proto.h"

void
center(int Playernum, int Governor, int APcount)
{
  placetype       where;
  planettype     *planet;

  where = Getplace(Playernum, Governor, args[1], 1);

  if (where.err)
  {
    sprintf(buf, "cs: bad scope.\n");
    notify(Playernum, Governor, buf);
    return;
  }

  if (argn == 1)
  {
    if (where.level == LEVEL_STAR)
    {
      Dir[Playernum - 1][Governor].lastx[0] = 0.0;
      Dir[Playernum - 1][Governor].lasty[0] = 0.0;
      notify(Playernum, Governor, "Center point reset at this scope.\n");
    }
    else if (where.level == LEVEL_UNIV)
    {
      Dir[Playernum - 1][Governor].lastx[1] = 0.0;
      Dir[Playernum - 1][Governor].lasty[1] = 0.0;
      notify(Playernum, Governor, "Center point reset at this scope.\n");
    }
    else
    {
      notify(Playernum, Governor, "That does nothing at this scope.\n");
    }

    return;
  }

  if (where.level == LEVEL_SHIP)
  {
    /* do not allow centering off ships, could be used to cheat */
    notify(Playernum, Governor, "You may not center off ships.\n");
    return;
  }
  else if (where.level == LEVEL_PLAN)
  {
    if (where.snum != Dir[Playernum - 1][Governor].snum)
    {
      notify(Playernum, Governor, "That planet must be at this scope.\n");
      return;
    }

    where = Getplace(Playernum, Governor, args[1], 1);

    getplanet(&planet, where.snum, where.pnum);

    Dir[Playernum - 1][Governor].lastx[0] = planet->xpos;
    Dir[Playernum - 1][Governor].lasty[0] = planet->ypos;

    free((char *)planet);

    sprintf(buf, "orbit now centered off planet %s\n",
            Stars[where.snum]->pnames[where.pnum]);
    notify(Playernum, Governor, buf);

  }
  else if (where.level == LEVEL_STAR)
  {
    Dir[Playernum - 1][Governor].lastx[1] = Stars[where.snum]->xpos;
    Dir[Playernum - 1][Governor].lasty[1] = Stars[where.snum]->ypos;
    sprintf(buf, "orbit now centered off star %s\n", Stars[where.snum]->name);
    notify(Playernum, Governor, buf);
  }
  else if (where.level == LEVEL_UNIV)
  {
    notify(Playernum, Governor, "Nothing to center off at that scope.\n");
  }
  else
  {
    notify(Playernum, Governor, "Scope error in center command.\n");
  }

  return;
}

void
do_prompt(int Playernum, int Governor)
{
  shiptype       *s, *s2;

  if (client_can_understand(Playernum, Governor, CSP_SCOPE_COMMAND))
    CSP_prompt(Playernum, Governor);
  else
  {
    if (Dir[Playernum - 1][Governor].level == LEVEL_UNIV)
    {
      sprintf(Dir[Playernum - 1][Governor].prompt, " ( [%d] / )\n",
              Sdata.AP[Playernum - 1]);
    }
    else if (Dir[Playernum - 1][Governor].level == LEVEL_STAR)
    {
      sprintf(Dir[Playernum - 1][Governor].prompt, " ( [%d] /%s )\n",
              Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1],
              Stars[Dir[Playernum - 1][Governor].snum]->name);
    }
    else if (Dir[Playernum - 1][Governor].level == LEVEL_PLAN)
    {
      sprintf(Dir[Playernum - 1][Governor].prompt, " ( [%d] /%s/%s )\n",
              Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1],
              Stars[Dir[Playernum - 1][Governor].snum]->name,
              Stars[Dir[Playernum - 1][Governor].snum]->
              pnames[Dir[Playernum - 1][Governor].pnum]);
    }
    else if (Dir[Playernum - 1][Governor].level == LEVEL_SHIP)
    {
      (void)getship(&s, Dir[Playernum - 1][Governor].shipno);
      switch (s->whatorbits)
      {
        case LEVEL_UNIV:
          sprintf(Dir[Playernum - 1][Governor].prompt, " ( [%d] /#%d )\n",
                  Sdata.AP[Playernum - 1], Dir[Playernum - 1][Governor].shipno);
          break;
        case LEVEL_STAR:
          sprintf(Dir[Playernum - 1][Governor].prompt, " ( [%d] /%s/#%d )\n",
                  Stars[s->storbits]->AP[Playernum - 1],
                  Stars[s->storbits]->name,
                  Dir[Playernum - 1][Governor].shipno);
          break;
        case LEVEL_PLAN:
          sprintf(Dir[Playernum - 1][Governor].prompt, " ( [%d] /%s/%s/#%d )\n",
                  Stars[s->storbits]->AP[Playernum - 1],
                  Stars[s->storbits]->name,
                  Stars[s->storbits]->pnames[Dir[Playernum - 1][Governor].pnum],
                  Dir[Playernum - 1][Governor].shipno);
          break;
          /* 
           * I put this mess in because of
           * non-functioning prompts when you are in a
           * ship within a ship, or deeper. I am
           * certain this can be done more elegantly (a
           * lot more) but I don't feel like trying
           * that right now. right now I want it to
           * function. Maarten
           */
        case LEVEL_SHIP:
          (void)getship(&s2, (int)s->destshipno);
          switch (s2->whatorbits)
          {
            case LEVEL_UNIV:
              sprintf(Dir[Playernum - 1][Governor].prompt,
                      " ( [%d] /#%d/#%d )\n", Sdata.AP[Playernum - 1],
                      s->destshipno, Dir[Playernum - 1][Governor].shipno);
              break;
            case LEVEL_STAR:
              sprintf(Dir[Playernum - 1][Governor].prompt,
                      " ( [%d] /%s/#%d/#%d )\n",
                      Stars[s->storbits]->AP[Playernum - 1],
                      Stars[s->storbits]->name, s->destshipno,
                      Dir[Playernum - 1][Governor].shipno);
              break;
            case LEVEL_PLAN:
              sprintf(Dir[Playernum - 1][Governor].prompt,
                      " ( [%d] /%s/%s/#%d/#%d )\n",
                      Stars[s->storbits]->AP[Playernum - 1],
                      Stars[s->storbits]->name,
                      Stars[s->storbits]->pnames[Dir[Playernum - 1][Governor].
                                                 pnum], s->destshipno,
                      Dir[Playernum - 1][Governor].shipno);
              break;
            case LEVEL_SHIP:
              while (s2->whatorbits == LEVEL_SHIP)
              {
                free((char *)s2);
                (void)getship(&s2, (int)s2->destshipno);
              }
              switch (s2->whatorbits)
              {
                case LEVEL_UNIV:
                  sprintf(Dir[Playernum - 1][Governor].prompt,
                          " ( [%d] / /../#%d/#%d )\n", Sdata.AP[Playernum - 1],
                          s->destshipno, Dir[Playernum - 1][Governor].shipno);
                  break;
                case LEVEL_STAR:
                  sprintf(Dir[Playernum - 1][Governor].prompt,
                          " ( [%d] /%s/ /../#%d/#%d )\n",
                          Stars[s->storbits]->AP[Playernum - 1],
                          Stars[s->storbits]->name, s->destshipno,
                          Dir[Playernum - 1][Governor].shipno);
                  break;
                case LEVEL_PLAN:
                  sprintf(Dir[Playernum - 1][Governor].prompt,
                          " ( [%d] /%s/%s/ /../#%d/#%d )\n",
                          Stars[s->storbits]->AP[Playernum - 1],
                          Stars[s->storbits]->name,
                          Stars[s->storbits]->
                          pnames[Dir[Playernum - 1][Governor].pnum],
                          s->destshipno, Dir[Playernum - 1][Governor].shipno);
                  break;
                default:
                  break;
              }
              free((char *)s2);
              break;
            default:
              break;
          }
      }
      free((char *)s);
    }
  }
}

void
cs(int Playernum, int Governor, int APcount)
{
  placetype       where;
  planettype     *planet;
  shiptype       *s;
  racetype       *Race;

  Race = races[Playernum - 1];

  /* Handle cs used with options */
  if (optn)
  {
    /* make new def scope */
    if (!opts['d'])
    {
      notify(Playernum, Governor, "Invalid option(s).\n");
      return;
    }

    if (argn == 2)
    {
      where = Getplace(Playernum, Governor, args[1], 0);
    }
    else if (argn == 1)
    {
      where.level = Dir[Playernum - 1][Governor].level;
      where.snum = Dir[Playernum - 1][Governor].snum;
      where.pnum = Dir[Playernum - 1][Governor].pnum;
      where.shipno = Dir[Playernum - 1][Governor].shipno;
      where.err = 0;
    }
    else
    {
      notify(Playernum, Governor, "Invalid usage.\n");
      return;
    }

    if (!where.err && where.level != LEVEL_SHIP)
    {
      Race->governor[Governor].deflevel = where.level;
      Race->governor[Governor].defsystem = where.snum;
      Race->governor[Governor].defplanetnum = where.pnum;
      putrace(Race);

      sprintf(buf, "New home system is %s\n",
              Dispplace(Playernum, Governor, &where));
      notify(Playernum, Governor, buf);
    }
    else
    {
      sprintf(buf, "cs: bad home system.\n");
      notify(Playernum, Governor, buf);
    }

    return;
  }

  if (argn == 2)
  {
    /* chdir to specified scope */

    where = Getplace(Playernum, Governor, args[1], 0);

    if (where.err)
    {
      sprintf(buf, "cs: bad scope.\n");
      notify(Playernum, Governor, buf);
      Dir[Playernum - 1][Governor].lastx[0] =
        Dir[Playernum - 1][Governor].lasty[0] = 0.0;
      return;
    }
    /* fix lastx, lasty coordinates */

    switch (Dir[Playernum - 1][Governor].level)
    {
      case LEVEL_UNIV:
        Dir[Playernum - 1][Governor].lastx[0] =
          Dir[Playernum - 1][Governor].lasty[0] = 0.0;
        break;
      case LEVEL_STAR:
        if (where.level == LEVEL_UNIV)
        {
          Dir[Playernum - 1][Governor].lastx[1] =
            Stars[Dir[Playernum - 1][Governor].snum]->xpos;
          Dir[Playernum - 1][Governor].lasty[1] =
            Stars[Dir[Playernum - 1][Governor].snum]->ypos;
        }
        else
        {
          Dir[Playernum - 1][Governor].lastx[0] =
            Dir[Playernum - 1][Governor].lasty[0] = 0.0;
        }
        break;

      case LEVEL_PLAN:
        getplanet(&planet, Dir[Playernum - 1][Governor].snum,
                  Dir[Playernum - 1][Governor].pnum);
        if (where.level == LEVEL_STAR &&
            where.snum == Dir[Playernum - 1][Governor].snum)
        {
          Dir[Playernum - 1][Governor].lastx[0] = planet->xpos;
          Dir[Playernum - 1][Governor].lasty[0] = planet->ypos;
        }
        else if (where.level == LEVEL_UNIV)
        {
          Dir[Playernum - 1][Governor].lastx[1] =
            Stars[Dir[Playernum - 1][Governor].snum]->xpos + planet->xpos;
          Dir[Playernum - 1][Governor].lasty[1] =
            Stars[Dir[Playernum - 1][Governor].snum]->ypos + planet->ypos;
        }
        else
        {
          Dir[Playernum - 1][Governor].lastx[0] =
            Dir[Playernum - 1][Governor].lasty[0] = 0.0;
        }
        free((char *)planet);
        break;

      case LEVEL_SHIP:
        (void)getship(&s, Dir[Playernum - 1][Governor].shipno);
        if (!s->docked)
        {
          switch (where.level)
          {
            case LEVEL_UNIV:
              Dir[Playernum - 1][Governor].lastx[1] = s->xpos;
              Dir[Playernum - 1][Governor].lasty[1] = s->ypos;
              break;

            case LEVEL_STAR:
              if (s->whatorbits >= LEVEL_STAR && s->storbits == where.snum)
              {
                /* 
                 * we are going UP from the
                 * ship.. change last
                 */
                Dir[Playernum - 1][Governor].lastx[0] =
                  s->xpos - Stars[s->storbits]->xpos;
                Dir[Playernum - 1][Governor].lasty[0] =
                  s->ypos - Stars[s->storbits]->ypos;
              }
              else
              {
                Dir[Playernum - 1][Governor].lastx[0] =
                  Dir[Playernum - 1][Governor].lasty[0] = 0.0;
              }
              break;

            case LEVEL_PLAN:
              if (s->whatorbits == LEVEL_PLAN && s->storbits == where.snum &&
                  s->pnumorbits == where.pnum)
              {
                /* same */
                getplanet(&planet, (int)s->storbits, (int)s->pnumorbits);
                Dir[Playernum - 1][Governor].lastx[0] =
                  s->xpos - Stars[s->storbits]->xpos - planet->xpos;
                Dir[Playernum - 1][Governor].lasty[0] =
                  s->ypos - Stars[s->storbits]->ypos - planet->ypos;
                free((char *)planet);
              }
              else
              {
                Dir[Playernum - 1][Governor].lastx[0] =
                  Dir[Playernum - 1][Governor].lasty[0] = 0.0;
              }
              break;

            case LEVEL_SHIP:
              Dir[Playernum - 1][Governor].lastx[0] =
                Dir[Playernum - 1][Governor].lasty[0] = 0.0;
              break;

            default:
              break;
          }
        }
        else
        {
          Dir[Playernum - 1][Governor].lastx[0] =
            Dir[Playernum - 1][Governor].lasty[0] = 0.0;
        }
        free((char *)s);
        break;

      default:
        break;
    }

    Dir[Playernum - 1][Governor].level = where.level;
    Dir[Playernum - 1][Governor].snum = where.snum;
    Dir[Playernum - 1][Governor].pnum = where.pnum;
    Dir[Playernum - 1][Governor].shipno = where.shipno;
  }
  else if (argn == 1)
  {
    /* chdir to def scope */
    Dir[Playernum - 1][Governor].level = Race->governor[Governor].deflevel;

    if ((Dir[Playernum - 1][Governor].snum =
         Race->governor[Governor].defsystem) >= Sdata.numstars)
      Dir[Playernum - 1][Governor].snum = Sdata.numstars - 1;

    if ((Dir[Playernum - 1][Governor].pnum =
         Race->governor[Governor].defplanetnum) >=
        Stars[Dir[Playernum - 1][Governor].snum]->numplanets)
      Dir[Playernum - 1][Governor].pnum =
        Stars[Dir[Playernum - 1][Governor].snum]->numplanets - 1;

    Dir[Playernum - 1][Governor].shipno = 0;
    Dir[Playernum - 1][Governor].lastx[0] =
      Dir[Playernum - 1][Governor].lasty[0] = 0.0;
    Dir[Playernum - 1][Governor].lastx[1] =
      Stars[Dir[Playernum - 1][Governor].snum]->xpos;
    Dir[Playernum - 1][Governor].lasty[1] =
      Stars[Dir[Playernum - 1][Governor].snum]->ypos;
    return;
  }
  else
  {
    sprintf(buf, "cs: bad scope.\n");
    notify(Playernum, Governor, buf);
  }
}
