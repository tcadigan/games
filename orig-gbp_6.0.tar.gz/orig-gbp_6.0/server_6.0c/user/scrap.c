/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)scrap.c  1.10 12/3/93 "
 * 
 * scrap.c -- turn a ship to junk
 *
 * $Header: /var/cvs/gbp/GB+/user/scrap.c,v 1.4 2007/07/06 18:07:58 gbp Exp $
 */

#include <stdlib.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"

#include "proto.h"

int             inship(shiptype *);     /* this was missing (kse) */

void
scrap(int Playernum, int Governor, int APcount)
{
  planettype     *planet;
  sectortype     *sect;
  shiptype       *s, *s2;
  int             shipno, nextshipno;
  int             scrapval = 0, destval = 0, crewval = 0, xtalval =
    0, troopval = 0;
  double          fuelval = 0.0;
  racetype       *Race;

  if (argn < 2)
  {
    notify(Playernum, Governor, "Scrap what?\n");
    return;
  }

  nextshipno = start_shiplist(Playernum, Governor, args[1]);

  Race = races[Playernum - 1];

  if (Race->Guest)
  {
    notify(Playernum, Governor, "Guest races cannot scrap ships\n");
    return;
  }

  while ((shipno = do_shiplist(&s, &nextshipno)))
  {
    if (in_list(Playernum, args[1], s, &nextshipno))
    {
#ifdef USE_VN
      if (s->type == OTYPE_VN || s->type == OTYPE_BERS)
      {
        notify(Playernum, Governor, "VNs will not scrap themselves.\n");
        free((char *)s);
        continue;
      }
#endif

      if (s->max_crew && !s->popn)
      {
        notify(Playernum, Governor, "Can't scrap that ship - no crew.\n");
        free((char *)s);
        continue;
      }

      if (s->whatorbits == LEVEL_UNIV)
      {
        /* Used to not allow scrapping at the UNIV level for anything. However, 
         * I'm going permit pods. This is so pod races can clean up their
         * messes.  I'm not going to charge APs at the UNIV scope either. -mfw */

        if (SISAPOD(s))
        {
          APcount = 0;
        }
        else
        {
          notify(Playernum, Governor, "Can't scrap at the ship's scope.\n");
          free((char *)s);
          continue;
        }
      }
      else
        if (!enufAP
            (Playernum, Governor, Stars[s->storbits]->AP[Playernum - 1],
             APcount))
      {
        notify(Playernum, Governor, "Not enough APs to scrap.\n");
        free((char *)s);
        continue;
      }

      /* HUTm (kse) wc's can't be scrapped inside of ship any more */
      if (inship(s) && s->type == OTYPE_TOXWC)
      {
        sprintf(buf, "Can't scrap waste cannisters inside of other ship.\n");
        notify(Playernum, Governor, buf);
        free((char *)s);
        continue;
      }

      /* ships that have other ships in the hangar can't scrap -mfw */
      if (s->ships)
      {
        sprintf(buf,
                "There are other ships in the hangar; scrap those first.\n");
        notify(Playernum, Governor, buf);
        free((char *)s);
        continue;
      }

      if (s->whatorbits == LEVEL_PLAN && s->type == OTYPE_TOXWC)
      {
        sprintf(buf,
                "WARNING: This releases %d toxin points back into the atmosphere!!\n",
                s->special.waste.toxic);
        notify(Playernum, Governor, buf);
      }

      if (!s->docked)
      {
        sprintf(buf,
                "%s is not landed or docked.\nNo resources can be reclaimed.\n",
                Ship(s));
        notify(Playernum, Governor, buf);
      }

      if (s->whatorbits == LEVEL_PLAN)
      {
        /* wc's release poison */
        getplanet(&planet, (int)s->storbits, (int)s->pnumorbits);

        if (landed(s))
        {
          if (!getsector(&sect, planet, (int)s->land_x, (int)s->land_y))
          {
            notify(Playernum, Governor,
                   "Error in sector database, notify deity.\n");
            free((char *)s);
            return;
          }
        }
      }

      if (docked(s) || inship(s))
      {
        if (!getship(&s2, (int)(s->destshipno)))
        {
          free((char *)s);
          continue;
        }

        if (!(s2->docked && s2->destshipno == s->number) &&
            !s->whatorbits == LEVEL_SHIP)
        {
          sprintf(buf, "Warning, other ship not docked..\n");
          notify(Playernum, Governor, buf);
          free((char *)s);
          free((char *)s2);
          continue;
        }
      }

      scrapval = Cost(s) / 2 + s->resource;

      if (s->docked)
      {
        sprintf(buf, "%s: original cost: %ld\n", Ship(s), Cost(s));
        notify(Playernum, Governor, buf);
        sprintf(buf, "         scrap value%s: %d rp's.\n",
                s->resource ? "(with stockpile) " : "", scrapval);
        notify(Playernum, Governor, buf);

        /* New code by Kharush. Check for STYPE_DHUTTLE added. */
        /* I've removed it, Dhuttle was silly -mfw */

        if (s->whatdest == LEVEL_SHIP &&
            s2->resource + scrapval > Max_resource(s2) &&
            s2->type != STYPE_SHUTTLE)
        {
          scrapval = Max_resource(s2) - s2->resource;
          sprintf(buf, "(There is only room for %d resources.)\n", scrapval);
          notify(Playernum, Governor, buf);
        }

        if (s->fuel)
        {
          sprintf(buf, "Fuel recovery: %.0f.\n", s->fuel);
          notify(Playernum, Governor, buf);
          fuelval = s->fuel;

          if (s->whatdest == LEVEL_SHIP && s2->fuel + fuelval > Max_fuel(s2))
          {
            fuelval = Max_fuel(s2) - s2->fuel;
            sprintf(buf, "(There is only room for %.2f fuel.)\n", fuelval);
            notify(Playernum, Governor, buf);
          }
        }
        else
        {
          fuelval = 0.0;
        }

        if (s->destruct)
        {
          sprintf(buf, "Armament recovery: %d.\n", s->destruct);
          notify(Playernum, Governor, buf);
          destval = s->destruct;

          if (s->whatdest == LEVEL_SHIP &&
              s2->destruct + destval > Max_destruct(s2))
          {
            destval = Max_destruct(s2) - s2->destruct;
            sprintf(buf, "(There is only room for %d destruct.)\n", destval);
            notify(Playernum, Governor, buf);
          }
        }
        else
        {
          destval = 0;
        }

        if (s->popn + s->troops)
        {
          if (s->whatdest == LEVEL_PLAN && sect->owner > 0 &&
              sect->owner != Playernum)
          {
            sprintf(buf,
                    "You don't own this sector; no crew can be recovered.\n");
            notify(Playernum, Governor, buf);
          }
          else
          {
            troopval = s->troops;

            if (s->whatdest == LEVEL_SHIP &&
                s2->troops + troopval > Max_mil(s2))
            {
              troopval = Max_mil(s2) - s2->troops;
              sprintf(buf, "(There is only room for %d troops.)\n", troopval);
              notify(Playernum, Governor, buf);
            }

            crewval = s->popn;

            if (s->whatdest == LEVEL_SHIP && s2->popn + crewval > Max_crew(s2))
            {
              crewval = Max_crew(s2) - s2->popn;
              sprintf(buf, "(There is only room for %d crew.)\n", crewval);
              notify(Playernum, Governor, buf);
            }

            sprintf(buf, "Population/Troops recovery: %d/%d.\n", crewval,
                    troopval);
            notify(Playernum, Governor, buf);
          }
        }
        else
        {
          crewval = 0;
          troopval = 0;
        }

        if (s->crystals + s->mounted)
        {
          if (s->whatdest == LEVEL_PLAN && sect->owner > 0 &&
              sect->owner != Playernum)
          {
            sprintf(buf,
                    "You don't own this sector; no crystals can be recovered.\n");
            notify(Playernum, Governor, buf);
          }
          else
          {
            xtalval = s->crystals + s->mounted;

            if (s->whatdest == LEVEL_SHIP &&
                s2->crystals + xtalval > Max_crystals(s2))
            {
              xtalval = Max_crystals(s2) - s2->crystals;
              sprintf(buf, "(There is only room for %d crystals.)\n", xtalval);
              notify(Playernum, Governor, buf);
            }

            sprintf(buf, "Crystal recovery: %d.\n", xtalval);
            notify(Playernum, Governor, buf);
          }
        }
        else
        {
          xtalval = 0;
        }
      }

      /* more adjustments needed here for hanger. Maarten */
      if (s->whatorbits == LEVEL_SHIP)
        s2->hanger -= (unsigned short)s->size;

      if (s->whatorbits == LEVEL_UNIV)
        deductAPs(Playernum, Governor, APcount, 0, 1);
      else
        deductAPs(Playernum, Governor, APcount, (int)s->storbits, 0);

      if (docked(s) || inship(s))
      {
        s2->crystals += xtalval;
        rcv_fuel(s2, (double)fuelval);
        rcv_destruct(s2, destval);
        rcv_resource(s2, scrapval);
        rcv_troops(s2, troopval, Race->mass);
        rcv_popn(s2, crewval, Race->mass);

        /* 
         * check for docking status in case scrapped
         * ship is landed. Maarten
         */
        if (!(s->whatorbits == LEVEL_SHIP))
        {
          s2->docked = 0;       /* undock the surviving ship */
          s2->whatdest = LEVEL_UNIV;
          s2->destshipno = 0;
        }

        putship(s2);
        free((char *)s2);
      }

      if (s->whatorbits == LEVEL_PLAN)
      {
        free((char *)planet);   /* This has already been allocated */
        getplanet(&planet, (int)s->storbits, (int)s->pnumorbits);

        if (landed(s) || inship(s))
        {
          /* if colonising the sector set sector owner and give a message it's
           * also nice to check if there is anyone to colonize */
          if (sect->owner == 0 && (troopval > 0 || crewval > 0))
          {
            sect->owner = Playernum;
            planet->info[Playernum - 1].numsectsowned++;
            sprintf(buf, "Sector %d,%d Colonized.\n", s->land_x, s->land_y);
            notify(Playernum, Governor, buf);
          }

          /* increase sector's crew and troop count */
          sect->troops += troopval;
          sect->popn += crewval;

          /* increase planets crew, troop, res, etc count for this player */
          planet->info[Playernum - 1].popn += crewval;
          planet->info[Playernum - 1].troops += troopval;

          /* New code by Kharush. Scrapping does not anymore overflow
           * stockpiles. */

          if (planet->info[Playernum - 1].resource + scrapval <= USHRT_MAX)
          {
            planet->info[Playernum - 1].resource += scrapval;
          }
          else
          {
            planet->info[Playernum - 1].resource = USHRT_MAX;
            sprintf(buf, "Planet has room for only %d resources.\n",
                    USHRT_MAX - planet->info[Playernum - 1].resource);
            notify(Playernum, Governor, buf);
          }

          if (planet->info[Playernum - 1].fuel + fuelval <= USHRT_MAX)
          {
            planet->info[Playernum - 1].fuel += fuelval;
          }
          else
          {
            planet->info[Playernum - 1].fuel = USHRT_MAX;
            sprintf(buf, "Planet has room for only %d fuel.\n",
                    USHRT_MAX - planet->info[Playernum - 1].fuel);
            notify(Playernum, Governor, buf);
          }

          if (planet->info[Playernum - 1].destruct + destval <= USHRT_MAX)
          {
            planet->info[Playernum - 1].destruct += destval;
          }
          else
          {
            planet->info[Playernum - 1].destruct = USHRT_MAX;
            sprintf(buf, "Planet has room for only %d destruct.\n",
                    USHRT_MAX - planet->info[Playernum - 1].destruct);
            notify(Playernum, Governor, buf);
          }

          /* old code planet->info[Playernum - 1].resource += scrapval;
           * planet->info[Playernum - 1].destruct += destval;
           * planet->info[Playernum - 1].fuel += (int) fuelval; */

          planet->popn += crewval;
          planet->info[Playernum - 1].crystals += (int)xtalval;

          putsector(sect, planet, (int)s->land_x, (int)s->land_y);
          free((char *)sect);
        }

        putplanet(planet, (int)s->storbits, (int)s->pnumorbits);
        free((char *)planet);
      }

      kill_ship(Playernum, s);
      putship(s);
      free((char *)s);

      if (landed(s))
      {
        sprintf(buf, "\nScrapped.\n");
      }
      else
      {
        sprintf(buf, "\nDestroyed.\n");
      }
      notify(Playernum, Governor, buf);
    }
    else
    {
      free((char *)s);
    }
  }
}
