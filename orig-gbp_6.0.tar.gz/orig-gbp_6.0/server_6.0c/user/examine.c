/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)examine.c       1.7 12/3/93 "
 *
 * examine -- check out an object
 *
 * $Header: /var/cvs/gbp/GB+/user/examine.c,v 1.3 2007/07/06 18:09:34 gbp Exp $
 */

#include <stdlib.h>
#include <string.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"

extern long     Shipdata[NUMSTYPES][NUMABILS];
extern const char *Shipnames[];

void            examine(int, int, int);

#include "proto.h"

void
examine(int Playernum, int Governor, int APcount)
{
  shiptype       *ship;
  int             t, shipno;
  FILE           *fd;
  char            ch;

  if (argn < 2)
  {
    notify(Playernum, Governor, "Examine what?\n");
    return;
  }
  sscanf(args[1] + (*args[1] == '#'), "%d", &shipno);

  if (!getship(&ship, shipno))
  {
    notify(Playernum, Governor, "No applicable ship.\n");
    return;
  }
  if (!ship->alive)
  {
    sprintf(buf, "That ship is dead.\n");
    notify(Playernum, Governor, buf);
    free((char *)ship);
    return;
  }
  if (ship->whatorbits == LEVEL_UNIV ||
      isclr(Stars[ship->storbits]->inhabited, Playernum))
  {
    sprintf(buf, "That ship it not visible to you.\n");
    notify(Playernum, Governor, buf);
    free((char *)ship);
    return;
  }
  if ((fd = fopen(EXAM_FL, "r")) == NULL)
  {
    perror(EXAM_FL);
    free((char *)ship);
    return;
  }
  /* look through ship data file */
  for (t = 0; t <= ship->type; t++)
    while (fgetc(fd) != '~') ;

  /* look through ship data file */
  sprintf(buf, "\n");
  /* give report */
  while ((ch = fgetc(fd)) != '~')
  {
    sprintf(temp, "%c", ch);
    strcat(buf, temp);
  }
  notify(Playernum, Governor, buf);
  fclose(fd);

  if (!ship->examined)
  {
    if (ship->whatorbits == LEVEL_UNIV)
      deductAPs(Playernum, Governor, APcount, 0, 1);    /* ded from sdata */
    else
      deductAPs(Playernum, Governor, APcount, (int)ship->storbits, 0);

    ship->examined = 1;
    putship(ship);
  }
  if (has_switch(ship))
  {
    sprintf(buf,
            "This device has an on/off switch that can be set with order.\n");
    notify(Playernum, Governor, buf);
  }
  if (!ship->active)
  {
    sprintf(buf,
            "This device has been irradiated;\nit's crew is dying and it cannot move for the time being.\n");
    notify(Playernum, Governor, buf);
  }
  free((char *)ship);
}
