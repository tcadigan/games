/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)csp_prof.c      1.4 12/9/93 "
 *
 * CSP, copyright (c) 1993 by John P. Deragon, Evan Koffler
 * Print out the csp version of profile
 *
 * $Header: /var/cvs/gbp/GB+/user/csp_prof.c,v 1.4 2007/07/06 18:09:34 gbp Exp $
 */

#include <string.h>
#include <stdio.h>

#define EXTERN extern
#include "vars.h"
#include "races.h"
#include "ships.h"
#include "buffers.h"
#include "power.h"
#include "config.h"
#include "ranks.h"
#include "tweakables.h"
#include "csp.h"
#include "csp_types.h"
#include "debug.h"
#include "proto.h"

extern char    *Desnames[];

void
CSP_profile(int Playernum, int Governor, int APcount)
{
  int             p;
  racetype       *r, *Race;
  enum PLAYER_TYPE RStatus = -1;
  enum RACE_TYPE  RType;
  enum SECTOR_TYPES RSector;
  char            defScope[50];

  Race = races[Playernum - 1];

  debug(LEVEL_CSP, "CSP: Entering CSP_profile\n");

  if ((argn == 1) || (Race->God))
  {
    debug(LEVEL_CSP_DETAILED, "CSP: Calling CSP_PROFILE as god or own race\n");
    if (Race->God)
    {
      if (argn != 1)
      {
        if (!(p = GetPlayer(args[1])))
        {
          sprintf(buf, "Player does not exist.\n");
          notify(Playernum, Governor, buf);
          return;
        }
        Race = races[p - 1];
      }
      else
        RStatus = CSPD_DIETY;
    }
    else if (Race->Guest)
      RStatus = CSPD_GUEST;
    else
      RStatus = CSPD_NORMAL;

    if (Race->Metamorph)
      RType = CSPD_RACE_MORPH;
    else
      RType = CSPD_RACE_NORMAL;

    sprintf(defScope, "%s/%s", Stars[Race->governor[Governor].homesystem]->name,
            Stars[Race->governor[Governor].homesystem]->pnames[Race->
                                                               governor
                                                               [Governor].
                                                               homeplanetnum]);

    /* Print out the profile_intro */
    sprintf(buf, "%c %d %d %d %s\n", CSP_CLIENT, CSP_PROFILE_INTRO,
            Race->Playernum, RStatus, Race->name);
    notify(Playernum, Governor, buf);

    /* send the stupid motto along */
    sprintf(buf, "%c %d %s\n", CSP_CLIENT, CSP_PROFILE_PERSONAL, Race->info);
    notify(Playernum, Governor, buf);

    /* 
     * send the dynamic information, ie: the only stuff that
     * changes is sent here
     */
    sprintf(buf, "%c %d %d %d %d %ld %d %d %d %s\n", CSP_CLIENT,
            CSP_PROFILE_DYNAMIC, Race->turn, 100,
            (Race->Gov_ship ? Race->Gov_ship : 0), Race->morale,
            (int)gun_range(Race, (shiptype *) NULL, 1),
            (int)tele_range(OTYPE_STELE, Race->tech),
            (int)tele_range(OTYPE_GTELE, Race->tech), defScope);
    notify(Playernum, Governor, buf);

    /* 
     * send the race stats format Type, fert, birth, mass, fight,
     * metab, sexes, explore, tech, iq
     */
    sprintf(buf, "%c %d %d %d %f %f %d %f %d %d %f %f\n", CSP_CLIENT,
            CSP_PROFILE_RACE_STATS, RType, Race->fertilize, Race->birthrate,
            Race->mass, Race->fighters, Race->metabolism, Race->number_sexes,
            (int)(Race->adventurism * 100.0), (float)Race->tech,
            (float)Race->IQ);
    notify(Playernum, Governor, buf);

    /* send the planet conditions */
    sprintf(buf, "%c %d %d %d %d %d %d %d %d %d %d\n", CSP_CLIENT,
            CSP_PROFILE_PLANET, Temp(Race->conditions[TEMP]),
            Temp(Race->conditions[METHANE]), Temp(Race->conditions[OXYGEN]),
            Temp(Race->conditions[CO2]), Temp(Race->conditions[HYDROGEN]),
            Temp(Race->conditions[NITROGEN]), Temp(Race->conditions[SULFUR]),
            Temp(Race->conditions[HELIUM]), Temp(Race->conditions[OTHER]));
    notify(Playernum, Governor, buf);

    /* send the sector prefs */
    sprintf(buf, "%c %d %d %d %d %d %d %d %d %d\n", CSP_CLIENT,
            CSP_PROFILE_SECTOR, ((int)(Race->likes[SEA] * 100)),
            ((int)(Race->likes[LAND] * 100)), ((int)(Race->likes[MOUNT] * 100)),
            ((int)(Race->likes[GAS] * 100)), ((int)(Race->likes[ICE] * 100)),
            ((int)(Race->likes[FOREST] * 100)),
            ((int)(Race->likes[DESERT] * 100)),
            ((int)(Race->likes[PLATED] * 100)));
    notify(Playernum, Governor, buf);

    sprintf(buf, "%c %d %d %d %d %d %d %d %d %d %d %d %d\n", CSP_CLIENT,
            CSP_PROFILE_DISCOVERY, Hyper_drive(Race), Crystal(Race),
            Atmos(Race), Laser(Race), Wormhole(Race), Vn(Race), Cew(Race),
            Cloak(Race), Avpm(Race), Tractor_beam(Race), Transporter(Race));
    notify(Playernum, Governor, buf);

    sprintf(buf, "%c %d\n", CSP_CLIENT, CSP_PROFILE_END);
    notify(Playernum, Governor, buf);

  }
  else
  {
    debug(LEVEL_CSP_DETAILED, "CSP: Calling CSP_PROFILE on another race\n");
    RStatus = CSPD_NORMAL;
    if (!(p = GetPlayer(args[1])))
    {
      sprintf(buf, "Player does not exist.\n");
      notify(Playernum, Governor, buf);
      return;
    }

    r = races[p - 1];
    if (Race->translate[p - 1] > 50)
    {
      if (Race->Metamorph)
        RType = CSPD_RACE_MORPH;
      else
        RType = CSPD_RACE_NORMAL;
    }
    else
      RType = CSPD_RACE_UNKNOWN;

    if (Race->God)
    {
      if (r->God)
        RStatus = CSPD_DIETY;
      else if (r->Guest)
        RStatus = CSPD_GUEST;
    }
    else
      RStatus = CSPD_NORMAL;

    /* Print out the profile_intro */
    sprintf(buf, "%c %d %d %d %s\n", CSP_CLIENT, CSP_PROFILE_INTRO, p, RStatus,
            r->name);
    notify(Playernum, Governor, buf);

    /* send the stupid motto along */
    sprintf(buf, "%c %d %s\n", CSP_CLIENT, CSP_PROFILE_PERSONAL, r->info);
    notify(Playernum, Governor, buf);

    /* 
     * send the dynamic information, ie: the only stuff that
     * changes is sent here
     */
    sprintf(buf, "%c %d %d %d %d %d %d %s\n", CSP_CLIENT,
            CSP_PROFILE_DYNAMIC_OTHER, Race->translate[p - 1],
            (IntEstimate_i((double)r->morale, Race, p)),
            (IntEstimate_i(gun_range(Race, (shiptype *) NULL, 1), Race, p)),
            (IntEstimate_i(tele_range(OTYPE_STELE, r->tech), Race, p)),
            (IntEstimate_i(tele_range(OTYPE_GTELE, r->tech), Race, p)),
            (Race->translate[p - 1] > 80 ? Desnames[r->likesbest] : "????"));

    notify(Playernum, Governor, buf);

    /* 
     * send the race stats format Type, fert, birth, mass, fight,
     * metab, sexes, explore, tech, iq
     */
    sprintf(buf, "%c %d %d %d %f %f %d %f %d %d %f %f\n", CSP_CLIENT,
            CSP_PROFILE_RACE_STATS, RType,
            (IntEstimate_i((double)(r->fertilize), Race, p)),
            (float)(IntEstimate_i(r->birthrate * 100.0, Race, p)),
            (float)(IntEstimate_i(r->mass, Race, p)),
            (int)(IntEstimate_i((double)r->fighters, Race, p)),
            (float)(IntEstimate_i(r->metabolism, Race, p)),
            (int)(IntEstimate_i((double)r->number_sexes, Race, p)),
            (int)(IntEstimate_i(r->adventurism * 100.0, Race, p)),
            (float)(IntEstimate_i(r->tech, Race, p)),
            (float)(IntEstimate_i((double)r->IQ, Race, p)));
    notify(Playernum, Governor, buf);

    /* send the planet conditions */
    sprintf(buf, "%c %d %d %d %d %d %d %d %d %d %d\n", CSP_CLIENT,
            CSP_PROFILE_PLANET,
            (IntEstimate_i((double)(r->conditions[TEMP]), Race, p)),
            (IntEstimate_i((double)(r->conditions[METHANE]), Race, p)),
            (IntEstimate_i((double)(r->conditions[OXYGEN]), Race, p)),
            (IntEstimate_i((double)(r->conditions[CO2]), Race, p)),
            (IntEstimate_i((double)(r->conditions[HYDROGEN]), Race, p)),
            (IntEstimate_i((double)(r->conditions[NITROGEN]), Race, p)),
            (IntEstimate_i((double)(r->conditions[SULFUR]), Race, p)),
            (IntEstimate_i((double)(r->conditions[HELIUM]), Race, p)),
            (IntEstimate_i((double)(r->conditions[OTHER]), Race, p)));
    notify(Playernum, Governor, buf);

    if (Race->translate[p - 1] > 80)
      RSector = r->likesbest;
    else
      RSector = CSPD_SECTOR_UNKNOWN;

    /* send the sector prefs */
    sprintf(buf, "%c %d %d %d %d %d %d %d %d %d\n", CSP_CLIENT,
            CSP_PROFILE_SECTOR, ((int)RSector == SEA ? 100 : 0),
            ((int)RSector == LAND ? 100 : 0), ((int)RSector == MOUNT ? 100 : 0),
            ((int)RSector == GAS ? 100 : 0), ((int)RSector == ICE ? 100 : 0),
            ((int)RSector == FOREST ? 100 : 0),
            ((int)RSector == DESERT ? 100 : 0),
            ((int)RSector == PLATED ? 100 : 0));
    notify(Playernum, Governor, buf);

    /* sprintf(buf, "%c %d %d %d %d %d %d\n", CSP_CLIENT,
     * CSP_PROFILE_DISCOVERY, NULL, NULL, NULL, NULL, NULL); -mfw */
    sprintf(buf, "%c %d %d %d %d %d %d\n", CSP_CLIENT, CSP_PROFILE_DISCOVERY, 0,
            0, 0, 0, 0);
    notify(Playernum, Governor, buf);

    sprintf(buf, "%c %d\n", CSP_CLIENT, CSP_PROFILE_END);
    notify(Playernum, Governor, buf);
  }
  debug(LEVEL_CSP, "CSP: Leaving CSP_profile\n");
}

int
IntEstimate_i(double data, racetype * r, int p)
{
  int             est;

  if (r->translate[p - 1] > 10)
  {
    est = round_perc((int)data, r, p);
    if ((int)abs(est) < 1000)
      return (est);
    else if ((int)abs(est) < 10000)
      return (est / 1000.);
    else if ((int)abs(est) < 1000000)
      return (est / 1000.);
    else
      return (est / 1000000.);
  }
  return (0);
}
