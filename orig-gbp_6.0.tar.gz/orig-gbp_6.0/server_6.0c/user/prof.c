/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)prof.c  1.16 12/3/93 "
 *
 * Tue Apr  9 16:14:58 MDT 1991 (Evan D. Koffler)
 * Reformatted the profile and treasury command.
 * 
 * prof.c -- print out racial profile
 *
 * $Header: /var/cvs/gbp/GB+/user/prof.c,v 1.3 2007/07/06 18:09:34 gbp Exp $
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "races.h"
#include "ships.h"
#include "buffers.h"
#include "power.h"
#include "config.h"
#include "ranks.h"
#include "tweakables.h"

extern char    *Desnames[];

EXTERN void     whois(int, int, int);
EXTERN void     profile(int, int, int);
EXTERN char    *Estimate_f(double, racetype *, int);
EXTERN char    *Estimate_i(int, racetype *, int);
EXTERN int      round_perc(int, racetype *, int);

#include "proto.h"

void
whois(int Playernum, int Governor, int APcount)
{
  int             i, j, numraces;
  racetype       *Race;

  if (argn <= 1)
  {
    sprintf(args[1], "%d", Playernum);  /* The coward's way out */
    argn = 2;
  }
  numraces = Num_races;

  for (i = 1; i <= argn - 1; i++)
  {
    j = atoi(args[i]);
    if (!(j < 1 || j > numraces))
    {
      Race = races[j - 1];
      if (j == Playernum)
        sprintf(buf, "[%2d, %d] %s \"%s\"\n", j, Governor, Race->name,
                Race->governor[Governor].name);
      else
        sprintf(buf, "[%2d] %s\n", j, Race->name);
    }
    else
    {
      sprintf(buf, "Identify: Invalid player number #%d. Try again.\n", j);
    }
    notify(Playernum, Governor, buf);
  }
}

void
treasury(int Playernum, int Governor)
{
  racetype       *Race;
  int             Grep;

  Race = races[Playernum - 1];

#ifdef COLLECTIVE_MONEY
  Grep = 0;
#else
  Grep = Governor;
#endif

  sprintf(buf,
          "Income last update was: %ld                Cost last update was: %ld\n",
          Race->governor[Grep].income + Race->governor[Grep].profit_market,
          Race->governor[Grep].maintain + Race->governor[Grep].cost_tech +
          Race->governor[Grep].cost_market);
  notify(Playernum, Governor, buf);
  sprintf(buf, "    Market: %5ld                               Market: %5ld\n",
          Race->governor[Grep].profit_market, Race->governor[Grep].cost_market);
  notify(Playernum, Governor, buf);
  sprintf(buf, "    Taxes:  %5ld                               Tech:   %5ld\n",
          Race->governor[Grep].income, Race->governor[Grep].cost_tech);
  notify(Playernum, Governor, buf);

  sprintf(buf, "                                                Maint:  %5ld\n",
          Race->governor[Grep].maintain);
  notify(Playernum, Governor, buf);
  sprintf(buf, "You have: %ld\n", MONEY(Race, Governor));
  notify(Playernum, Governor, buf);
}

void
profile(int Playernum, int Governor, int APcount)
{
  int             p;
  racetype       *r, *Race;

  Race = races[Playernum - 1];

  if (client_can_understand(Playernum, Governor, CSP_PROFILE_INTRO))
    CSP_profile(Playernum, Governor, 0);
  else
  {
    if ((argn == 1) || (Race->God))
    {
      if (Race->God)
      {
        if (argn != 1)
        {
          if (!(p = GetPlayer(args[1])))
          {
            sprintf(buf, "Player does not exist.\n");
            notify(Playernum, Governor, buf);
            return;
          }
          Race = races[p - 1];
        }
      }
      sprintf(buf, "--==** Racial profile for %s (player %d) **==--\n",
              Race->name, Race->Playernum);
      notify(Playernum, Governor, buf);
      if (Race->God)
      {
        sprintf(buf, "*** Diety Status ***\n");
        notify(Playernum, Governor, buf);
      }
      sprintf(buf, "Personal: %s\n", Race->info);
      notify(Playernum, Governor, buf);
      sprintf(buf, "Default Scope: /%s/%s\n",
              Stars[Race->governor[Governor].homesystem]->name,
              Stars[Race->governor[Governor].homesystem]->pnames[Race->
                                                                 governor
                                                                 [Governor].
                                                                 homeplanetnum]);
      notify(Playernum, Governor, buf);
      if (Race->Gov_ship == 0)
        sprintf(buf, "NO DESIGNATED CAPITAL!!");
      else
        sprintf(buf, "Designated Capital: #%-8d", Race->Gov_ship);
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\tRanges:   guns:   %5.0f\n",
              gun_range(Race, (shiptype *) NULL, 1));
      notify(Playernum, Governor, buf);
      sprintf(buf, "Morale: %5ld\t\t\t\t\t    space:  %5.0f\n", Race->morale,
              tele_range(OTYPE_STELE, Race->tech));
      notify(Playernum, Governor, buf);
      sprintf(buf, "Updates active: %d\t\t\t\t      ground: %5.0f\n\n",
              Race->turn, tele_range(OTYPE_GTELE, Race->tech));
      notify(Playernum, Governor, buf);
      sprintf(buf, "%s      Planet Conditions\t      Sector Preferences\n",
              Race->Metamorph ? "Metamorphic Race\t" : "Normal Race\t\t");
      notify(Playernum, Governor, buf);
      sprintf(buf, "Fert:    %3d%%           Temp:       %d\n", Race->fertilize,
              Temp(Race->conditions[TEMP]));
      notify(Playernum, Governor, buf);
      sprintf(buf,
              "Rate:    %3.1f            methane  %5d%%           %-8.8s %c %3.0f%%\n",
              Race->birthrate, Race->conditions[METHANE], Desnames[SEA],
              CHAR_SEA, Race->likes[SEA] * 100.);
      notify(Playernum, Governor, buf);
      sprintf(buf,
              "Mass:   %4.2f            oxygen   %5d%%           %-8.8s %c %3.0f%%\n",
              Race->mass, Race->conditions[OXYGEN], Desnames[GAS], CHAR_GAS,
              Race->likes[GAS] * 100.);
      notify(Playernum, Governor, buf);
      sprintf(buf,
              "Fight:     %d            helium   %5d%%           %-8.8s %c %3.0f%%\n",
              Race->fighters, Race->conditions[HELIUM], Desnames[ICE], CHAR_ICE,
              Race->likes[ICE] * 100.);
      notify(Playernum, Governor, buf);
      sprintf(buf,
              "Metab:  %4.2f            nitrogen %5d%%           %-8.8s %c %3.0f%%\n",
              Race->metabolism, Race->conditions[NITROGEN], Desnames[MOUNT],
              CHAR_MOUNT, Race->likes[MOUNT] * 100.);
      notify(Playernum, Governor, buf);
      sprintf(buf,
              "Sexes:     %1d            CO2      %5d%%           %-8.8s %c %3.0f%%\n",
              Race->number_sexes, Race->conditions[CO2], Desnames[LAND],
              CHAR_LAND, Race->likes[LAND] * 100.);
      notify(Playernum, Governor, buf);
      sprintf(buf,
              "Explore:  %-3.0f%%          hydrogen %5d%%           %-8.8s %c %3.0f%%\n",
              Race->adventurism * 100.0, Race->conditions[HYDROGEN],
              Desnames[DESERT], CHAR_DESERT, Race->likes[DESERT] * 100.);
      notify(Playernum, Governor, buf);
      sprintf(buf,
              "Avg Int: %3d            sulfer   %5d%%           %-8.8s %c %3.0f%%\n",
              Race->IQ, Race->conditions[SULFUR], Desnames[FOREST], CHAR_FOREST,
              Race->likes[FOREST] * 100.);
      notify(Playernum, Governor, buf);
      sprintf(buf,
              "Tech:   %-6.2f          other    %5d%%           %-8.8s %c %3.0f%%\n",
              Race->tech, Race->conditions[OTHER], Desnames[PLATED],
              CHAR_PLATED, Race->likes[PLATED] * 100.);
      notify(Playernum, Governor, buf);

      notify(Playernum, Governor, "Discoveries:");
      if (Hyper_drive(Race))
        notify(Playernum, Governor, "  Hyperdrive");
      if (Crystal(Race))
        notify(Playernum, Governor, "  Crystals");
      if (Atmos(Race))
        notify(Playernum, Governor, "  Atmospheric");
      if (Laser(Race))
        notify(Playernum, Governor, "  Combat Lasers");
      if (Wormhole(Race))
        notify(Playernum, Governor, "  Wormhole");
#ifdef USE_VN
      if (Vn(Race))
        notify(Playernum, Governor, "  Von Neumann Machines");
#endif
      if (Cew(Race))
        notify(Playernum, Governor, "  Confined Energy Weapons");
      if (Cloak(Race))
        notify(Playernum, Governor, "  Cloaking");
      if (Avpm(Race))
        notify(Playernum, Governor, "  AVPM");
      if (Tractor_beam(Race))
        notify(Playernum, Governor, "  Tractor Beam");
      if (Transporter(Race))
        notify(Playernum, Governor, "  Transporter");
      notify(Playernum, Governor, "\n");
    }
    else
    {
      if (!(p = GetPlayer(args[1])))
      {
        sprintf(buf, "Player does not exist.\n");
        notify(Playernum, Governor, buf);
        return;
      }
      r = races[p - 1];
      sprintf(buf, "------ Race report on %s (%d) ------\n", r->name, p);
      notify(Playernum, Governor, buf);
      if (Race->God)
      {
        if (r->God)
        {
          sprintf(buf, "*** Deity Status ***\n");
          notify(Playernum, Governor, buf);
        }
      }
      sprintf(buf, "Personal: %s\n", r->info);
      notify(Playernum, Governor, buf);
      sprintf(buf, "%%Know:  %3d%%\n", Race->translate[p - 1]);
      notify(Playernum, Governor, buf);
      if (Race->translate[p - 1] > 50)
      {
        sprintf(buf, "%s\t  Planet Conditions\n",
                r->Metamorph ? "Metamorphic Race" : "Normal Race\t");
        notify(Playernum, Governor, buf);
        sprintf(buf, "Fert:    %s", Estimate_i((int)(r->fertilize), Race, p));
        notify(Playernum, Governor, buf);
        sprintf(buf, "\t\t  Temp:\t%s\n",
                Estimate_i((int)(r->conditions[TEMP]), Race, p));
        notify(Playernum, Governor, buf);
        sprintf(buf, "Rate:    %s%%",
                Estimate_f(r->birthrate * 100.0, Race, p));
        notify(Playernum, Governor, buf);
      }
      else
      {
        sprintf(buf, "Unknown Race\t\t  Planet Conditions\n");
        notify(Playernum, Governor, buf);
        sprintf(buf, "Fert:    %s", Estimate_i((int)(r->fertilize), Race, p));
        notify(Playernum, Governor, buf);
        sprintf(buf, "\t\t  Temp:\t%s\n",
                Estimate_i((int)(r->conditions[TEMP]), Race, p));
        notify(Playernum, Governor, buf);
        sprintf(buf, "Rate:    %s", Estimate_f(r->birthrate, Race, p));
        notify(Playernum, Governor, buf);
      }
      sprintf(buf, "\t\t  methane  %4s%%\t\tRanges:\n",
              Estimate_i((int)(r->conditions[METHANE]), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "Mass:    %s", Estimate_f(r->mass, Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\t  oxygen   %4s%%",
              Estimate_i((int)(r->conditions[OXYGEN]), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\t  guns:   %6s\n",
              Estimate_f(gun_range(r, (shiptype *) NULL, 1), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "Fight:   %s", Estimate_i((int)(r->fighters), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\t  helium   %4s%%",
              Estimate_i((int)(r->conditions[HELIUM]), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\t  space:  %6s\n",
              Estimate_f(tele_range(OTYPE_STELE, r->tech), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "Metab:   %s", Estimate_f(r->metabolism, Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\t  nitrogen %4s%%",
              Estimate_i((int)(r->conditions[NITROGEN]), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\t  ground: %6s\n",
              Estimate_f(tele_range(OTYPE_GTELE, r->tech), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "Sexes:   %s", Estimate_i((int)(r->number_sexes), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\t  CO2      %4s%%\n",
              Estimate_i((int)(r->conditions[CO2]), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "Explore: %s%%",
              Estimate_f(r->adventurism * 100.0, Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\t  hydrogen %4s%%\n",
              Estimate_i((int)(r->conditions[HYDROGEN]), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "Avg Int: %s", Estimate_i((int)(r->IQ), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\t  sulfer   %4s%%\n",
              Estimate_i((int)(r->conditions[SULFUR]), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "Tech:    %s", Estimate_f(r->tech, Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\t  other    %4s%%",
              Estimate_i((int)(r->conditions[OTHER]), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "\t\tMorale:   %6s\n",
              Estimate_i((int)(r->morale), Race, p));
      notify(Playernum, Governor, buf);
      sprintf(buf, "Sector type preference : %s\n",
              Race->translate[p - 1] > 80 ? Desnames[r->likesbest] : " ? ");
      notify(Playernum, Governor, buf);
    }
  }                             /* csp check */
}

static char     est_buf[20];

char           *
Estimate_f(double data, racetype * r, int p)
{
  int             est;

  sprintf(est_buf, "?");

  if (r->translate[p - 1] > 10)
  {
    est = round_perc((int)data, r, p);
    if (est < 1000)
      sprintf(est_buf, "%d", est);
    else if (est < 10000)
      sprintf(est_buf, "%.1fK", (double)est / 1000.);
    else if (est < 1000000)
      sprintf(est_buf, "%.0fK", (double)est / 1000.);
    else
      sprintf(est_buf, "%.1fM", (double)est / 1000000.);
  }

  return est_buf;
}

char           *
Estimate_i(int data, racetype * r, int p)
{
  int             est;

  sprintf(est_buf, "?");

  if (r->translate[p - 1] > 10)
  {
    est = round_perc((int)data, r, p);
    if ((int)abs(est) < 1000)
      sprintf(est_buf, "%d", est);
    else if ((int)abs(est) < 10000)
      sprintf(est_buf, "%.1fK", (double)est / 1000.);
    else if ((int)abs(est) < 1000000)
      sprintf(est_buf, "%.0fK", (double)est / 1000.);
    else
      sprintf(est_buf, "%.1fM", (double)est / 1000000.);
  }

  return est_buf;
}

int
round_perc(int data, racetype * r, int p)
{
  int             k;

#if 0                           /* r->captured_prisoners[p-1] is never actually 
                                 * used eslewhere. */
  k = 101 - MIN(r->translate[p - 1] + r->captured_prisoners[p - 1], 100);
#else
  k = 101 - MIN(r->translate[p - 1], 100);
#endif
  return ((data / k) * k);
}
