/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)mobiliz.c       1.7 12/3/93 "
 * 
 * mobiliz.c -- persuade people to build military stuff. Sectors that are
 * mobilized produce Destructive Potential in proportion to the % they are
 * mobilized.  they are also more damage-resistant.
 *
 * $Header: /var/cvs/gbp/GB+/user/mobiliz.c,v 1.4 2007/07/06 18:09:34 gbp Exp $
 */

#include <stdlib.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "buffers.h"
#include "races.h"
#include "power.h"
#include "ranks.h"
#include <ctype.h>

void            mobilize(int, int, int);
void            tax(int, int, int);
int             control(int, int, startype *);

#include "proto.h"

void
mobilize(int Playernum, int Governor, int APcount)
{
  int             sum_mob = 0;
  planettype     *p;

  if (Dir[Playernum - 1][Governor].level != LEVEL_PLAN)
  {
    sprintf(buf, "scope must be a planet.\n");
    notify(Playernum, Governor, buf);
    return;
  }
  if (!enufAP
      (Playernum, Governor,
       Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1], APcount))
  {
    return;
  }
  getplanet(&p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);
  getsmap(Smap, p);

  if (argn < 2)
  {
    sprintf(buf, "Current mobilization: %d    Quota: %d\n",
            p->info[Playernum - 1].comread, p->info[Playernum - 1].mob_set);
    notify(Playernum, Governor, buf);
    free((char *)p);
    return;
  }
  sum_mob = atoi(args[1]);

  if (sum_mob > 100 || sum_mob < 0)
  {
    sprintf(buf, "Illegal value.\n");
    notify(Playernum, Governor, buf);
    free((char *)p);
    return;
  }
  p->info[Playernum - 1].mob_set = sum_mob;
  putplanet(p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);
  deductAPs(Playernum, Governor, APcount, Dir[Playernum - 1][Governor].snum, 0);

  sprintf(buf, "New quota set to: %d at a cost of %d APs.\n",
          p->info[Playernum - 1].mob_set, APcount);
  notify(Playernum, Governor, buf);

  free((char *)p);
}

void
tax(int Playernum, int Governor, int APcount)
{
  int             sum_tax = 0;
  planettype     *p;
  racetype       *Race;

  if (Dir[Playernum - 1][Governor].level != LEVEL_PLAN)
  {
    sprintf(buf, "scope must be a planet.\n");
    notify(Playernum, Governor, buf);
    return;
  }
  Race = races[Playernum - 1];
  if (!Race->Gov_ship)
  {
    notify(Playernum, Governor, "You have no government center active.\n");
    return;
  }
  if (Race->Guest)
  {
    notify(Playernum, Governor,
           "Sorry, but you can't do this when you are a guest.\n");
    return;
  }
  if (!enufAP
      (Playernum, Governor,
       Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1], APcount))
  {
    return;
  }
  getplanet(&p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);

  if (argn < 2)
  {
    sprintf(buf, "Current tax rate: %d%%    Target: %d%%\n",
            p->info[Playernum - 1].tax, p->info[Playernum - 1].newtax);
    notify(Playernum, Governor, buf);
    free((char *)p);
    return;
  }
  sum_tax = atoi(args[1]);

  if (sum_tax > 100 || sum_tax < 0)
  {
    sprintf(buf, "Illegal value.\n");
    notify(Playernum, Governor, buf);
    free((char *)p);
    return;
  }
  p->info[Playernum - 1].newtax = sum_tax;
  putplanet(p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);

  deductAPs(Playernum, Governor, APcount, Dir[Playernum - 1][Governor].snum, 0);
  notify(Playernum, Governor, "Set.\n");
  free((char *)p);
}

int
control(int Playernum, int Governor, startype * star)
{
  return (!Governor || star->governor[Playernum - 1] == Governor);
}
