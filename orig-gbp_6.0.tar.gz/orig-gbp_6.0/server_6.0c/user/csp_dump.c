/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * csp_dump.c -- Dump various information in CSP format.
 *
 * #ident  "@(#)csp_dump.c        1.2 12/3/93 "
 *
 * $Header: /var/cvs/gbp/GB+/user/csp_dump.c,v 1.4 2007/07/06 18:09:34 gbp Exp $
 */

#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <curses.h>
#include <stdio.h>
#include <math.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"
#include "csp.h"
#include "csp_types.h"
#include "proto.h"

extern char     Shipltrs[];

racetype       *Race;

extern reportdata *rd;

#define        PLANET        1

void            csp_ship_report(int, int, int, unsigned char[], int);

void
CSP_sectors(int Playernum, int Governor)
{
  int             star, i, sectors = 0, controlled = 0;

  for (star = 0; star < Sdata.numstars; star++)
  {
    for (i = 0; i < Stars[star]->numplanets; i++)
    {
      if (planets[star][i]->type != TYPE_ASTEROID &&
          (planets[star][i]->info[Playernum - 1].numsectsowned >
           planets[star][i]->Maxx * planets[star][i]->Maxy / 2))
        /* controlled planets count */
        controlled++;
      sectors += planets[star][i]->info[Playernum - 1].numsectsowned;
    }
  }
  sprintf(buf, "Controlled Planets (>50%%): %d\n", controlled);
  notify(Playernum, Governor, buf);
  sprintf(buf, "Total occupied sectors: %d\n", sectors);
  notify(Playernum, Governor, buf);
}

void
CSP_star_dump(int Playernum, int Governor)
{
  placetype       where;
  struct star    *star;
  int             i;

  if (argn < 2)
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_ERR, CSP_ERR_TOO_FEW_ARGS);
    notify(Playernum, Governor, buf);
    return;
  }
  if (argn > 3)
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_ERR, CSP_ERR_TOO_MANY_ARGS);
    notify(Playernum, Governor, buf);
    return;
  }
  if (argn == 2)
    where = Getplace(Playernum, Governor, ":", 1);
  else
    where = Getplace(Playernum, Governor, args[2], 1);

  if (where.err)
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_ERR, CSP_ERR_NOSUCH_PLACE);
    notify(Playernum, Governor, buf);
    return;
  }
  if (where.err)
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_ERR, CSP_ERR_NOSUCH_PLACE);
    notify(Playernum, Governor, buf);
    return;
  }
  if (!isset(Stars[where.snum]->explored, Playernum))
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_STAR_UNEXPL, where.snum);
    notify(Playernum, Governor, buf);
    return;
  }
  star = Stars[where.snum];
  /* intro */
  sprintf(buf, "%c %d %d %s %d %d %f %f\n", CSP_CLIENT, CSP_STARDUMP_INTRO,
          where.snum, star->name, 1,
          (isset(star->inhabited, Playernum) ? 1 : 0), star->xpos, star->ypos);
  notify(Playernum, Governor, buf);
  /* condition */
  sprintf(buf, "%c %d %d %d %d %d %f\n", CSP_CLIENT, CSP_STARDUMP_CONDITION,
          where.snum, star->stability, star->nova_stage, star->temperature,
          star->gravity);
  notify(Playernum, Governor, buf);
  /* wormhole */
  sprintf(buf, "%c %d %d %d %d\n", CSP_CLIENT, CSP_STARDUMP_WORMHOLE,
          star->wh_has_wormhole, star->wh_dest_starnum, star->wh_stability);
  notify(Playernum, Governor, buf);
  /* planets */
  for (i = 0; i < star->numplanets; i++)
  {
    sprintf(buf, "%c %d %d %d %s\n", CSP_CLIENT, CSP_STARDUMP_PLANET,
            where.snum, i, star->pnames[i]);
    notify(Playernum, Governor, buf);
  }
  sprintf(buf, "%c %d\n", CSP_CLIENT, CSP_STARDUMP_END);
  notify(Playernum, Governor, buf);
  return;
}

void
csp_planet_dump(int Playernum, int Governor)
{
  planettype     *p;
  placetype       where;
  struct plinfo  *pl;

  if (argn < 2)
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_ERR, CSP_ERR_TOO_FEW_ARGS);
    notify(Playernum, Governor, buf);
    return;
  }
  if (argn > 3)
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_ERR, CSP_ERR_TOO_MANY_ARGS);
    notify(Playernum, Governor, buf);
    return;
  }
  if (argn == 2)
    /* ignore explored (last arg) was set to 1 in JH, for both lines -mfw */
    where = Getplace(Playernum, Governor, ":", 0);
  else
    where = Getplace(Playernum, Governor, args[2], 0);

  if (where.err)
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_ERR, CSP_ERR_NOSUCH_PLACE);
    notify(Playernum, Governor, buf);
    return;
  }

  if (where.level != LEVEL_PLAN)
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_ERR, CSP_ERR_NOSUCH_PLACE);
    notify(Playernum, Governor, buf);
    return;
  }

  if (!isset(Stars[where.snum]->explored, Playernum))
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_STAR_UNEXPL, where.snum);
    notify(Playernum, Governor, buf);
    return;
  }

  getplanet(&p, (int)where.snum, (int)where.pnum);

  sprintf(buf, "%c %d %d %d %s %s\n", CSP_CLIENT, CSP_PLANDUMP_INTRO,
          where.snum, where.pnum, Stars[where.snum]->pnames[where.pnum],
          Stars[where.snum]->name);
  notify(Playernum, Governor, buf);

  pl = &p->info[Playernum - 1];
  if (pl->explored)
  {
    /* Everything but routes... */
    sprintf(buf, "%c %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n",
            CSP_CLIENT, CSP_PLANDUMP_CONDITIONS, where.snum, where.pnum,
            p->conditions[RTEMP], p->conditions[TEMP], p->conditions[METHANE],
            p->conditions[OXYGEN], p->conditions[CO2], p->conditions[HYDROGEN],
            p->conditions[NITROGEN], p->conditions[SULFUR],
            p->conditions[HELIUM], p->conditions[OTHER], p->conditions[TOXIC],
            (int)compatibility(p, races[Playernum - 1]));
    notify(Playernum, Governor, buf);

    sprintf(buf, "%c %d %d %d %d %d %d %d %d %d %ld %ld\n", CSP_CLIENT,
            CSP_PLANDUMP_STOCK, where.snum, where.pnum, pl->fuel, pl->destruct,
            pl->resource, pl->crystals, pl->tech_invest, pl->numsectsowned,
            pl->popn, pl->troops);
    notify(Playernum, Governor, buf);

    sprintf(buf, "%c %d %d %d %ld %d %d %d %d %f\n", CSP_CLIENT,
            CSP_PLANDUMP_PROD, where.snum, where.pnum, pl->prod_money,
            pl->prod_res, pl->prod_fuel, pl->prod_dest, pl->prod_crystals,
            pl->prod_tech);
    notify(Playernum, Governor, buf);

    sprintf(buf,
            "%c %d %d %d %d %d %d %d %d %d %d %ld %d %d %f %f %d %ld %ld %ld %ld %d %d %d %d\n",
            CSP_CLIENT, CSP_PLANDUMP_MISC, where.snum, where.pnum, pl->comread,
            pl->mob_set, pl->tox_thresh, pl->autorep, pl->tax, pl->newtax,
            pl->guns, pl->mob_points, p->Maxx, p->Maxy, p->xpos, p->ypos,
            p->xtals_left, p->popn, p->maxpopn, p->troops, p->total_resources,
            p->slaved_to, p->type, p->expltimer, p->explored);
    notify(Playernum, Governor, buf);
  }
  else
  {
    sprintf(buf, "%c %d %d %d\n", CSP_CLIENT, CSP_PLANDUMP_NOEXPL, where.snum,
            where.pnum);
    notify(Playernum, Governor, buf);
  }
  /* notify done */
  sprintf(buf, "%c %d\n", CSP_CLIENT, CSP_PLANDUMP_END);
  notify(Playernum, Governor, buf);

  free((char *)p);
}

void
CSP_ship_list(int Playernum, int Governor)
{
  shiptype       *s;
  planettype     *p;
  int             starnum;
  unsigned short  shipno;
  int             i, n_ships;
  unsigned char   Report_types[NUMSTYPES];

  if (argn < 2)
    return;

  for (i = 0; i < NUMSTYPES; i++)
    Report_types[i] = 1;

  Num_ships = 0;
  n_ships = Numships();

  rd =
    (reportdata *) malloc(sizeof (reportdata) *
                          (n_ships + Sdata.numstars * MAXPLANETS));
  if (!rd)
  {
    loginfo(ERRORLOG, WANTERRNO, "FATAL: Malloc failed [csp_ship_dump]");
    close_data_files();
    exit(1);
  }

  /* (one list entry for each ship, planet in universe) */

  Race = races[Playernum - 1];

  /* get ship here */
  sscanf(args[2], "%d", &starnum);
  star_getrships(Playernum, Governor, starnum);

  sprintf(buf, "| %d %d \n", CSP_SHIPLIST_INTRO, starnum);
  notify(Playernum, Governor, buf);

  for (i = 0; i < Num_ships; i++)
  {
    /* last ship gotten from disk */
    s = rd[i].s;
    p = rd[i].p;
    shipno = rd[i].n;
    if (shipno > 0 && s->owner == Playernum)
    {
      sprintf(buf, "| %d %d \n", CSP_SHIPLIST_DATA, shipno);
      notify(Playernum, Governor, buf);
    }
  }
  sprintf(buf, "%c %d \n", CSP_CLIENT, CSP_SHIPLIST_END);
  notify(Playernum, Governor, buf);

  return;
}

void
csp_ship_dump(int Playernum, int Governor)
{
  int             shipno;
  reg int         shn, i;
  int             n_ships, num;
  unsigned char   Report_types[NUMSTYPES];
  int             first_arg, tact_mode;

  for (i = 0; i < NUMSTYPES; i++)
    Report_types[i] = 1;

  Num_ships = 0;
  n_ships = Numships();

  rd =
    (reportdata *) malloc(sizeof (reportdata) *
                          (n_ships + Sdata.numstars * MAXPLANETS));
  if (!rd)
  {
    loginfo(ERRORLOG, WANTERRNO, "FATAL: Malloc failed [csp_ship_dump]");
    close_data_files();
    exit(1);
  }

  /* (one list entry for each ship, planet in universe) */

  Race = races[Playernum - 1];

  tact_mode = 1;
  first_arg = 2;

  if (argn >= 3)
  {

    if (*args[2] == 'N')
    {
      first_arg = 3;
      tact_mode = 0;            /* no tact data wanted */
    }
    /* sprintf(buf, "tactmode=%d, f=%d\n", tact_mode, first_arg);
     * notify(Playernum, Governor, buf); */
    if (*args[first_arg] == '#' || isdigit((unsigned char)*args[first_arg]))
    {
      /* report on a couple ships */
      int             l = first_arg;

      while (l < MAXARGS && *args[l] != '\0')
      {
        sscanf(args[l] + (*args[l] == '#'), "%d", &shipno);
        if (shipno > n_ships || shipno < 1)
        {
          sprintf(buf, "rst: no such ship #%d \n", shipno);
          notify(Playernum, Governor, buf);
          free((char *)rd);
          sprintf(buf, "%c %d\n", CSP_CLIENT, CSP_SHIPDUMP_END);
          notify(Playernum, Governor, buf);
          return;
        }
        (void)Getrship(Playernum, Governor, shipno);
        num = Num_ships;
        if (rd[Num_ships - 1].s->whatorbits != LEVEL_UNIV)
        {
          star_getrships(Playernum, Governor, (int)rd[num - 1].s->storbits);
          csp_ship_report(Playernum, Governor, num - 1, Report_types,
                          tact_mode);
        }
        else
          csp_ship_report(Playernum, Governor, num - 1, Report_types,
                          tact_mode);
        l++;
      }
      Free_rlist();
      sprintf(buf, "%c %d\n", CSP_CLIENT, CSP_SHIPDUMP_END);
      notify(Playernum, Governor, buf);
      return;
    }
  }

  switch (Dir[Playernum - 1][Governor].level)
  {
    case LEVEL_UNIV:
      notify(Playernum, Governor,
             "All ship dumps are not supported at universe level.\n");
      notify(Playernum, Governor,
             "You must specify specific ship numbers to do this.\n");
      free((char *)rd);         /* nothing allocated */
      sprintf(buf, "%c %d\n", CSP_CLIENT, CSP_SHIPDUMP_END);
      notify(Playernum, Governor, buf);
      return;
    case LEVEL_STAR:
    case LEVEL_PLAN:
      star_getrships(Playernum, Governor, Dir[Playernum - 1][Governor].snum);

      for (i = 0; i < Num_ships; i++)
        csp_ship_report(Playernum, Governor, i, Report_types, tact_mode);

      break;
    case LEVEL_SHIP:
      Getrship(Playernum, Governor, Dir[Playernum - 1][Governor].shipno);
      /* first ship report */
      csp_ship_report(Playernum, Governor, 0, Report_types, tact_mode);

      /* And then report on the ships it is carrying. */
      shn = rd[0].s->ships;
      Num_ships = 0;

      while (shn && Getrship(Playernum, Governor, shn))
        shn = nextship(rd[Num_ships - 1].s);

      for (i = 0; i < Num_ships; i++)
        csp_ship_report(Playernum, Governor, i, Report_types, tact_mode);

      break;
  }

  sprintf(buf, "%c %d\n", CSP_CLIENT, CSP_SHIPDUMP_END);
  notify(Playernum, Governor, buf);
  Free_rlist();
}

void
csp_ship_report(int Playernum, int Governor, int indx, unsigned char rep_on[],
                int tact_mode)
{
  shiptype       *s;
  planettype     *p;
  int             shipno;
  reg int         i, sight, caliber;
  placetype       where;
  double          Dist;
  int             fev = 0, fspeed = 0, defense, fdam = 0;
  double          tech;
  char            buf2[BUFSIZ];

  /* last ship gotten from disk */
  s = rd[indx].s;
  p = rd[indx].p;
  shipno = rd[indx].n;

  /* launched canister, non-owned ships don't show up */
  if ((rd[indx].type == PLANET && p->info[Playernum - 1].numsectsowned) ||
      (rd[indx].type != PLANET && s->alive && s->owner == Playernum &&
       (authorized(Governor, s)) && rep_on[s->type] && !(s->type == OTYPE_CANIST
                                                         && !s->docked) &&
       !(s->type == OTYPE_GREEN && !s->docked)))
  {

    if (rd[indx].type != PLANET)
    {
      sprintf(buf, "%c %d %d %d %d %d %d %d %ld %d \"%s\" \"%s\"\n", CSP_CLIENT,
              CSP_SHIPDUMP_GEN, shipno, s->type, s->active, s->damage, s->rad,
              s->governor, has_switch(s), s->build_type,
              ((s->type == OTYPE_TERRA) ||
               (s->type == OTYPE_PLOW)) ? "Standard" : s->class, s->name);
      notify(Playernum, Governor, buf);

      sprintf(buf, "%c %d %d %d %d %d %d %ld %d %ld %f %ld %d %d %d %d\n",
              CSP_CLIENT, CSP_SHIPDUMP_STOCK, shipno, s->crystals, s->hanger,
              s->max_hanger, s->resource, Max_resource(s), s->destruct,
              Max_destruct(s), s->fuel, Max_fuel(s), s->popn, s->troops,
              s->max_crew, s->cloak);
      notify(Playernum, Governor, buf);

      sprintf(buf, "%c %d %d %d %d %d %d %ld %f %ld %ld %f %d\n", CSP_CLIENT,
              CSP_SHIPDUMP_STATUS, shipno, s->hyper_drive.has, s->mount,
              s->mounted, s->type == STYPE_POD ? s->special.pod.temperature : 0,
              Armor(s), s->tech, Max_speed(s), Cost(s), Mass(s), Size(s));
      notify(Playernum, Governor, buf);

      sprintf(buf, "%c %d %d %d %d %d %d %d %d %d %d\n", CSP_CLIENT,
              CSP_SHIPDUMP_WEAPONS, shipno, s->laser, s->cew, s->cew_range,
              (int)((1.0 - .01 * s->damage) * s->tech / 4.0), s->primary,
              s->primtype, s->secondary, s->sectype);
      notify(Playernum, Governor, buf);

      sprintf(buf,
              "%c %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n",
              CSP_CLIENT, CSP_SHIPDUMP_ORDERS, shipno, s->hyper_drive.on,
              s->hyper_drive.ready, s->hyper_drive.charge, s->protect.self,
              s->fire_laser, s->focus, s->retaliate, s->protect.planet,
              s->protect.on, s->protect.ship, s->merchant, s->on,
#ifdef AUTOSCRAP
              s->autoscrap,
#else
              0,
#endif
              s->protect.evade, s->bombard, s->cloaked, s->wants_reports);
      notify(Playernum, Governor, buf);

#ifdef THRESHLOADING
      sprintf(buf, "%c %d %d ", CSP_CLIENT, CSP_SHIPDUMP_THRESH, shipno);
      for (i = 0; i <= TH_CRYSTALS; i++)
      {
        sprintf(buf2, "%d %d ", i, s->threshload[i]);
        strcat(buf, buf2);
      }
      strcat(buf, "\n");
      notify(Playernum, Governor, buf);
#endif

      sprintf(buf, "%c %d %d %d ", CSP_CLIENT, CSP_SHIPDUMP_SPECIAL, shipno,
              s->type);
      buf2[0] = '\0';
      switch (s->type)
      {
        case OTYPE_TERRA:
        case OTYPE_PLOW:
          strcpy(buf2, &(s->class[s->special.terraform.index]));
          if (buf2[i = (strlen(buf2) - 1)] == 'c')
          {
            char            c = s->class[s->special.terraform.index];

            s->class[s->special.terraform.index] = '\0';
            sprintf(buf2 + i, "%sc", s->class);
            s->class[s->special.terraform.index] = c;
          }
          break;
        case STYPE_MISSILE:
          sprintf(buf2, "%d %d %d %d", s->whatdest, s->special.impact.scatter,
                  s->special.impact.x, s->special.impact.y);
          break;
        case STYPE_MINEF:
          sprintf(buf2, "%d", s->special.trigger.radius);
          break;
        case OTYPE_TRANSDEV:
          sprintf(buf2, "%d", s->special.transport.target);
          break;
        case STYPE_MIRROR:
          sprintf(buf2, "%d %d %d %d %d", s->special.aimed_at.level,
                  s->special.aimed_at.snum, s->special.aimed_at.pnum,
                  s->special.aimed_at.shipno, s->special.aimed_at.intensity);
          break;
      }
      strcat(buf, buf2);
      strcat(buf, "\n");
      notify(Playernum, Governor, buf);

      if (s->hyper_drive.on)
      {
        double          dist, fuse;

        dist =
          sqrt(Distsq
               (s->xpos, s->ypos, Stars[s->deststar]->xpos,
                Stars[s->deststar]->ypos));

        fuse = calc_fuse(s, dist);

        /* 
         * something wrong? (kse) sprintf(buf, "%c %d %f %f %f\n", CSP_CLIENT,
         * CSP_SHIPDUMP_HYPER, shipno, dist, fuse, mfuse); */
        sprintf(buf, "%c %d %d %f %f\n", CSP_CLIENT, CSP_SHIPDUMP_HYPER, shipno,
                dist, fuse);
        notify(Playernum, Governor, buf);
      }

      if (s->type == OTYPE_FACTORY)
      {
        if ((s->build_type != 0) && (s->build_type != OTYPE_FACTORY))
        {
          sprintf(buf, "%c %d %d %d %f %f %d %d %d %d %d %d %d %d\n",
                  CSP_CLIENT, CSP_SHIPDUMP_FACTORY, shipno, s->build_cost,
                  s->complexity, s->base_mass, ship_size(s), s->armor,
                  s->max_speed, s->max_crew, s->max_fuel, s->max_resource,
                  s->max_destruct, s->max_hanger);
          notify(Playernum, Governor, buf);
        }
      }

      sprintf(buf, "%c %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %f %f\n",
              CSP_CLIENT, CSP_SHIPDUMP_DEST, shipno, s->docked, s->land_x,
              s->land_y, s->navigate.on, s->navigate.bearing, s->navigate.turns,
              s->whatdest, s->deststar, s->destpnum, s->destshipno, s->speed,
              s->whatorbits, s->storbits, s->pnumorbits, s->xpos, s->ypos);
      notify(Playernum, Governor, buf);
    }

    /* Tactical information... */
    if (rd[indx].type == PLANET)
    {
      tech = Race->tech;
      caliber = MEDIUM;
      sprintf(buf, "%c %d %d %d %f %d %d %d\n", CSP_CLIENT,
              CSP_SHIPDUMP_PTACT_GEN, rd[indx].star, rd[indx].pnum, tech,
              p->info[Playernum - 1].guns, p->info[Playernum - 1].destruct,
              p->info[Playernum - 1].fuel);
      notify(Playernum, Governor, buf);
    }
    else
    {
      where.level = s->whatorbits;
      where.snum = s->storbits;
      where.pnum = s->pnumorbits;
      tech = s->tech;
      caliber = current_caliber(s);
      if ((s->whatdest != LEVEL_UNIV || s->navigate.on) && !s->docked &&
          s->active)
      {
        fspeed = s->speed;
        fev = s->protect.evade;
      }
      fdam = s->damage;
    }

    sight = 0;
    if (rd[indx].type == PLANET)
      sight = 1;
    else if (Sight(s))
      sight = 1;

    /* tactical display */
    /* sprintf(buf, "tactmode=%d\n", tact_mode); notify(Playernum, Governor,
     * buf); */
    if (sight && tact_mode)
    {
      for (i = 0; i < Num_ships; i++)
      {
        if (i != indx &&
            (Dist =
             sqrt(Distsq(rd[indx].x, rd[indx].y, rd[i].x, rd[i].y))) <
            gun_range(Race, rd[indx].s, (rd[indx].type == PLANET)))
        {
          if (rd[i].type == PLANET)
          {
            /* 
             * tac report at
             * planet
             */
            if (rd[indx].type == PLANET)
            {
              sprintf(buf, "%c %d %d %d %d %d %f\n", CSP_CLIENT,
                      CSP_SHIPDUMP_PTACT_PDIST, rd[indx].star, rd[indx].pnum,
                      rd[i].star, rd[i].pnum, Dist);
              notify(Playernum, Governor, buf);
            }
            else
            {
              sprintf(buf, "%c %d %d %d %d %f\n", CSP_CLIENT,
                      CSP_SHIPDUMP_STACT_PDIST, shipno, rd[i].star, rd[i].pnum,
                      Dist);
              notify(Playernum, Governor, buf);
            }
          }
          else
          {
            if (!see_cloaked(&rd[i], &rd[indx], Dist))
              goto NextLoop;
            /* 
             * tac report at
             * ship
             */
            if ((rd[i].s->owner != Playernum || !authorized(Governor, rd[i].s))
                && rd[i].s->alive && rd[i].s->type != OTYPE_CANIST &&
                rd[i].s->type != OTYPE_GREEN)
            {
              int             tev = 0, tspeed = 0, body = 0, prob = 0;
              int             factor = 0;

              if ((rd[i].s->whatdest != LEVEL_UNIV || rd[i].s->navigate.on) &&
                  !rd[i].s->docked && rd[i].s->active)
              {
                tspeed = rd[i].s->speed;
                tev = rd[i].s->protect.evade;
              }
              body = Size(rd[i].s);
              defense = getdefense(rd[i].s);
              prob =
                hit_odds(Dist, &factor, tech, fdam, fev, tev, fspeed, tspeed,
                         body, caliber, defense);
              if (rd[indx].type != PLANET && laser_on(rd[indx].s) &&
                  rd[indx].s->focus)
                prob = prob * prob / 100;

              if (rd[indx].type == PLANET)
              {
                sprintf(buf,
                        "%c %d %d %d %d %d %d %d %d %d %f %d %d %d %d %d %d %d %d %d \"%s\" %f %f\n",
                        CSP_CLIENT, CSP_SHIPDUMP_PTACT_INFO, rd[indx].star,
                        rd[indx].pnum, caliber, rd[i].n, rd[i].s->owner,
                        rd[i].s->governor, rd[i].s->type, rd[i].s->active, Dist,
                        factor, body, tspeed, tev, prob, rd[i].s->damage,
                        landed(rd[i].s), rd[i].s->land_x, rd[i].s->land_y,
                        rd[i].s->name, rd[i].s->xpos, rd[i].s->ypos);
              }
              else
              {
                sprintf(buf,
                        "%c %d %d %d %d %d %d %d %d %f %d %d %d %d %d %d %d %d %d \"%s\" %f %f\n",
                        CSP_CLIENT, CSP_SHIPDUMP_STACT_INFO, shipno, caliber,
                        rd[i].n, rd[i].s->owner, rd[i].s->governor,
                        rd[i].s->type, rd[i].s->active, Dist, factor, body,
                        tspeed, tev, prob, rd[i].s->damage, landed(rd[i].s),
                        rd[i].s->land_x, rd[i].s->land_y, rd[i].s->name,
                        rd[i].s->xpos, rd[i].s->ypos);
              }

              notify(Playernum, Governor, buf);
            }
          }
        }
      NextLoop:;
      }
    }
  }
}

void
csp_univ_dump(int Playernum, int Governor)
{
  reg int         i;
  double          dist, x, y;
  int             max;

  if (argn < 2)
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_ERR, CSP_ERR_TOO_FEW_ARGS);
    notify(Playernum, Governor, buf);
    return;
  }

  if (argn > 3)
  {
    sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_ERR, CSP_ERR_TOO_MANY_ARGS);
    notify(Playernum, Governor, buf);
    return;
  }

  if (argn > 3)
    max = atoi(args[3]);
  else
    max = 999999;

  /* intro */
  sprintf(buf, "%c %d %d %d %s\n", CSP_CLIENT, CSP_UNIVDUMP_INTRO,
          Sdata.numstars, UNIVSIZE, GAL_NAME);
  notify(Playernum, Governor, buf);

  x = Dir[Playernum - 1][Governor].lastx[1];
  y = Dir[Playernum - 1][Governor].lasty[1];

  /* star */
  for (i = 0; i < Sdata.numstars; i++)
  {
    dist = sqrt(Distsq(Stars[i]->xpos, Stars[i]->ypos, x, y));

    if ((int)dist <= max)
    {
      sprintf(buf, "%c %d %d %s %.0f %.0f %.0f\n", CSP_CLIENT,
              CSP_UNIVDUMP_STAR, i, Stars[i]->name, Stars[i]->xpos,
              Stars[i]->ypos, dist);
      notify(Playernum, Governor, buf);
    }
  }

  /* end */
  sprintf(buf, "%c %d\n", CSP_CLIENT, CSP_UNIVDUMP_END);
  notify(Playernum, Governor, buf);

  return;
}
