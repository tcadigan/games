/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)fire.c        1.9 12/3/93 "
 * 
 * fire.c -- fire at ship or planet from ship or planet
 *
 * $Header: /var/cvs/gbp/GB+/user/fire.c,v 1.5 2007/07/06 18:06:56 gbp Exp $
 */

#include <stdlib.h>
#include <string.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "ranks.h"
#include "buffers.h"

EXTERN void     fire(int, int, int, int);
EXTERN void     bombard(int, int, int);
EXTERN void     defend(int, int, int);
EXTERN void     detonate(int, int, int);
EXTERN int      retal_strength(shiptype *);
EXTERN int      adjacent(int, int, int, int, planettype *);
EXTERN int      landed(shiptype *);
EXTERN void     check_overload(shiptype *, int, int *);
EXTERN void     check_retal_strength(shiptype *, int *);
EXTERN int      laser_on(shiptype *);

#include "proto.h"

void
fire(int Playernum, int Governor, int APcount, int cew)
{                               /* ship vs ship */
  int             fromship, toship, nextshipno, haveship, sh = -1;
  shiptype       *from, *to, *ship, dummy;
  planettype     *p, *planet;
  int             strength, maxstrength, retal, damage;

  /* check to see if past First Combat update */
  if (get_num_updates() < CombatUpdate)
  {
    sprintf(buf, "fire command is disabled until after Combat Update: [%d]\n",
            CombatUpdate);
    notify(Playernum, Governor, buf);
    return;
  }

  /* for telegramming and retaliating */
  memset((char *)Nuked, 0, sizeof (Nuked));

  if (argn < 3)
  {
    notify(Playernum, Governor,
           "Syntax: 'fire <ship> <target> [<strength>]'.\n");
    return;
  }
  nextshipno = start_shiplist(Playernum, Governor, args[1]);
  while ((fromship = do_shiplist(&from, &nextshipno)))
    if (in_list(Playernum, args[1], from, &nextshipno))
    {

      if (!from->active)
      {
        sprintf(buf, "%s is irradiated and inactive.\n", Ship(from));
        notify(Playernum, Governor, buf);
        free((char *)from);
        continue;
      }
      if (from->type == STYPE_MINEF)
      {
        notify(Playernum, Governor,
               "That ship is not designed to be fired manually\n");
        free((char *)from);
        continue;
      }

      if (from->whatorbits == LEVEL_UNIV)
      {
        if (!enufAP(Playernum, Governor, Sdata.AP[Playernum - 1], APcount))
        {
          free((char *)from);
          continue;
        }
      }
      else
        if (!enufAP
            (Playernum, Governor, Stars[from->storbits]->AP[Playernum - 1],
             APcount))
      {
        free((char *)from);
        continue;
      }
      if (cew)
      {
        if (!from->cew)
        {
          notify(Playernum, Governor,
                 "That ship is not equipped to fire CEWs.\n");
          free((char *)from);
          continue;
        }
        if (!from->mounted)
        {
          notify(Playernum, Governor,
                 "You need to have a crystal mounted to fire CEWs.\n");
          free((char *)from);
          continue;
        }
      }
      sscanf(args[2] + (args[2][0] == '#'), "%d", &toship);
      if (toship <= 0)
      {
        notify(Playernum, Governor, "Bad ship number.\n");
        free((char *)from);
        continue;
      }
      if (toship == fromship)
      {
        notify(Playernum, Governor,
               "Here I am, a brain the size of a universe, and you test me this way?\n");
        free((char *)from);
        continue;
      }
      if (!getship(&to, toship))
      {
        free((char *)from);
        continue;
      }
      if (races[to->owner - 1]->Guest)
      {
        notify(Playernum, Governor, "You may not attack Guest ships.\n");
        free((char *)from);
        free((char *)to);
        continue;
      }
      /* save defense attack strength for retaliation */
      check_retal_strength(to, &retal);
      memcpy(&dummy, to, sizeof (shiptype));

      if (from->type == OTYPE_AFV)
      {
        if (!landed(from))
        {
          sprintf(buf, "%s isn't landed on a planet!\n", Ship(from));
          notify(Playernum, Governor, buf);
          free((char *)from);
          free((char *)to);
          continue;
        }
        if (!landed(to))
        {
          sprintf(buf, "%s isn't landed on a planet!\n", Ship(from));
          notify(Playernum, Governor, buf);
          free((char *)from);
          free((char *)to);
          continue;
        }
      }
      if (landed(from) && landed(to))
      {
        if ((from->storbits != to->storbits) ||
            (from->pnumorbits != to->pnumorbits))
        {
          notify(Playernum, Governor,
                 "Landed ships can only attack other landed ships if they are on the same planet!\n");
          free((char *)from);
          free((char *)to);
          continue;
        }
        getplanet(&p, (int)from->storbits, (int)from->pnumorbits);
        if (!adjacent
            ((int)from->land_x, (int)from->land_y, (int)to->land_x,
             (int)to->land_y, p))
        {
          notify(Playernum, Governor, "You are not adjacent to your target!\n");
          free((char *)from);
          free((char *)to);
          free((char *)p);
          continue;
        }
        free((char *)p);
      }
      if (cew)
      {
        if (from->fuel < (double)from->cew)
        {
          sprintf(buf, "You need %d fuel to fire CEWs.\n", from->cew);
          notify(Playernum, Governor, buf);
          free((char *)from);
          free((char *)to);
          continue;
        }
        else if (landed(from) || landed(to))
        {
          notify(Playernum, Governor,
                 "CEWs cannot originate from or targeted to ships landed on planets.\n");
          free((char *)from);
          free((char *)to);
          continue;
        }
        else
        {
          sprintf(buf, "CEW strength %d.\n", from->cew);
          notify(Playernum, Governor, buf);
          strength = from->cew / 2;
        }
      }
      else
      {
        check_retal_strength(from, &maxstrength);

        if (argn >= 4)
          sscanf(args[3], "%d", &strength);
        else
          check_retal_strength(from, &strength);

        if (strength > maxstrength)
        {
          strength = maxstrength;
          sprintf(buf, "%s set to %d\n",
                  laser_on(from) ? "Laser strength" : "Guns", strength);
          notify(Playernum, Governor, buf);
        }
      }

      /* check to see if there is crystal overloads */
      if (laser_on(from) || cew)
        check_overload(from, cew, &strength);

      if (strength <= 0)
      {
        sprintf(buf, "No attack. (no strength specified) \n");
        notify(Playernum, Governor, buf);
        putship(from);
        free((char *)from);
        free((char *)to);
        continue;
      }

      /* check for smart guns from Hap -mfw */
      if (from->smart_gun)
      {
        int             ip;

        ip = 0;
        from->smart_fire = 0;

        while (from->smart_list[ip] && !from->smart_fire)
        {
          if (from->smart_list[ip] == Shipltrs[to->type])
          {
            if (from->smart_gun == PRIMARY)
              strength = MIN(from->primary, from->smart_strength);
            else
              strength = MIN(from->secondary, from->smart_strength);

            from->smart_fire = 1;

            notify((int)from->owner, from->governor, "Smart guns activated!\n");
          }                     /* if match */
          ip++;
        }                       /* while */
      }                         /* if smart */

      damage =
        shoot_ship_to_ship(from, to, strength, cew, 0, long_buf, short_buf);

      if (damage < 0)
      {
        notify(Playernum, Governor, "Illegal attack.\n");
        free((char *)from);
        free((char *)to);
        continue;
      }
      if (laser_on(from) || cew)
        use_fuel(from, 2.0 * (double)strength);
      else
      {
        /* HUT modification (tze) : if ship has not destruction loaded it uses
         * planetary stockpile */
        if (from->destruct < strength)
        {
          getplanet(&planet, from->storbits, from->pnumorbits);
          planet->info[from->owner - 1].destruct -=
            MIN(planet->info[from->owner - 1].destruct,
                strength - from->destruct);
          use_destruct(from, from->destruct);
          putplanet(planet, from->storbits, from->pnumorbits);
          free((char *)planet);
        }
        else
          use_destruct(from, strength);
      }
      /* use_destruct(from, strength); */

      if (!to->alive)
        post(short_buf, COMBAT);
      notify_star(Playernum, Governor, (int)to->owner, (int)from->storbits,
                  short_buf);
      warn((int)to->owner, (int)to->governor, long_buf);
      notify(Playernum, Governor, long_buf);
      /* defending ship retaliates */

      strength = 0;

      if (retal && damage && to->protect.self)
      {
        strength = retal;
#ifdef USE_VN
        /* 
         * CWL berserkers vary how much destruct to use against a foe missiles,
         * mines, pods, explorers, SETI, and shuttles get 10 guns fired at them.
         * Everything else gets fullload
         */
        if (to->type == OTYPE_BERS)
        {
          if (from->type == STYPE_MISSILE || from->type == STYPE_MINEF ||
              from->type == STYPE_SHUTTLE || from->type == STYPE_POD ||
              from->type == OTYPE_SETI)
          {
            strength = 10;
          }
          else if (from->type == OTYPE_GR || from->type == STYPE_EXPLORER)
          {
            strength = 20;
          }
          strength = MIN(dummy.primary, strength);
        }                       /* end CWL */
#endif

        /* smart gun retaliate from Hap -mfw */
        if (to->smart_gun)
        {
          int             ip;

          ip = 0;
          to->smart_fire = 0;

          while (to->smart_list[ip] && !to->smart_fire)
          {
            if (to->smart_list[ip] == Shipltrs[from->type])
            {
              if (to->smart_gun == PRIMARY)
                strength = MIN(dummy.primary, to->smart_strength);
              else
                strength = MIN(dummy.secondary, to->smart_strength);

              to->smart_fire = 1;

              warn((int)to->owner, (int)to->governor, "Smart gun activated!\n");
            }                   /* from ship is in our smart list */
            ip++;
          }                     /* while */
        }                       /* smart retaliate */

        if (laser_on(to))
          check_overload(to, 0, &strength);

        if ((damage =
             shoot_ship_to_ship(&dummy, from, strength, 0, 1, long_buf,
                                short_buf)) >= 0)
        {
          if (laser_on(to))
            use_fuel(to, 2.0 * (double)strength);
          else
          {
            /* HUT modification (tze) : if ship has not destruction loaded it
             * uses planetary stockpile */
            if (to->destruct < strength)
            {
              getplanet(&planet, to->storbits, to->pnumorbits);
              planet->info[to->owner - 1].destruct -=
                MIN(planet->info[to->owner - 1].destruct,
                    strength - to->destruct);
              use_destruct(to, to->destruct);
              putplanet(planet, to->storbits, to->pnumorbits);
              free((char *)planet);
            }
            else
              use_destruct(to, strength);
          }
          /* use_destruct(to, strength); */

          if (!from->alive)
            post(short_buf, COMBAT);
          notify_star(Playernum, Governor, (int)to->owner, (int)from->storbits,
                      short_buf);
          notify(Playernum, Governor, long_buf);
          warn((int)to->owner, (int)to->governor, long_buf);
        }
      }
      /* 
       * protecting ships retaliate individually if damage
       * was inflicted
       */
      /* AFVs immune to retaliation of this type */
      if (damage && from->alive && from->type != OTYPE_AFV)
      {
        /* star level ships */
        if (to->whatorbits == LEVEL_STAR)
          sh = Stars[to->storbits]->ships;

        /* planet level ships */
        if (to->whatorbits == LEVEL_PLAN)
        {
          getplanet(&p, (int)to->storbits, (int)to->pnumorbits);
          sh = p->ships;
          free((char *)p);
        }

        while (sh && from->alive)
        {
          // XXX: Infinite loop possibility here, I think -mfw

          haveship = getship(&ship, sh);

          if (ship->protect.on && (ship->protect.ship == toship) &&
              (ship->protect.ship == toship) && sh != fromship && sh != toship
              && ship->alive && ship->active)
          {
            check_retal_strength(ship, &strength);

            /* smart gun protect from Hap -mfw */
            if (ship->smart_gun)
            {
              int             ip;

              ip = 0;
              ship->smart_fire = 0;

              while (ship->smart_list[ip] && !ship->smart_fire)
              {
                if (ship->smart_list[ip] == Shipltrs[from->type])
                {
                  if (ship->smart_gun == PRIMARY)
                    strength = MIN(ship->primary, ship->smart_strength);
                  else
                    strength = MIN(ship->secondary, ship->smart_strength);

                  ship->smart_fire = 1;

                  warn((int)to->owner, (int)to->governor,
                       "Smart gun activated!\n");
                }               /* from ship is in our smart list */
                ip++;
              }                 /* while */
            }                   /* smart protect */

            if (laser_on(ship))
              check_overload(ship, 0, &strength);

            if ((damage =
                 shoot_ship_to_ship(ship, from, strength, 0, 0, long_buf,
                                    short_buf)) >= 0)
            {
              if (laser_on(ship))
                use_fuel(ship, 2.0 * (double)strength);
              else
              {
                /* HUT modification (tze) : if ship has not destruction loaded
                 * it uses planetary stockpile */
                if (ship->destruct < strength)
                {
                  getplanet(&planet, ship->storbits, ship->pnumorbits);
                  planet->info[ship->owner - 1].destruct -=
                    MIN(planet->info[ship->owner - 1].destruct,
                        strength - ship->destruct);
                  use_destruct(ship, ship->destruct);
                  putplanet(planet, ship->storbits, ship->pnumorbits);
                  free((char *)planet);
                }
                else
                  use_destruct(ship, strength);
              }
              /* use_destruct(ship, strength); */

              if (!from->alive)
                post(short_buf, COMBAT);
              notify_star(Playernum, Governor, (int)ship->owner,
                          (int)from->storbits, short_buf);
              notify(Playernum, Governor, long_buf);
              warn((int)ship->owner, (int)ship->governor, long_buf);
            }
            putship(ship);
          }

          if (haveship)
          {
            sh = nextship(ship);
            free((char *)ship);
          }
          else
          {
            sh = 0;
          }

          haveship = 0;
        }
      }
      putship(from);
      putship(to);
      deductAPs(Playernum, Governor, APcount, (int)from->storbits, 0);

      free((char *)from);
      free((char *)to);
    }
    else
      free((char *)from);
}

/* ship vs planet */
void
bombard(int Playernum, int Governor, int APcount)
{
  int             fromship, nextshipno;
  shiptype       *from;
  planettype     *planet;
  int             strength, maxstrength, x, y, i;
  racetype       *Race;

  /* check to see if past First Combat update */
  if (get_num_updates() < CombatUpdate)
  {
    sprintf(buf,
            "bombard command is disabled until after Combat Update: [%d]\n",
            CombatUpdate);
    notify(Playernum, Governor, buf);
    return;
  }

  if (argn < 2)
  {
    notify(Playernum, Governor,
           "Syntax: 'bombard <ship> [<x,y> [<strength>]]'.\n");
    return;
  }

  Race = races[Playernum - 1];

  nextshipno = start_shiplist(Playernum, Governor, args[1]);

  while ((fromship = do_shiplist(&from, &nextshipno)))
  {
    if (in_list(Playernum, args[1], from, &nextshipno))
    {
      if (from->storbits != Dir[Playernum - 1][Governor].snum ||
          from->pnumorbits != Dir[Playernum - 1][Governor].pnum)
      {
        notify(Playernum, Governor,
               "Change scope to the planet this ship is orbiting.\n");
        free((char *)from);
        return;
      }

      if (!enufAP
          (Playernum, Governor, Stars[from->storbits]->AP[Playernum - 1],
           APcount))
      {
        /* Not enough APs */
        sprintf(buf, "Not enough APs for %s.\n", Ship(from));
        notify(Playernum, Governor, buf);
        free((char *)from);
        continue;
      }

      if (from->whatorbits != LEVEL_PLAN)
      {
        sprintf(buf, "%s must be in orbit around a planet to bombard.\n",
                Ship(from));
        notify(Playernum, Governor, buf);
        free((char *)from);
        continue;
      }

      if (!from->active)
      {
        sprintf(buf, "%s is irradiated and inactive.\n", Ship(from));
        notify(Playernum, Governor, buf);
        free((char *)from);
        continue;
      }

      if (from->type == OTYPE_AFV && !landed(from))
      {
        sprintf(buf, "%s is not landed on the planet.\n", Ship(from));
        notify(Playernum, Governor, buf);
        free((char *)from);
        continue;
      }

      check_retal_strength(from, &maxstrength);

      if (argn > 3)
        sscanf(args[3], "%d", &strength);
      else
        check_retal_strength(from, &strength);

      if (strength > maxstrength)
      {
        strength = maxstrength;
        sprintf(buf, "%s set to %d\n",
                laser_on(from) ? "Laser strength" : "Guns", strength);
        notify(Playernum, Governor, buf);
      }

      /* check to see if there is crystal overload */
      if (laser_on(from))
        check_overload(from, 0, &strength);

      if (strength <= 0)
      {
        sprintf(buf, "No attack. (no strength specified)\n");
        notify(Playernum, Governor, buf);
        putship(from);
        free((char *)from);
        continue;
      }

      /* get planet */
      getplanet(&planet, (int)from->storbits, (int)from->pnumorbits);

      /* Make sure we're not bombarding a guest planet -mfw */
      for (i = 1; i <= Num_races; i++)
      {
        if (i != Playernum && planet->info[i - 1].popn)
        {
          if (races[i - 1]->Guest)
          {
            notify(Playernum, Governor, "Can't bombard a Guest's planet.\n");
            free((char *)from);
            free((char *)planet);
            continue;
          }
        }
      }

#ifdef USE_WHORMHOLE
      if (p->type == TYPE_WORMHOLE)
      {
        if (Race->tech >= TECH_WORMHOLE || Race->God)
          sprintf(buf, "The bombs would just disappear into the wormhole.\n");
        else
          sprintf(buf, "There is no surface to bomb.\n");

        notify(Playernum, Governor, buf);
        free((char *)planet);
        free((char *)from);
        continue;
      }
#endif

      if (argn > 2)
      {
        sscanf(args[2], "%d,%d", &x, &y);

        if (x < 0 || x > planet->Maxx - 1 || y < 0 || y > planet->Maxy - 1)
        {
          notify(Playernum, Governor, "Illegal sector.\n");
          free((char *)planet);
          free((char *)from);
          continue;
        }
      }
      else
      {
        /* the auto_bomb() function is going to pick the coords */
        x = -1;
        y = -1;
      }

      if (landed(from) &&
          !adjacent((int)from->land_x, (int)from->land_y, x, y, planet))
      {
        notify(Playernum, Governor, "You are not adjacent to that sector.\n");
        free((char *)planet);
        free((char *)from);
        continue;
      }

      (void)auto_bomb(from, planet, x, y, strength, 0);

      /* write the stuff to disk */
      putship(from);

      putplanet(planet, (int)from->storbits, (int)from->pnumorbits);

      deductAPs(Playernum, Governor, APcount, (int)from->storbits, 0);

      free((char *)planet);
    }

    free((char *)from);
  }
}

#ifdef DEFENSE
void
defend(int Playernum, int Governor, int APcount)
{                               /* planet vs ship */
  int             toship, sh;
  shiptype       *to, *ship, dummy;
  planettype     *p;
  sectortype     *sect;
  int             strength, retal, damage, x, y;
  int             numdest;
  racetype       *Race;

  /* check to see if past First Combat update */
  if (get_num_updates() < CombatUpdate)
  {
    sprintf(buf, "defend command is disabled until after Combat Update: [%d]\n",
            CombatUpdate);
    notify(Playernum, Governor, buf);
    return;
  }

  /* for telegramming and retaliating */
  memset((char *)Nuked, 0, sizeof (Nuked));

  /* get the planet from the players current scope */
  if (Dir[Playernum - 1][Governor].level != LEVEL_PLAN)
  {
    notify(Playernum, Governor, "You have to set scope to the planet first.\n");
    return;
  }
  if (argn < 3)
  {
    notify(Playernum, Governor,
           "Syntax: 'defend <ship> <sector> [<strength>]'.\n");
    return;
  }

  sscanf(args[1] + (args[1][0] == '#'), "%d", &toship);
  if (toship <= 0)
  {
    notify(Playernum, Governor, "Bad ship number.\n");
    return;
  }
  if (!enufAP
      (Playernum, Governor,
       Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1], APcount))
  {
    return;
  }
  getplanet(&p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);

  if (!p->info[Playernum - 1].numsectsowned)
  {
    notify(Playernum, Governor, "You do not occupy any sectors here.\n");
    free((char *)p);
    return;
  }
  if (p->slaved_to && p->slaved_to != Playernum)
  {
    notify(Playernum, Governor, "This planet is enslaved.\n");
    free((char *)p);
    return;
  }
  if (!getship(&to, toship))
  {
    free((char *)p);
    return;
  }
  if (to->whatorbits != LEVEL_PLAN)
  {
    notify(Playernum, Governor, "The ship is not in planet orbit.\n");
    free((char *)to);
    free((char *)p);
    return;
  }
  if (to->storbits != Dir[Playernum - 1][Governor].snum ||
      to->pnumorbits != Dir[Playernum - 1][Governor].pnum)
  {
    notify(Playernum, Governor, "Target is not in orbit around this planet.\n");
    free((char *)to);
    free((char *)p);
    return;
  }
  if (landed(to))
  {
    notify(Playernum, Governor, "Planet guns can't fire on landed ships.\n");
    free((char *)to);
    free((char *)p);
    return;
  }
  if (races[to->owner - 1]->Guest)
  {
    notify(Playernum, Governor, "Can't fire on Guest ships.\n");
    free((char *)to);
    free((char *)p);
    return;
  }
  /* save defense strength for retaliation */
  check_retal_strength(to, &retal);
  memcpy(&dummy, to, sizeof (shiptype));
  if (argn >= 3)
    sscanf(args[2], "%d,%d", &x, &y);

  if (x < 0 || x > p->Maxx - 1 || y < 0 || y > p->Maxy - 1)
  {
    notify(Playernum, Governor, "Illegal sector.\n");
    free((char *)p);
    free((char *)to);
    return;
  }
  if (!getsector(&sect, p, x, y))
  {
    notify(Playernum, Governor, "Error in sector database, notify deity.\n");
    free((char *)p);
    free((char *)to);
    return;
  }

  /* check to see if you own the sector */
  if (sect->owner != Playernum)
  {
    notify(Playernum, Governor, "Nice try.\n");
    free((char *)sect);
    free((char *)p);
    free((char *)to);
    return;
  }
  free((char *)sect);

  if (argn >= 4)
    sscanf(args[3], "%d", &strength);
  else
    strength = p->info[Playernum - 1].guns;

  strength = MIN(strength, p->info[Playernum - 1].destruct);
  strength = MIN(strength, p->info[Playernum - 1].guns);

  if (strength <= 0)
  {
    sprintf(buf, "No attack - %d guns, %dd\n", p->info[Playernum - 1].guns,
            p->info[Playernum - 1].destruct);
    notify(Playernum, Governor, buf);
    free((char *)p);
    free((char *)to);
    return;
  }
  Race = races[Playernum - 1];

  damage = shoot_planet_to_ship(Race, p, to, strength, long_buf, short_buf);

  if (!to->alive && to->type == OTYPE_TOXWC)
  {
    /* get planet again since toxicity probably has changed */
    free((char *)p);
    getplanet(&p, Dir[Playernum - 1][Governor].snum,
              Dir[Playernum - 1][Governor].pnum);
  }
  if (damage < 0)
  {
    sprintf(buf, "Target out of range  %.2d!\n", SYSTEMSIZE);
    notify(Playernum, Governor, buf);
    free((char *)p);
    free((char *)to);
    return;
  }
  if (p->info[Playernum - 1].destruct < strength)
    p->info[Playernum - 1].destruct = 0;
  else
    p->info[Playernum - 1].destruct -= strength;
  if (!to->alive)
    post(short_buf, COMBAT);
  notify_star(Playernum, Governor, (int)to->owner, (int)to->storbits,
              short_buf);
  warn((int)to->owner, (int)to->governor, long_buf);
  notify(Playernum, Governor, long_buf);

  /* defending ship retaliates */

  strength = 0;
  if (retal && damage && to->protect.self)
  {
    strength = retal;
    if (laser_on(to))
      check_overload(to, 0, &strength);

    if ((numdest =
         shoot_ship_to_planet(&dummy, p, strength, x, y, 1, 0, 0, long_buf,
                              short_buf)) >= 0)
    {
      if (laser_on(to))
        use_fuel(to, 2.0 * (double)strength);
      else
        use_destruct(to, strength);

      post(short_buf, COMBAT);
      notify_star(Playernum, Governor, (int)to->owner, (int)to->storbits,
                  short_buf);
      notify(Playernum, Governor, long_buf);
      warn((int)to->owner, (int)to->governor, long_buf);
    }
  }
  /* protecting ships retaliate individually if damage was inflicted */
  if (damage)
  {
    sh = p->ships;
    while (sh)
    {
      (void)getship(&ship, sh);
      if (ship->protect.on && (ship->protect.ship == toship) &&
          (ship->protect.ship == toship) && sh != toship && ship->alive &&
          ship->active)
      {
        if (laser_on(ship))
          check_overload(ship, 0, &strength);
        check_retal_strength(ship, &strength);

        if ((numdest =
             shoot_ship_to_planet(ship, p, strength, x, y, 1, 0, 0, long_buf,
                                  short_buf)) >= 0)
        {

          if (laser_on(ship))
            use_fuel(ship, 2.0 * (double)strength);
          else
            use_destruct(ship, strength);
          post(short_buf, COMBAT);
          notify_star(Playernum, Governor, (int)ship->owner,
                      (int)ship->storbits, short_buf);
          notify(Playernum, Governor, long_buf);
          warn((int)ship->owner, (int)ship->governor, long_buf);
        }
        putship(ship);
      }
      sh = nextship(ship);
      free((char *)ship);
    }
  }
  /* write the ship stuff out to disk */
  putship(to);
  putplanet(p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);
  deductAPs(Playernum, Governor, APcount, Dir[Playernum - 1][Governor].snum, 0);

  free((char *)p);
  free((char *)to);

  return;
}
#endif

void
detonate(int Playernum, int Governor, int APcount)
{
  shiptype       *s;
  int             shipno, nextshipno;

  /* check to see if past Combat Update */
  if (get_num_updates() < CombatUpdate)
  {
    sprintf(buf,
            "detonate command is disabled until after Combat Update: [%d]\n",
            CombatUpdate);
    notify(Playernum, Governor, buf);
    return;
  }

  nextshipno = start_shiplist(Playernum, Governor, args[1]);

  while ((shipno = do_shiplist(&s, &nextshipno)))
    if (in_list(Playernum, args[1], s, &nextshipno))
    {

      if (s->type != STYPE_MINEF)
      {
        notify(Playernum, Governor, "That is not a mine.\n");
        free((char *)s);
        continue;
      }
      else if (!s->on)
      {
        notify(Playernum, Governor, "The mine is not activated.\n");
        free((char *)s);
        continue;
      }
      else if (s->docked || s->whatorbits == LEVEL_SHIP)
      {
        notify(Playernum, Governor, "The mine is docked or landed.\n");
        free((char *)s);
        continue;
      }
      free((char *)s);
      do_mine(shipno, 1);
    }
    else
      free((char *)s);
}

int
retal_strength(shiptype * s)
{
  int             strength = 0, avail = 0;
  planettype     *p;

  if (!s->alive)
    return 0;
  if (!Shipdata[s->type][ABIL_SPEED] && !landed(s))
    return 0;
  /* land based ships */
#ifndef USE_VN
  if (!s->popn)
#else
  if (!s->popn && (s->type != OTYPE_BERS))
#endif
    return 0;

#ifndef USE_VN
  if (s->guns == PRIMARY)
    avail = (s->type == STYPE_FIGHTER ||
             s->type == OTYPE_AFV) ? s->primary : MIN(s->popn, s->primary);
  else if (s->guns == SECONDARY)
    avail = (s->type == STYPE_FIGHTER ||
             s->type == OTYPE_AFV) ? s->secondary : MIN(s->popn, s->secondary);
  else
    avail = 0;
#else
  if (s->guns == PRIMARY)
    avail = (s->type == STYPE_FIGHTER || s->type == OTYPE_AFV ||
             s->type == OTYPE_BERS) ? s->primary : MIN(s->popn, s->primary);
  else if (s->guns == SECONDARY)
    avail = (s->type == STYPE_FIGHTER || s->type == OTYPE_AFV ||
             s->type == OTYPE_BERS) ? s->secondary : MIN(s->popn, s->secondary);
  else
    avail = 0;
#endif

  avail = MIN(s->retaliate, avail);

  /* HUT modification (tze) : landed ships can use planetary stockpile directly 
   */
  if ((avail > s->destruct) && landed(s))
  {
    getplanet(&p, (int)s->storbits, (int)s->pnumorbits);
    strength =
      MIN(s->destruct +
          planets[s->storbits][s->pnumorbits]->info[s->owner - 1].destruct,
          avail);
    free((char *)p);
  }
  else
    strength = MIN(s->destruct, avail);

  /* 
   * fprintf (stderr,
   * "\nn:o=%d\navail=%d\ns->destruct=%d\ns->owner=%d\nlanded=%d\n(%s/%s):p->destruct=%d\n 
   * p->destruct=%d\n p->destruct=%d\n ", s->number, avail, s->destruct,
   * s->owner, landed(s), Stars[s->storbits]->name,
   * Stars[s->storbits]->pnames[s->pnumorbits],
   * planets[s->storbits][s->pnumorbits]->info[s->owner-1].destruct); */
  /* strength = MIN(s->destruct, avail); */

  return strength;
}

int
adjacent(int fx, int fy, int tx, int ty, planettype * p)
{
  if (abs(fy - ty) <= 1)
  {
    if (abs(fx - tx) <= 1)
      return 1;
    else if (fx == p->Maxx - 1 && tx == 0)
      return 1;
    else if (fx == 0 && tx == p->Maxx - 1)
      return 1;
    else
      return 0;
  }
  else
    return 0;
}

int
landed(shiptype * ship)
{
  return (ship->whatdest == LEVEL_PLAN && ship->docked);
}

void
check_overload(shiptype * ship, int cew, int *strength)
{
  if ((ship->laser && ship->fire_laser) || cew)
  {
    if (int_rand(0, *strength) >
        (int)((1.0 - .01 * ship->damage) * ship->tech / 2.0))
    {
      /* check to see if the ship blows up */
      sprintf(buf,
              "%s: Matter-antimatter EXPLOSION from overloaded crystal on %s\n",
              Dispshiploc(ship), Ship(ship));
      kill_ship((int)(ship->owner), ship);
      *strength = 0;
      warn((int)ship->owner, (int)ship->governor, buf);
      post(buf, COMBAT);
      notify_star((int)ship->owner, (int)ship->governor, 0, (int)ship->storbits,
                  buf);
    }
    else if (int_rand(0, *strength) >
             (int)((1.0 - .01 * ship->damage) * ship->tech / 4.0))
    {
      sprintf(buf, "%s: Crystal damaged from overloading on %s.\n",
              Dispshiploc(ship), Ship(ship));
      ship->fire_laser = 0;
      ship->mounted = 0;
      *strength = 0;
      warn((int)ship->owner, (int)ship->governor, buf);
    }
  }
}

void
check_retal_strength(shiptype * ship, int *strength)
{
  *strength = 0;
  if (ship->active && ship->alive)
  {                             /* irradiated ships dont * retaliate */
    if (laser_on(ship))
      *strength = MIN(ship->fire_laser, (int)ship->fuel / 2);
    else
      *strength = retal_strength(ship);
  }
}

int
laser_on(shiptype * ship)
{
  return (ship->laser && ship->fire_laser);
}
