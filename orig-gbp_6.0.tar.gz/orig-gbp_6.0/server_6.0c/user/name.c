/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)name.c        1.13 12/3/93 "
 * 
 * name.c -- rename something to something else
 * announce.c -- make announcements in the system you currently in. You
 * must be inhabiting that system for your message to sent. You must also
 * be in that system (and inhabiting) to receive announcements.
 * page.c -- send a message to a player requesting his presence in a system.
 
 $Header: /var/cvs/gbp/GB+/user/name.c,v 1.6 2007/07/06 18:09:34 gbp Exp $
 */

#include <ctype.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "races.h"
#include "power.h"
#include "ships.h"
#include "buffers.h"
#include "config.h"
#include "ranks.h"
#include "tweakables.h"

static char     msg[1024];
static char     head[1024];

/* 
                                                                                  * static struct tm *current_tm; *//* for 
                                                                                  * watching 
                                                                                  * for 
                                                                                  * next 
                                                                                  * update 
                                                                                  */
/* static long clk; */

EXTERN void     personal(int, int, char *);
EXTERN void     bless(int, int, int);
EXTERN void     insurgency(int, int, int);
EXTERN void     pay(int, int, int);
EXTERN void     give(int, int, int);
EXTERN void     page(int, int, int);
EXTERN void     send_message(int, int, int, int);
EXTERN void     read_messages(int, int, int);
EXTERN void     motto(int, int, int, char *);
EXTERN void     name(int, int, int);
EXTERN int      MostAPs(int, startype *);
EXTERN void     announce(int, int, char *, int, int);
EXTERN char    *garble_msg(char *, int, int, int);
EXTERN void     garble_chat(int, int);

#include "proto.h"

/* garble code variables from HAP by CWL -mfw */
#define BUFFER_LEN ((MAX_COMMAND_LEN)*8)
extern int      chat_flag;
extern int      chat_static;
char            gbuf[BUFFER_LEN];       /* Buffer used by garble */
extern long     size_of_words;
extern FILE    *garble_file;

/* end CWL */

#define mypunct(c) index("[]<>;:.,?!",(c))

void
personal(int Playernum, int Governor, char *message)
{
  racetype       *Race;

  Race = races[Playernum - 1];
  strncpy(Race->info, message, PERSONALSIZE - 1);
  putrace(Race);
}

void
bless(int Playernum, int Governor, int APcount)
{
  planettype     *planet;
  racetype       *Race;
  int             who, amount, Mod;
  char            commod;

  Race = races[Playernum - 1];
  if (!Race->God || Playernum != 1)
  {
    notify(Playernum, Governor,
           "You are not privileged to use this command.\n");
    return;
  }
  if (Dir[Playernum - 1][Governor].level != LEVEL_PLAN)
  {
    notify(Playernum, Governor, "Please cs to the planet in question.\n");
    return;
  }
  who = atoi(args[1]);
  if (who < 1 || who > Num_races)
  {
    notify(Playernum, Governor, "No such player number.\n");
    return;
  }
  if (argn < 3)
  {
    notify(Playernum, Governor, "Syntax: bless <player> <what> <+amount>\n");
    return;
  }
  amount = atoi(args[3]);

  Race = races[who - 1];
  /* race characteristics? */
  Mod = 1;

  if (match(args[2], "money"))
  {
    MONEY(Race, 0) += amount;
    sprintf(buf, "Deity gave you %d money.\n", amount);
  }
  else if (match(args[2], "password"))
  {
    strcpy(Race->password, args[3]);
    sprintf(buf, "Deity changed your race password to `%s'\n", args[3]);
  }
  else if (match(args[2], "morale"))
  {
    Race->morale += amount;
    sprintf(buf, "Deity gave you %d morale.\n", amount);
  }
  else if (match(args[2], "pods"))
  {
    Race->pods = 1;
    sprintf(buf, "Deity gave you pod ability.\n");
  }
  else if (match(args[2], "nopods"))
  {
    Race->pods = 0;
    sprintf(buf, "Deity took away pod ability.\n");
  }
  else if (match(args[2], "collectiveiq"))
  {
    Race->collective_iq = 1;
    sprintf(buf, "Deity gave you collective intelligence.\n");
  }
  else if (match(args[2], "nocollectiveiq"))
  {
    Race->collective_iq = 0;
    sprintf(buf, "Deity took away collective intelligence.\n");
  }
  else if (match(args[2], "maxiq"))
  {
    Race->IQ_limit = atoi(args[3]);
    sprintf(buf, "Deity gave you a maximum IQ of %d.\n", Race->IQ_limit);
  }
  else if (match(args[2], "mass"))
  {
    Race->mass = atof(args[3]);
    sprintf(buf, "Deity gave you %.2f mass.\n", Race->mass);
  }
  else if (match(args[2], "metabolism"))
  {
    Race->metabolism = atof(args[3]);
    sprintf(buf, "Deity gave you %.2f metabolism.\n", Race->metabolism);
  }
  else if (match(args[2], "adventurism"))
  {
    Race->adventurism = atof(args[3]);
    sprintf(buf, "Deity gave you %-3.0f%% adventurism.\n",
            Race->adventurism * 100.0);
  }
  else if (match(args[2], "birthrate"))
  {
    Race->birthrate = atof(args[3]);
    sprintf(buf, "Deity gave you %.2f birthrate.\n", Race->birthrate);
  }
  else if (match(args[2], "fertility"))
  {
    Race->fertilize = amount;
    sprintf(buf, "Deity gave you a fetilization ability of %d.\n", amount);
  }
  else if (match(args[2], "IQ"))
  {
    Race->IQ = amount;
    sprintf(buf, "Deity gave you %d IQ.\n", amount);
  }
  else if (match(args[2], "fight"))
  {
    Race->fighters = amount;
    sprintf(buf, "Deity set your fighting ability to %d.\n", amount);
  }
  else if (match(args[2], "technology"))
  {
    Race->tech += (double)amount;
    sprintf(buf, "Deity gave you %d technology.\n", amount);
  }
  else if (match(args[2], "guest"))
  {
    Race->Guest = 1;
    sprintf(buf, "Deity turned you into a guest race.\n");
  }
  else if (match(args[2], "god"))
  {
    Race->God = 1;
    sprintf(buf, "Deity turned you into a deity race.\n");
  }
  else if (match(args[2], "mortal"))
  {
    Race->God = 0;
    Race->Guest = 0;
    sprintf(buf, "Deity turned you into a mortal race.\n");
    /* sector preferences */
  }
  else if (match(args[2], "water"))
  {
    Race->likes[SEA] = 0.01 * (double)amount;
    sprintf(buf, "Deity set your water preference to %d%%\n", amount);
  }
  else if (match(args[2], "land"))
  {
    Race->likes[LAND] = 0.01 * (double)amount;
    sprintf(buf, "Deity set your land preference to %d%%\n", amount);
  }
  else if (match(args[2], "mountain"))
  {
    Race->likes[MOUNT] = 0.01 * (double)amount;
    sprintf(buf, "Deity set your mountain preference to %d%%\n", amount);
  }
  else if (match(args[2], "gas"))
  {
    Race->likes[GAS] = 0.01 * (double)amount;
    sprintf(buf, "Deity set your gas preference to %d%%\n", amount);
  }
  else if (match(args[2], "ice"))
  {
    Race->likes[ICE] = 0.01 * (double)amount;
    sprintf(buf, "Deity set your ice preference to %d%%\n", amount);
  }
  else if (match(args[2], "forest"))
  {
    Race->likes[FOREST] = 0.01 * (double)amount;
    sprintf(buf, "Deity set your forest preference to %d%%\n", amount);
  }
  else if (match(args[2], "desert"))
  {
    Race->likes[DESERT] = 0.01 * (double)amount;
    sprintf(buf, "Deity set your desert preference to %d%%\n", amount);
  }
  else if (match(args[2], "plated"))
  {
    Race->likes[PLATED] = 0.01 * (double)amount;
    sprintf(buf, "Deity set your plated preference to %d%%\n", amount);
  }
  else if (match(args[2], "activate"))
  {
    if (amount >= 0 && amount <= 5)
    {
      Race->governor[amount].active = 1;
      sprintf(buf, "Deity activated governor %d\n", amount);
    }
  }
  else if (match(args[2], "deactivate"))
  {
    if (amount >= 0 && amount <= 5)
    {
      Race->governor[amount].active = 0;
      sprintf(buf, "Deity deactivated governor %d\n", amount);
    }
  }
  else if (match(args[2], "homesystem"))
  {
    Race->governor[0].homesystem = amount;
    sprintf(buf, "Deity set home system.\n");
  }
  else if (match(args[2], "homeplanet"))
  {
    Race->governor[0].homeplanetnum = amount;
    sprintf(buf, "Deity set home planet.\n");
  }
  else if (match(args[2], "dissolve"))
  {
    Race->dissolved = 1;
    sprintf(buf, "Diety dissolved race.\n");
  }
  else
    Mod = 0;

  if (Mod)
  {
    putrace(Race);
    warn(who, 0, buf);
    return;
  }

  /* ok, must be the planet then */
  commod = args[2][0];
  getplanet(&planet, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);
  if (match(args[2], "explorebit"))
  {
    planet->info[who - 1].explored = 1;
    getstar(&Stars[Dir[Playernum - 1][Governor].snum],
            Dir[Playernum - 1][Governor].snum);
    setbit(Stars[Dir[Playernum - 1][Governor].snum]->explored, who);
    putstar(Stars[Dir[Playernum - 1][Governor].snum],
            Dir[Playernum - 1][Governor].snum);
    sprintf(buf, "Deity set your explored bit at /%s/%s.\n",
            Stars[Dir[Playernum - 1][Governor].snum]->name,
            Stars[Dir[Playernum - 1][Governor].snum]->
            pnames[Dir[Playernum - 1][Governor].pnum]);
  }
  else if (match(args[2], "noexplorebit"))
  {
    planet->info[who - 1].explored = 0;
    sprintf(buf, "Deity reset your explored bit at /%s/%s.\n",
            Stars[Dir[Playernum - 1][Governor].snum]->name,
            Stars[Dir[Playernum - 1][Governor].snum]->
            pnames[Dir[Playernum - 1][Governor].pnum]);
    if (match(args[3], "system"))
    {
      clrbit(Stars[Dir[Playernum - 1][Governor].snum]->explored, who);
    }
  }
  else if (match(args[2], "planetpopulation"))
  {
    long            was, now;

    was = planet->info[who - 1].popn;
    now = atoi(args[3]);

    planet->info[who - 1].popn = now;
    planet->popn += (now - was);

    sprintf(buf, "Deity set your population variable to %ld at /%s/%s.\n",
            planet->info[who - 1].popn,
            Stars[Dir[Playernum - 1][Governor].snum]->name,
            Stars[Dir[Playernum - 1][Governor].snum]->
            pnames[Dir[Playernum - 1][Governor].pnum]);
  }
  else if (match(args[2], "inhabited"))
  {
    getstar(&Stars[Dir[Playernum - 1][Governor].snum],
            Dir[Playernum - 1][Governor].snum);
    setbit(Stars[Dir[Playernum - 1][Governor].snum]->inhabited, Playernum);
    putstar(Stars[Dir[Playernum - 1][Governor].snum],
            Dir[Playernum - 1][Governor].snum);
    sprintf(buf, "Deity has set your inhabited bit for /%s/%s.\n",
            Stars[Dir[Playernum - 1][Governor].snum]->name,
            Stars[Dir[Playernum - 1][Governor].snum]->
            pnames[Dir[Playernum - 1][Governor].pnum]);
  }
  else if (match(args[2], "numsectsowned"))
  {
    planet->info[who - 1].numsectsowned = atoi(args[3]);
    sprintf(buf, "Deity set your \"numsectsowned\" variable at /%s/%s to %d.\n",
            Stars[Dir[Playernum - 1][Governor].snum]->name,
            Stars[Dir[Playernum - 1][Governor].snum]->
            pnames[Dir[Playernum - 1][Governor].pnum],
            planet->info[who - 1].numsectsowned);
  }
  else
  {
    switch (commod)
    {
      case 'r':
        planet->info[who - 1].resource += amount;
        sprintf(buf, "Deity gave you %d resources at %s/%s.\n", amount,
                Stars[Dir[Playernum - 1][Governor].snum]->name,
                Stars[Dir[Playernum - 1][Governor].snum]->
                pnames[Dir[Playernum - 1][Governor].pnum]);
        break;
      case 'd':
        planet->info[who - 1].destruct += amount;
        sprintf(buf, "Deity gave you %d destruct at %s/%s.\n", amount,
                Stars[Dir[Playernum - 1][Governor].snum]->name,
                Stars[Dir[Playernum - 1][Governor].snum]->
                pnames[Dir[Playernum - 1][Governor].pnum]);
        break;
      case 'f':
        planet->info[who - 1].fuel += amount;
        sprintf(buf, "Deity gave you %d fuel at %s/%s.\n", amount,
                Stars[Dir[Playernum - 1][Governor].snum]->name,
                Stars[Dir[Playernum - 1][Governor].snum]->
                pnames[Dir[Playernum - 1][Governor].pnum]);
        break;
      case 'x':
        planet->info[who - 1].crystals += amount;
        sprintf(buf, "Deity gave you %d crystals at %s/%s.\n", amount,
                Stars[Dir[Playernum - 1][Governor].snum]->name,
                Stars[Dir[Playernum - 1][Governor].snum]->
                pnames[Dir[Playernum - 1][Governor].pnum]);
        break;
      case 'a':
        getstar(&Stars[Dir[Playernum - 1][Governor].snum],
                Dir[Playernum - 1][Governor].snum);
        Stars[Dir[Playernum - 1][Governor].snum]->AP[who - 1] += amount;
        putstar(Stars[Dir[Playernum - 1][Governor].snum],
                Dir[Playernum - 1][Governor].snum);
        sprintf(buf, "Deity gave you %d action points at %s.\n", amount,
                Stars[Dir[Playernum - 1][Governor].snum]->name);
        break;
      default:
        notify(Playernum, Governor, "No such commodity.\n");
        free((char *)planet);
        return;
    }
  }
  putplanet(planet, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);
  warn_race(who, buf);
  free((char *)planet);
}

void
insurgency(int Playernum, int Governor, int APcount)
{
  int             who, amount, eligible, them = 0;
  racetype       *Race, *alien;
  planettype     *p;
  double          x;
  int             changed_hands, chance;
  register int    i;

  if (Dir[Playernum - 1][Governor].level != LEVEL_PLAN)
  {
    notify(Playernum, Governor,
           "You must 'cs' to the planet you wish to try it on.\n");
    return;
  }

  /* 
   * if(argn<3) { notify(Playernum, Governor, "The correct syntax is
   * 'insurgency <race> <money>'\n"); return; }
   */
  if (!enufAP
      (Playernum, Governor,
       Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1], APcount))
    return;
  if (!(who = GetPlayer(args[1])))
  {
    sprintf(buf, "No such player.\n");
    notify(Playernum, Governor, buf);
    return;
  }
  Race = races[Playernum - 1];
  alien = races[who - 1];
  if (alien->Guest)
  {
    notify(Playernum, Governor, "Don't be such a dickweed.\n");
    return;
  }
  if (who == Playernum)
  {
    notify(Playernum, Governor, "You can't revolt against yourself!\n");
    return;
  }
  eligible = 0;
  them = 0;
  for (i = 0; i < Stars[Dir[Playernum - 1][Governor].snum]->numplanets; i++)
  {
    getplanet(&p, Dir[Playernum - 1][Governor].snum, i);
    eligible += p->info[Playernum - 1].popn;
    them += p->info[who - 1].popn;
    free((char *)p);
  }
  if (!eligible)
  {
    notify(Playernum, Governor,
           "You must have population in the star system to attempt insurgency\n.");
    return;
  }
  getplanet(&p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);

  if (!p->info[who - 1].popn)
  {
    notify(Playernum, Governor, "This player does not occupy this planet.\n");
    free((char *)p);
    return;
  }
  sscanf(args[2], "%d", &amount);
  if (amount < 0)
  {
    notify(Playernum, Governor,
           "You have to use a positive amount of money.\n");
    free((char *)p);
    return;
  }
  if (MONEY(Race, Governor) < amount)
  {
    notify(Playernum, Governor, "Nice try.\n");
    free((char *)p);
    return;
  }
  /* HUT Gardan 11.2.1997 x = eligible / (eligible + them); x *= 0.8 * (double) 
   * p->info[who - 1].tax + 0.2 * (them / (them + 2000)); x *= (double) amount
   * * 2 / (them + (double) amount); x *= (double) amount / ((double) amount +
   * 4000); chance = x * 100.0; */

  /* old code */
  x =
    INSURG_FACTOR * (double)amount *(double)p->info[who -
                                                    1].tax /
    (double)p->info[who - 1].popn;
  x *= morale_factor((double)(Race->morale - alien->morale));
  x *= morale_factor((double)(eligible - them) / 50.0);
  x *=
    morale_factor(10.0 *
                  (double)(Race->fighters * p->info[Playernum - 1].troops -
                           alien->fighters * p->info[who - 1].troops)) / 50.0;

  sprintf(buf, "x = %f\n", x);
  notify(Playernum, Governor, buf);
  chance = round_rand(200.0 * atan((double)x) / 3.14159265);
  sprintf(long_buf, "%s/%s: %s [%d] tries insurgency vs %s [%d]\n",
          Stars[Dir[Playernum - 1][Governor].snum]->name,
          Stars[Dir[Playernum - 1][Governor].snum]->
          pnames[Dir[Playernum - 1][Governor].pnum], Race->name, Playernum,
          alien->name, who);
  sprintf(buf, "\t%s: %d total civs [%d]  opposing %d total civs [%d]\n",
          Stars[Dir[Playernum - 1][Governor].snum]->name, eligible, Playernum,
          them, who);
  strcat(long_buf, buf);
  sprintf(buf, "\t\t %ld morale [%d] vs %ld morale [%d]\n", Race->morale,
          Playernum, alien->morale, who);
  strcat(long_buf, buf);
  sprintf(buf, "\t\t %d money against %ld population at tax rate %d%%\n",
          amount, p->info[who - 1].popn, p->info[who - 1].tax);
  strcat(long_buf, buf);
  sprintf(buf, "Success chance is %d%%\n", chance);
  strcat(long_buf, buf);
  if (success(chance))
  {
    changed_hands = revolt(p, who, Playernum);
    notify(Playernum, Governor, long_buf);
    sprintf(buf, "Success!  You liberate %d sector%s.\n", changed_hands,
            (changed_hands == 1) ? "" : "s");
    notify(Playernum, Governor, buf);
    sprintf(buf,
            "A revolt on /%s/%s instigated by %s [%d] costs you %d sector%s\n",
            Stars[Dir[Playernum - 1][Governor].snum]->name,
            Stars[Dir[Playernum - 1][Governor].snum]->
            pnames[Dir[Playernum - 1][Governor].pnum], Race->name, Playernum,
            changed_hands, (changed_hands == 1) ? "" : "s");
    strcat(long_buf, buf);
    warn(who, (int)Stars[Dir[Playernum - 1][Governor].snum]->governor[who - 1],
         long_buf);
    p->info[Playernum - 1].tax = p->info[who - 1].tax;
    /* you inherit their tax rate (insurgency wars he he ) */
    sprintf(buf, "/%s/%s: Successful insurgency by %s [%d] against %s [%d]\n",
            Stars[Dir[Playernum - 1][Governor].snum]->name,
            Stars[Dir[Playernum - 1][Governor].snum]->
            pnames[Dir[Playernum - 1][Governor].pnum], Race->name, Playernum,
            alien->name, who);
    post(buf, DECLARATION);
  }
  else
  {
    notify(Playernum, Governor, long_buf);
    notify(Playernum, Governor, "The insurgency failed!\n");
    sprintf(buf, "A revolt on /%s/%s instigated by %s [%d] fails\n",
            Stars[Dir[Playernum - 1][Governor].snum]->name,
            Stars[Dir[Playernum - 1][Governor].snum]->
            pnames[Dir[Playernum - 1][Governor].pnum], Race->name, Playernum);
    strcat(long_buf, buf);
    warn(who, (int)Stars[Dir[Playernum - 1][Governor].snum]->governor[who - 1],
         long_buf);
    sprintf(buf, "/%s/%s: Failed insurgency by %s [%d] against %s [%d]\n",
            Stars[Dir[Playernum - 1][Governor].snum]->name,
            Stars[Dir[Playernum - 1][Governor].snum]->
            pnames[Dir[Playernum - 1][Governor].pnum], Race->name, Playernum,
            alien->name, who);
    post(buf, DECLARATION);
  }
  deductAPs(Playernum, Governor, APcount, Dir[Playernum - 1][Governor].snum, 0);
  MONEY(Race, Governor) -= amount;
  putrace(Race);
  free((char *)p);
}

void
pay(int Playernum, int Governor, int APcount)
{
  int             who, amount;
  racetype       *Race, *alien;

  if (!(who = GetPlayer(args[1])))
  {
    sprintf(buf, "No such player.\n");
    notify(Playernum, Governor, buf);
    return;
  }

  if (!enufAP
      (Playernum, Governor,
       Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1], APcount))
    return;

  Race = races[Playernum - 1];
  alien = races[who - 1];

  sscanf(args[2], "%d", &amount);
  if (amount < 0)
  {
    notify(Playernum, Governor,
           "You have to give a player a positive amount of money.\n");
    return;
  }
  if (Race->Guest)
  {
    notify(Playernum, Governor,
           "Nice try. Your attempt has been duly noted.\n");
    return;
  }
  if (MONEY(Race, Governor) < amount)
  {
    notify(Playernum, Governor, "You don't have that much money to give!\n");
    return;
  }
  MONEY(Race, Governor) -= amount;
  MONEY(alien, 0) += amount;
  sprintf(buf, "%s [%d] payed you %d.\n", Race->name, Playernum, amount);
  warn(who, 0, buf);
  sprintf(buf, "%d payed to %s [%d].\n", amount, alien->name, who);
  notify(Playernum, Governor, buf);

  sprintf(buf, "%s [%d] pays %s [%d].\n", Race->name, Playernum, alien->name,
          who);
  post(buf, TRANSFER);

  deductAPs(Playernum, Governor, APcount, Dir[Playernum - 1][Governor].snum, 0);
  putrace(alien);
  putrace(Race);
}

void
give(int Playernum, int Governor, int APcount)
{
  int             who, sh;
  shiptype       *ship;
  planettype     *planet;
  racetype       *Race, *alien;

  if (!(who = GetPlayer(args[1])))
  {
    sprintf(buf, "No such player.\n");
    notify(Playernum, Governor, buf);
    return;
  }

  alien = races[who - 1];
  Race = races[Playernum - 1];
  if (alien->Guest && !Race->God)
  {
    notify(Playernum, Governor, "You can't give this player anything.\n");
    return;
  }
  if (Race->Guest)
  {
    notify(Playernum, Governor, "You can't give anyone anything.\n");
    return;
  }
  /* check to see if both players are mutually allied */
  if (!Race->God &&
      !(isset(Race->allied, who) && isset(alien->allied, Playernum)))
  {
    notify(Playernum, Governor, "You two are not mutually allied.\n");
    return;
  }
  sscanf(args[2] + (args[2][0] == '#'), "%d", &sh);

  if (!getship(&ship, sh))
  {
    notify(Playernum, Governor, "Illegal ship number.\n");
    return;
  }
  if (ship->owner != Playernum || !ship->alive)
  {
    DontOwnErr(Playernum, Governor, sh);
    free((char *)ship);
    return;
  }
  /* HUTm (kse) ships can be given only in current scope */
  if ((Dir[Playernum - 1][Governor].level == LEVEL_UNIV &&
       ship->whatorbits != LEVEL_UNIV) ||
      (Dir[Playernum - 1][Governor].snum != ship->storbits))
  {
    notify(Playernum, Governor,
           "You cannot give ship from different system.\n");
    free((char *)ship);
    return;
  }
  if (SISAPOD(ship))
  {
    notify(Playernum, Governor,
           "You cannot change the ownership of spore pods.\n");
    free((char *)ship);
    return;
  }
  if ((ship->popn + ship->troops) && !Race->God)
  {
    notify(Playernum, Governor,
           "You can't give this ship away while it has crew/mil on board.\n");
    free((char *)ship);
    return;
  }
  if (ship->ships && !Race->God)
  {
    notify(Playernum, Governor,
           "You can't give away this ship, it has other ships loaded on it.\n");
    free((char *)ship);
    return;
  }
  switch (ship->whatorbits)
  {
    case LEVEL_UNIV:
      if (!enufAP(Playernum, Governor, Sdata.AP[Playernum - 1], APcount))
      {
        free((char *)ship);
        return;
      }
      break;
    default:
      if (!enufAP
          (Playernum, Governor,
           Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1],
           APcount))
      {
        free((char *)ship);
        return;
      }
      break;
  }

  /* Remove its fleet association -mfw */
  if (ship->fleetmember || ship->nextinfleet)
  {
    remove_sh_fleet(Playernum, Governor, ship);
  }

  ship->owner = who;
  ship->governor = 0;           /* give to the leader */
  capture_stuff(ship);

  putship(ship);

  /* set inhabited/explored bits */
  switch (ship->whatorbits)
  {
    case LEVEL_UNIV:
      break;
    case LEVEL_STAR:
      getstar(&(Stars[ship->storbits]), (int)ship->storbits);
      setbit(Stars[ship->storbits]->explored, who);
      putstar(Stars[ship->storbits], (int)ship->storbits);
      break;
    case LEVEL_PLAN:
      getstar(&(Stars[ship->storbits]), (int)ship->storbits);
      setbit(Stars[ship->storbits]->explored, who);
      putstar(Stars[ship->storbits], (int)ship->storbits);

      getplanet(&planet, (int)ship->storbits, (int)ship->pnumorbits);
      planet->info[who - 1].explored = 1;
      putplanet(planet, (int)ship->storbits, (int)ship->pnumorbits);
      free((char *)planet);

      break;
    default:
      notify(Playernum, Governor, "Something wrong with this ship's scope.\n");
      free((char *)ship);
      return;
  }

  switch (ship->whatorbits)
  {
    case LEVEL_UNIV:
      deductAPs(Playernum, Governor, APcount, 0, 1);
      free((char *)ship);
      return;
    default:
      deductAPs(Playernum, Governor, APcount, Dir[Playernum - 1][Governor].snum,
                0);
      break;
  }
  notify(Playernum, Governor, "Owner changed.\n");
  sprintf(buf, "%s [%d] gave you %s at %s.\n", Race->name, Playernum,
          Ship(ship), prin_ship_orbits(ship));
  warn(who, 0, buf);

  if (!Race->God)
  {
    sprintf(buf, "%s [%d] gives %s [%d] a ship.\n", Race->name, Playernum,
            alien->name, who);
    post(buf, TRANSFER);
    free((char *)ship);
  }
}

void
page(int Playernum, int Governor, int APcount0)
{
  int             i, who = -1, gov = -1, to_block, dummy[2], APcount;
  racetype       *Race, *alien;

  APcount = APcount0;
  if (!enufAP
      (Playernum, Governor,
       Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1], APcount))
    return;

  to_block = 0;
  if (match(args[1], "block"))
  {
    to_block = 1;
    notify(Playernum, Governor, "Paging alliance block.\n");
  }
  else
  {
    if (!(who = GetPlayer(args[1])))
    {
      sprintf(buf, "No such player.\n");
      notify(Playernum, Governor, buf);
      return;
    }
    alien = races[who - 1];
    APcount *= !alien->God;
    if (argn > 1)
      gov = atoi(args[2]);
  }

  switch (Dir[Playernum - 1][Governor].level)
  {
    case LEVEL_UNIV:
      sprintf(buf, "You can't make pages at universal scope.\n");
      notify(Playernum, Governor, buf);
      break;
    default:
      getstar(&Stars[Dir[Playernum - 1][Governor].snum],
              Dir[Playernum - 1][Governor].snum);
      if (!enufAP
          (Playernum, Governor,
           Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1],
           APcount))
      {
        return;
      }
      Race = races[Playernum - 1];

      sprintf(buf, "%s \"%s\" page(s) you from the %s star system.\n",
              Race->name, Race->governor[Governor].name,
              Stars[Dir[Playernum - 1][Governor].snum]->name);

      if (to_block)
      {
        dummy[0] =
          Blocks[Playernum - 1].invite[0] & Blocks[Playernum - 1].pledge[0];
        dummy[1] =
          Blocks[Playernum - 1].invite[1] & Blocks[Playernum - 1].pledge[1];
        for (i = 1; i <= Num_races; i++)
          if (isset(dummy, i) && i != Playernum)
            notify_race(i, buf);
      }
      else
      {
        if (argn > 1)
          notify(who, gov, buf);
        else
          notify_race(who, buf);
      }

      notify(Playernum, Governor, "Request sent.\n");
      break;
  }
  deductAPs(Playernum, Governor, APcount, Dir[Playernum - 1][Governor].snum, 0);
}

void
send_message(int Playernum, int Governor, int APcount0, int postit)
{
  int             who = -1, i, j, to_block, dummy[2], APcount;
  int             to_star, star = -1, start, to, what;
  placetype       where;
  racetype       *Race, *alien;

  APcount = APcount0;

  to_star = to_block = 0;

  /* clear the message buffer out */
  strcpy(msg, "");

  if (argn < 2)
  {
    notify(Playernum, Governor, "Send what?\n");
    return;
  }

  if (postit)
  {
    Race = races[Playernum - 1];
    sprintf(msg, "%s \"%s\" [%d,%d]: ", Race->name,
            Race->governor[Governor].name, Playernum, Governor);

    /* put the message together */
    for (j = 1; j < argn; j++)
    {
      sprintf(buf, "%s ", args[j]);
      strcat(msg, buf);
    }

    strcat(msg, "\n");
    post(msg, ANNOUNCE);
    return;
  }

  if (match(args[1], "block"))
  {
    to_block = 1;
    notify(Playernum, Governor, "Sending message to alliance block.\n");

    if (!(who = GetPlayer(args[2])))
    {
      sprintf(buf, "No such alliance block.\n");
      notify(Playernum, Governor, buf);
      return;
    }

    alien = races[who - 1];
    APcount *= !alien->God;
  }
  else if (match(args[1], "star"))
  {
    to_star = 1;
    notify(Playernum, Governor, "Sending message to star system.\n");
    where = Getplace(Playernum, Governor, args[2], 1);

    if (where.err || where.level != LEVEL_STAR)
    {
      sprintf(buf, "No such star.\n");
      notify(Playernum, Governor, buf);
      return;
    }

    star = where.snum;
    getstar(&(Stars[star]), star);
  }
  else
  {
    if (!(who = GetPlayer(args[1])))
    {
      sprintf(buf, "No such player.\n");
      notify(Playernum, Governor, buf);
      return;
    }

    alien = races[who - 1];
    APcount *= ((!alien->God) && (who != Playernum));
  }

  switch (Dir[Playernum - 1][Governor].level)
  {
    case LEVEL_UNIV:
      sprintf(buf, "You can't send messages from universal scope.\n");
      notify(Playernum, Governor, buf);
      return;

    case LEVEL_SHIP:
      sprintf(buf, "You can't send messages from ship scope.\n");
      notify(Playernum, Governor, buf);
      return;

    default:
      getstar(&Stars[Dir[Playernum - 1][Governor].snum],
              Dir[Playernum - 1][Governor].snum);

      if (!enufAP
          (Playernum, Governor,
           Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1],
           APcount))
        return;
      break;
  }

  Race = races[Playernum - 1];

  /* send the message */
  if (to_block)
  {
    to = TO_BLOCK;
    what = who;
  }
  else if (to_star)
  {
    to = TO_STAR;
    what = star;
  }
  else
  {
    to = TO_PLAYER;
    what = who;
  }

  if (to_star || to_block || isdigit((unsigned char)*args[2]))
  {
    start = 3;
  }
  else if (postit)
  {
    start = 1;
  }
  else
  {
    to = TO_RACE;
    what = who;
    start = 2;
  }

  /* put the message together */
  for (j = start; j < argn; j++)
  {
    sprintf(buf, "%s ", args[j]);
    strcat(msg, buf);
  }

  /* post it */
  sprintf(buf,
          "%s \"%s\" [%d,%d] has sent you a dispatch.\nUse `read dispatches' to access it.\n",
          Race->name, Race->governor[Governor].name, Playernum, Governor);

  if (to_block)
  {
    dummy[0] = (Blocks[who - 1].invite[0] & Blocks[who - 1].pledge[0]);
    dummy[1] = (Blocks[who - 1].invite[1] & Blocks[who - 1].pledge[1]);
    sprintf(buf,
            "%s \"%s\" [%d,%d] sends a dispatch to %s [%d] alliance block.\n",
            Race->name, Race->governor[Governor].name, Playernum, Governor,
            Blocks[who - 1].name, who);

    for (i = 1; i <= Num_races; i++)
    {
      if (isset(dummy, i))
      {
        /* Determine alien from 'i' then garble msg -mfw */
        alien = races[i - 1];

        if (!Race->God && !alien->God && (chat_flag == TRANS_CHAT))
        {
          garble_msg(msg, alien->translate[Playernum - 1], 1, Playernum);
        }

        notify_race(i, buf);
        send_race_dispatch(Playernum, Governor, i, to, what, msg);
      }
    }
  }
  else if (to_star)
  {
    sprintf(buf, "%s \"%s\" [%d,%d] sends a stargram to %s.\n", Race->name,
            Race->governor[Governor].name, Playernum, Governor,
            Stars[star]->name);
    notify_star(Playernum, Governor, 0, star, buf);

    /* I've basically copied the warn_star function here so we can better deal
     * with garbling the message -mfw */
    for (i = 1; i <= Num_races; i++)
    {
      if (i != Playernum && i != 0 && isset(Stars[star]->inhabited, i))
      {
        alien = races[i - 1];

        if (!Race->God && !alien->God && (chat_flag == TRANS_CHAT))
        {
          garble_msg(msg, alien->translate[Playernum - 1], 1, Playernum);
        }

        send_race_dispatch(Playernum, Governor, i, to, what, msg);
      }
    }
  }
  else
  {
    int             gov;

    if (who == Playernum)
      APcount = 0;

    alien = races[who - 1];

    if (!Race->God && !alien->God && (chat_flag == TRANS_CHAT))
    {
      garble_msg(msg, alien->translate[Playernum - 1], 1, Playernum);
    }

    if (isdigit((unsigned char)*args[2]) && (gov = atoi(args[2])) >= 0 &&
        gov <= MAXGOVERNORS)
    {
      notify(who, gov, buf);
      send_dispatch(Playernum, Governor, who, gov, to, what, msg);
    }
    else
    {
      notify_race(who, buf);
      send_race_dispatch(Playernum, Governor, who, to, what, msg);
    }

    /* translation modifier increases */
    alien->translate[Playernum - 1] =
      MIN(alien->translate[Playernum - 1] + int_rand(1, 3), 100);
    putrace(alien);
  }

  notify(Playernum, Governor, "Dispatch sent.\n");
  deductAPs(Playernum, Governor, APcount, Dir[Playernum - 1][Governor].snum, 0);
}

void
read_messages(int Playernum, int Governor, int APcount)
{
  if (!strncmp(args[1], "telegrams", 1))
  {
    teleg_read(Playernum, Governor);
  }
  else if (!strncmp(args[1], "dispatches", 1))
  {
    if (argn == 2)
    {
      read_dispatch(Playernum, Governor, 0);
    }
    else if (argn == 3)
    {
      read_dispatch(Playernum, Governor, atoi(args[2]));
    }
    else
    {
      notify(Playernum, Governor,
             "Wrong number of arguments to 'read dispatches'.\n");
    }
  }
  else if (!strncmp(args[1], "news", 1))
  {
    notify(Playernum, Governor, CUTE_MESSAGE);
    notify(Playernum, Governor,
           "\n----------        Declarations        ----------\n");
    news_read(Playernum, Governor, DECLARATION);
    notify(Playernum, Governor,
           "\n----------           Combat           ----------\n");
    news_read(Playernum, Governor, COMBAT);
    notify(Playernum, Governor,
           "\n----------          Business          ----------\n");
    news_read(Playernum, Governor, TRANSFER);
    notify(Playernum, Governor,
           "\n----------          Bulletins         ----------\n");
    news_read(Playernum, Governor, ANNOUNCE);
  }
  else if (!strncmp(args[1], "declarations", 2))
  {
    notify(Playernum, Governor, CUTE_MESSAGE);
    notify(Playernum, Governor,
           "\n----------        Declarations        ----------\n");
    news_read(Playernum, Governor, DECLARATION);
  }
  else if (!strncmp(args[1], "combat", 1))
  {
    notify(Playernum, Governor, CUTE_MESSAGE);
    notify(Playernum, Governor,
           "\n----------           Combat           ----------\n");
    news_read(Playernum, Governor, COMBAT);
  }
  else if (!strncmp(args[1], "business", 1))
  {
    notify(Playernum, Governor, CUTE_MESSAGE);
    notify(Playernum, Governor,
           "\n----------          Business          ----------\n");
    news_read(Playernum, Governor, TRANSFER);
  }
  else if (!strncmp(args[1], "postings", 1))
  {
    notify(Playernum, Governor, CUTE_MESSAGE);
    notify(Playernum, Governor,
           "\n----------          Bulletins         ----------\n");
    news_read(Playernum, Governor, ANNOUNCE);
  }
  else
    notify(Playernum, Governor, "Read what?\n");
}

void
purge_messages(int Playernum, int Governor, int APcount)
{
  if (argn != 2)
  {
    notify(Playernum, Governor, "Purge what?\n");
    return;
  }

  if (!strncmp(args[1], "telegrams", 1))
  {
    purge_telegrams(Playernum, Governor);
  }
  else if (!strncmp(args[1], "dispatches", 1))
  {
    purge_dispatch(Playernum, Governor, APcount);
  }
  else if (!strncmp(args[1], "all", 1))
  {
    purge_telegrams(Playernum, Governor);
    purge_dispatch(Playernum, Governor, APcount);
  }
  else
  {
    notify(Playernum, Governor, "Improper usage, see 'help command purge'\n");
  }
}

void
motto(int Playernum, int Governor, int APcount, char *message)
{
  strncpy(Blocks[Playernum - 1].motto, message, MOTTOSIZE - 1);
  Putblock(Blocks);
  notify(Playernum, Governor, "Done.\n");
}

void
name(int Playernum, int Governor, int APcount)
{
  char           *ch;
  register int    i, spaces;
  int             len, s;
  unsigned char   check = 0;
  shiptype       *ship;
  char            string[1024];
  char            temp[128];
  racetype       *Race;
  planettype     *p;

  if (!isalnum((unsigned char)args[2][0]) || argn < 3)
  {
    notify(Playernum, Governor, "Illegal name format.\n");
    return;
  }

  sprintf(buf, "%s", args[2]);

  for (i = 3; i < argn; i++)
  {
    sprintf(temp, " %s", args[i]);
    strcat(buf, temp);
  }

  sprintf(string, "%s", buf);

  i = strlen(args[0]);

  /* 
   * make sure there are no ^'s or '/' in name, also make sure the name
   * has at least 1 character in it
   */
  ch = string;
  spaces = 0;
  while (*ch != '\0')
  {
    /* Added underscore character -mfw */
    /* check |= ((!isalnum(*ch) && !(*ch == ' ') && !(*ch == '.')) || (*ch ==
     * '/')); */
    check |=
      ((!isalnum((unsigned char)*ch) && !(*ch == ' ') && !(*ch == '.') &&
        !(*ch == '_')) || (*ch == '/'));
    ch++;
    if (*ch == ' ')
      spaces++;
  }

  len = strlen(buf);
  /* if (spaces == strlen(buf)) Not allowing whitespaces -mfw { */
  if (spaces > 0)
  {
    notify(Playernum, Governor, "Illegal name, no whitespaces allowed.\n");
    return;
  }

  if (strlen(buf) < 1 || check)
  {
    sprintf(buf, "Illegal name %s.\n", check ? "form" : "length");
    notify(Playernum, Governor, buf);
    return;
  }

  if (match(args[1], "ship"))
  {
    if (Dir[Playernum - 1][Governor].level == LEVEL_SHIP)
    {
      (void)getship(&ship, Dir[Playernum - 1][Governor].shipno);
      strncpy(ship->name, buf, SHIP_NAMESIZE);
      putship(ship);
      notify(Playernum, Governor, "Name set.\n");
      free((char *)ship);
      return;
    }
    else
    {
      notify(Playernum, Governor, "You have to 'cs' to a ship to name it.\n");
      return;
    }
  }
  else if (match(args[1], "class"))
  {
    if (Dir[Playernum - 1][Governor].level == LEVEL_SHIP)
    {
      (void)getship(&ship, Dir[Playernum - 1][Governor].shipno);

      if (ship->type != OTYPE_FACTORY)
      {
        notify(Playernum, Governor, "You are not at a factory!\n");
        free((char *)ship);
        return;
      }

      if (ship->on)
      {
        notify(Playernum, Governor, "This factory is already on line.\n");
        free((char *)ship);
        return;
      }

      strncpy(ship->class, buf, SHIP_NAMESIZE - 1);
      putship(ship);
      notify(Playernum, Governor, "Class set.\n");
      free((char *)ship);
      return;
    }
    else
    {
      notify(Playernum, Governor,
             "You have to 'cs' to a factory to name the ship class.\n");
      return;
    }
  }
  else if (match(args[1], "block"))
  {
    /* name your alliance block */
    strncpy(Blocks[Playernum - 1].name, buf, RNAMESIZE - 1);
    Putblock(Blocks);
    notify(Playernum, Governor, "Done.\n");
  }
  else if (match(args[1], "star"))
  {
    if (Dir[Playernum - 1][Governor].level == LEVEL_STAR)
    {
      Race = races[Playernum - 1];

#ifndef NAME_STARS
      if (!Race->God)
      {
        notify(Playernum, Governor, "Only dieties may name a star.\n");
        return;
      }
#else
      if (!Race->God &&
          !MostAPs(Playernum, Stars[Dir[Playernum - 1][Governor].snum]))
      {
        notify(Playernum, Governor,
               "You don't have the most AP's in that system.\n");
        return;
      }
#endif

      /* got to re-get all stars, to stop cheaters -mfw */
      for (s = 0; s < Sdata.numstars; s++)
      {
        getstar(&Stars[s], s);
      }

      /* to prevent cheating or naming conflicts -mfw */
      for (s = 0; s < Sdata.numstars; s++)
      {
        if (s != Dir[Playernum - 1][Governor].snum)
        {
          if (!strncmp(Stars[s]->name, buf, MIN(len, strlen(Stars[s]->name))))
          {
            notify(Playernum, Governor, "Unacceptable star name.\n");
            return;
          }
        }
      }

      strncpy(Stars[Dir[Playernum - 1][Governor].snum]->name, buf,
              NAMESIZE - 1);
      putstar(Stars[Dir[Playernum - 1][Governor].snum],
              Dir[Playernum - 1][Governor].snum);
    }
    else
    {
      notify(Playernum, Governor, "You have to 'cs' to a star to name it.\n");
      return;
    }
  }
  else if (match(args[1], "planet"))
  {
    if (Dir[Playernum - 1][Governor].level == LEVEL_PLAN)
    {
      getstar(&Stars[Dir[Playernum - 1][Governor].snum],
              Dir[Playernum - 1][Governor].snum);
      Race = races[Playernum - 1];
      getplanet(&p, Dir[Playernum - 1][Governor].snum,
                Dir[Playernum - 1][Governor].pnum);

      if (((p->Maxx * p->Maxy / 2) >= p->info[Playernum - 1].numsectsowned) &&
          (!Race->God))
      {
        notify(Playernum, Governor,
               "You must own more than half the planet to rename it....\n");
        free((char *)p);
        return;
      }

      free((char *)p);

      /* to prevent cheating or naming conflicts -mfw */
      for (s = 0; s < Stars[Dir[Playernum - 1][Governor].snum]->numplanets; s++)
      {
        if (!strncmp
            (Stars[Dir[Playernum - 1][Governor].snum]->pnames[s], buf,
             MIN(len,
                 strlen(Stars[Dir[Playernum - 1][Governor].snum]->pnames[s]))))
        {
          notify(Playernum, Governor, "Sorry, that name is already taken.\n");
          return;
        }
      }

      strncpy(Stars[Dir[Playernum - 1][Governor].snum]->
              pnames[Dir[Playernum - 1][Governor].pnum], buf, NAMESIZE - 1);
      putstar(Stars[Dir[Playernum - 1][Governor].snum],
              Dir[Playernum - 1][Governor].snum);
      deductAPs(Playernum, Governor, APcount, Dir[Playernum - 1][Governor].snum,
                0);
    }
    else
    {
      notify(Playernum, Governor, "You have to 'cs' to a planet to name it.\n");
      return;
    }
  }
  else if (match(args[1], "race"))
  {
    if (Governor != 0)
    {
      notify(Playernum, Governor, "Only your leader can name your race.\n");
      return;
    }

    Race = races[Playernum - 1];

    if (Race->governor[Governor].toggle.standby & LOCK_RNAME)
    {
      notify(Playernum, Governor, "You can't change your race name again.\n");
    }
    else
    {
      /* CWL's name changes cost APs -mfw */
      if (!strncmp(Race->name, "Unknown", 7))
        APcount = 0;
      else
        APcount = 5;

      if (!enufAP
          (Playernum, Governor,
           Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1],
           APcount))
      {
        notify(Playernum, Governor, "You don't have enough APs\n");
        return;
      }
      else
      {
        deductAPs(Playernum, Governor, APcount,
                  Dir[Playernum - 1][Governor].snum, 0);
      }

      strncpy(Race->name, buf, RNAMESIZE - 1);

      sprintf(buf, "Race name changed to `%s'.\n", Race->name);
      notify(Playernum, Governor, buf);

      if (chat_flag != FREE_CHAT)
        Race->governor[Governor].toggle.standby |= LOCK_RNAME;

      putrace(Race);
    }
  }
  else if (match(args[1], "governor"))
  {
    Race = races[Playernum - 1];

    if (Race->governor[Governor].toggle.standby & LOCK_GNAME)
    {
      notify(Playernum, Governor,
             "You can't change your governor name again.\n");
    }
    else
    {
      strncpy(Race->governor[Governor].name, buf, RNAMESIZE - 1);

      sprintf(buf, "Governor name changed to `%s'.\n",
              Race->governor[Governor].name);
      notify(Playernum, Governor, buf);

      if (chat_flag != FREE_CHAT)
        Race->governor[Governor].toggle.standby |= LOCK_GNAME;

      putrace(Race);
    }
  }
  else if (match(args[1], "fleet"))
  {
    /* Allow player to name fleet -mfw */
    if (Dir[Playernum - 1][Governor].level == LEVEL_SHIP)
    {
      int             fl;

      (void)getship(&ship, Dir[Playernum - 1][Governor].shipno);
      Race = races[Playernum - 1];

      if ((fl = ship->fleetmember))
      {
        if (fl > 0 && Race->fleet[fl].admiral != Governor &&
            Race->fleet[fl].flagship != 0)
        {
          notify(Playernum, Governor, "You're not admiral of this fleet.\n");
          return;
        }

        strncpy(Race->fleet[ship->fleetmember].name, buf, FLEET_NAMESIZE);
        notify(Playernum, Governor, "Fleet name set.\n");
        putrace(Race);
      }
      else
      {
        notify(Playernum, Governor, "This ship is not in a fleet.\n");
      }

      free((char *)ship);
      return;
    }
    else
    {
      notify(Playernum, Governor,
             "You have to 'cs' to a ship in the fleet to name your fleet.\n");
      return;
    }
  }
  else
  {
    notify(Playernum, Governor, "I don't know what you mean.\n");
    return;
  }
  /* } not allowing whitespaces -mfw */
}

int
MostAPs(int Playernum, startype * s)
{
  register int    i, t = 0;

  for (i = 0; i < MAXPLAYERS; i++)
    if (s->AP[i] >= t)
      t = s->AP[i];

  return (s->AP[Playernum - 1] == t);
}

void
announce(int Playernum, int Governor, char *message, int mode, int override)
{
  racetype       *Race;
  char            symbol = '\a';

  Race = races[Playernum - 1];

  if (mode == SHOUT && !Race->God)
  {
    notify(Playernum, Governor,
           "You are not privileged to use this command.\n");
    return;
  }

  if (chat_flag == NO_CHAT && !Race->God)
  {
    notify(Playernum, Governor,
           "That mode of communication is currently disabled.\n");
    return;
  }

  switch (Dir[Playernum - 1][Governor].level)
  {
    case LEVEL_UNIV:
      if (mode == ANN)
        mode = BROADCAST;
      break;
    default:
      if ((mode == ANN) &&
          !(!!isset
            (Stars[Dir[Playernum - 1][Governor].snum]->inhabited, Playernum) ||
            Race->God))
      {
        sprintf(buf,
                "You do not inhabit this system or have diety privileges.\n");
        notify(Playernum, Governor, buf);
        return;
      }
  }

  switch (mode)
  {
    case ANN:
      symbol = ':';
      break;
    case BROADCAST:
      symbol = '>';
      break;
    case SHOUT:
      symbol = '!';
      break;
    case THINK:
      symbol = '=';
      break;
  }
  *message++;

  sprintf(msg, "%s\n", message);

  if (mode == EMOTE)
    sprintf(head, "%s [%d,%d] %s ", Race->name, Playernum, Governor,
            Race->governor[Governor].name);
  else
  {
    sprintf(head, "%s \"%s\" [%d,%d] %c ", Race->name,
            Race->governor[Governor].name, Playernum, Governor, symbol);
  }

  switch (mode)
  {
    case ANN:
      d_announce(Playernum, Governor, Dir[Playernum - 1][Governor].snum, head,
                 msg);
      break;
    case BROADCAST:
      d_broadcast(Playernum, Governor, head, msg, 0);
      break;
    case SHOUT:
      d_shout(Playernum, Governor, head, msg);
      break;
    case THINK:
      d_think(Playernum, Governor, head, msg);
      break;
    case EMOTE:
      d_broadcast(Playernum, Governor, head, msg, 1);
      break;
    default:
      break;
  }
}

/* garble -CWL */
char           *
garble_msg(char *s, int pcnt, int diff, int Playernum)
{
  int             l, i;
  int             over;
  int             rand;
  char            word[130];
  char            wbuf[130];
  char           *wp;
  char           *wbp;
  char           *sp;

  // long fsize; -mfw
  long            lookup, lp;
  int             csum;
  int             wascap;

  l = strlen(s);
  over = (int)(102.0 * sqrt((double)diff));

  if (USE_GARBLEFILE && size_of_words)
  {
    rewind(garble_file);

    if (!garble_file)
      return s;

    gbuf[0] = 0;
    word[0] = 0;
    sp = s;

    while (*sp)
    {
      wp = word;

      while (*sp && !isspace(*sp) && !mypunct(*sp) && !isdigit(*sp))
      {
        *wp++ = *sp++;
      }
      *wp = 0;

      if (word[0])
      {
        wascap = isupper(word[0]);
        csum = 0;
        wp = word;

        while (*wp)
        {
          csum += (int)(*wp++);
        }

        rand = int_rand(1, over);

        if (rand > pcnt)
        {
          if (rand > 100)
          {
            /* This word will be garbled by static -mfw */
            for (lp = 0; lp < strlen(word); lp++)
            {
              word[lp] = '*';
            }
          }
          else
          {
            /* This word will be garbled by language barrier (translated) */
            lookup = (Playernum * pcnt * csum * strlen(word)) % size_of_words;

            if (UNIFORM_WORDS)
            {
              fseek(garble_file, (lookup * (UNIFORM_WORDS)), 0);
              fgets(wbuf, UNIFORM_WORDS, garble_file);
            }
            else
            {
              for (lp = 0; lp < lookup; lp++)
              {
                fgets(wbuf, 80, garble_file);
              }
            }

            if (wascap && islower(wbuf[0]))
            {
              wbuf[0] = toupper(wbuf[0]);
            }
            else if (isupper(wbuf[0]) && !wascap)
            {
              wbuf[0] = tolower(wbuf[0]);
            }

            wbp = wbuf;
            wp = word;

            while (*wbp && *wbp != '\n' && *wbp != UNIFORM_FILLER)
            {
              *wp++ = *wbp++;
            }
            *wp = 0;
          }
        }

        if (strlen(gbuf) + strlen(word) < BUFFER_LEN)
        {
          strcat(gbuf, word);
        }

        rewind(garble_file);
      }

      wp = word;

      if (isdigit(*sp) && (int_rand(1, over) > pcnt))
      {
        *wp++ = (char)(int_rand(0, 9) + (int)'0');
        sp++;
      }
      else
      {
        *wp++ = *sp++;
      }
      *wp = 0;

      strcat(gbuf, word);
    }                           /* while */

    strcpy(s, gbuf);
    return gbuf;
  }
  else
  {
    for (i = 0; i < l; i++)
    {
      if ((int_rand(1, over) > pcnt) && (s[i] != '\n') && (s[i] != ' ') &&
          (s[i] != '[') && (s[i] != ']') && (s[i] != ':') && (s[i] != '>'))
      {
        s[i] = ' ';
      }
    }

    return s;
  }
}                               /* end garble_msg */

void
garble_chat(int Playernum, int Governor)
{
  int             temp1, temp2;

  if (argn < 2 || argn > 3)
  {
    sprintf(buf, "You need to specify the chat level.\n");
    notify(Playernum, Governor, buf);
    return;
  }

  temp1 = atoi(args[1]);

  if (temp1 < 0 || temp1 > 2)
  {
    sprintf(buf, "Invalid chat level, use 0-2.\n");
    notify(Playernum, Governor, buf);
    return;
  }

  if (temp1 == 1)
  {
    temp2 = atoi(args[2]);

    if (temp2 < 1 || temp2 > 4)
    {
      sprintf(buf, "Invalid static level, use 1-4.\n");
      notify(Playernum, Governor, buf);
      return;
    }

    chat_static = temp2;
  }
  else
  {
    chat_static = 1;
  }

  chat_flag = temp1;

  if (chat_flag == 1)
  {
    sprintf(buf, "Chat now at level %d with static level at %d\n", chat_flag,
            chat_static);
  }
  else
  {
    sprintf(buf, "Chat now at level %d.", chat_flag);
  }

  notify(Playernum, Governor, buf);

  return;
}
