/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 ***********************************************
 * 
 * #ident  "@(#)fleet.c  1.0 6/28/01 "
 * 
 * Galactic Bloodshed Fleet System
 *
 * Author: Michael F. Wilkinson (mfw)
 *
 * Contains:
 *   fleet() called from GB_server.c
 *   ancillary functions
 *
 * Taken from an idea from HAP and adapted for
 * GB+, see 'fleets' in concept.txt
 *
 ***********************************************/

#include <stdlib.h>
#include <string.h>
/* #include <strings.h> */

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "fleet.h"

extern long     Shipdata[NUMSTYPES][NUMABILS];
extern const char *Shipnames[];

void            fleet(int, int, int);
int             bad_flagship(int, int, int);
int             fctofi(char);
char            fitofc(int);

#include "proto.h"

void
fleet(int Playernum, int Governor, int APcount)
{
  shiptype       *st;
  int             i, sh, adm, some = 0;
  char            obuf[1024];
  char            hbuf[80];
  char            name[80];

  notify(Playernum, Governor,
         "\nOverview of Operational Fleets with Attached Vessels\n");

  notify(Playernum, Governor,
         "----------------------------------------------------\n");

  for (i = 1; i <= MAXFLEETS; i++)
  {
    obuf[0] = '\0';

    if ((sh = races[Playernum - 1]->fleet[i].flagship))
    {
      some = 1;

      strcpy(name, races[Playernum - 1]->fleet[i].name);
      adm = races[Playernum - 1]->fleet[i].admiral;

      if (name[0])
      {
        sprintf(obuf, "(%c) %18s - Admiral: \"%s\" [%d,%d]\n", fitofc(i), name,
                races[Playernum - 1]->governor[adm].name, Playernum, adm);
      }
      else
      {
        sprintf(obuf, "(%c) %12s Fleet - Admiral: \"%s\" [%d,%d]\n", fitofc(i),
                Fleetnames[i], races[Playernum - 1]->governor[adm].name,
                Playernum, adm);
      }

      strcat(obuf, "                         Vessels: ");

      if (bad_flagship(Playernum, Governor, i))
      {
        sh = 0;
        sprintf(hbuf, "Error with flagship (cleared).");
        strcat(obuf, hbuf);
      }

      while (sh)
      {
        if (getship(&st, sh))
        {
          sh = st->nextinfleet;

          if (st->alive)
          {
            sprintf(hbuf, "%c%d ", Shipltrs[st->type], st->number);
          }

          strcat(obuf, hbuf);

          free((char *)st);
        }
        else
        {
          sh = 0;
        }
      }

      strcat(obuf, "\n");
      notify(Playernum, Governor, obuf);
    }
  }

  if (!some)
  {
    notify(Playernum, Governor, "No active fleets.\n");
  }

  notify(Playernum, Governor, "\n");
}

int
bad_flagship(int player, int gov, int fl)
{
  racetype       *r;
  shiptype       *s;
  int             flagship;

  r = races[player - 1];

  flagship = r->fleet[fl].flagship;

  if (!flagship)
  {
    /* no flagship, there is no error, return ok */
    return 0;
  }

  if (!getship(&s, flagship))
  {
    /* Couldn't get the ship, we have a problem, clear it */
    r->fleet[fl].flagship = 0;
    r->fleet[fl].admiral = 0;
    putrace(r);
    return 1;
  }

  if (s->fleetmember != fl)
  {
    /* The fleet the ship thinks it's in is different, error, clear it */
    r->fleet[fl].flagship = 0;
    r->fleet[fl].admiral = 0;
    putrace(r);
    free((char *)s);
    return 1;
  }

  free((char *)s);
  return 0;
}

/* Fleet character to fleet integer */
int
fctofi(char c)
{
  int             i;

  i = (c >= ('a' - 1)) ? (c - ('a' - 1)) : (c - ('A' - 1));

  if (i < 1 || i > MAXFLEETS)
    return 0;
  else
    return i;
}

/* Fleet integer to fleet character */
char
fitofc(int i)
{
  if (i < 1 || i > MAXFLEETS)
    return (char)0;
  else
    return (i + ('A' - 1));
}
