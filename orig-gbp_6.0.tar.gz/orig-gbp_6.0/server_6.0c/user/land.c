/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 *  #ident  "@(#)land.c  1.12 12/3/93 "
 * 
 *  land.c -- land a ship,
 *  also....
 *  dock -- dock a ship w/ another ship
 *  and.....
 *  assault -- a very un-PC version of land/dock
 
 $Header: /var/cvs/gbp/GB+/user/land.c,v 1.5 2007/07/06 18:06:56 gbp Exp $
 */

#include <stdlib.h>
#include <math.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"

extern long     Shipdata[NUMSTYPES][NUMABILS];
static int      roll;

EXTERN void     land(int, int, int);
EXTERN int      crash(shiptype *, double);
EXTERN int      docked(shiptype *);
EXTERN int      overloaded(shiptype *);

#include "proto.h"

void
land(int Playernum, int Governor, int APcount)
{
  shiptype       *s, *s2;
  planettype     *p;
  sectortype     *sect;

  int             shipno, ship2no, x = -1, y = -1, i, numdest = -1;
  int             strength = 0, damage = 0, nupdates;
  double          fuel;
  double          Dist;
  racetype       *Race, *alien;
  int             nextshipno;

  if (argn < 2)
  {
    notify(Playernum, Governor, "Land what?\n");
    return;
  }

  nextshipno = start_shiplist(Playernum, Governor, args[1]);

  while ((shipno = do_shiplist(&s, &nextshipno)))
  {
    if (in_list(Playernum, args[1], s, &nextshipno))
    {
      if (overloaded(s))
      {
        sprintf(buf, "%s is too overloaded to land.\n", Ship(s));
        notify(Playernum, Governor, buf);
        free((char *)s);
        continue;
      }

      if (!Shipdata[s->type][ABIL_CANDOCK])
      {
        sprintf(buf, "This ship is not equipped to be landed or docked.\n");
        notify(Playernum, Governor, buf);
        free((char *)s);
        continue;
      }

      if (s->type == OTYPE_QUARRY)
      {
        notify(Playernum, Governor, "You can't load quarries onto ship.\n");
        free((char *)s);
        continue;
      }

      if (docked(s))
      {
        notify(Playernum, Governor, "That ship is docked to another ship.\n");
        free((char *)s);
        continue;
      }

      if (args[2][0] == '#')
      {
        /* 
         * attempting to land on a friendly ship (for
         * carriers/stations/etc)
         */
        sscanf(args[2] + 1, "%d", &ship2no);

        if (!getship(&s2, ship2no))
        {
          sprintf(buf, "Ship #%d wasn't found.\n", ship2no);
          notify(Playernum, Governor, buf);
          free((char *)s);
          continue;
        }

        if (testship(Playernum, Governor, s2))
        {
          notify(Playernum, Governor, "Illegal format.\n");
          free((char *)s);
          free((char *)s2);
          continue;
        }

        if (s2->type == OTYPE_FACTORY)
        {
          notify(Playernum, Governor, "Can't land on factories.\n");
          free((char *)s);
          free((char *)s2);
          continue;
        }

        if (landed(s))
        {
          if (!landed(s2))
          {
            sprintf(buf, "%s is not landed on a planet.\n", Ship(s2));
            notify(Playernum, Governor, buf);
            free((char *)s);
            free((char *)s2);
            continue;
          }

          if (s2->storbits != s->storbits)
          {
            notify(Playernum, Governor,
                   "These ships are not in the same star system.\n");
            free((char *)s);
            free((char *)s2);
            continue;
          }

          if (s2->pnumorbits != s->pnumorbits)
          {
            notify(Playernum, Governor,
                   "These ships are not landed on the same planet.\n");
            free((char *)s);
            free((char *)s2);
            continue;
          }

          if ((s2->land_x != s->land_x) || (s2->land_y != s->land_y))
          {
            notify(Playernum, Governor,
                   "These ships are not in the same sector.\n");
            free((char *)s);
            free((char *)s2);
            continue;
          }

          if (s->on)
          {
            sprintf(buf, "%s must be turned off before loading.\n", Ship(s));
            notify(Playernum, Governor, buf);
            free((char *)s);
            free((char *)s2);
            continue;
          }

          if (Size(s) > Hanger(s2))
          {
            sprintf(buf,
                    "Mothership does not have %d hanger space available to load ship.\n",
                    Size(s));
            notify(Playernum, Governor, buf);
            free((char *)s);
            free((char *)s2);
            continue;
          }

          /* ok, load 'em up */
          remove_sh_plan(s);

          /* 
           * get the target ship again because
           * it had a pointer changed (and put
           * to disk) in the remove routines
           */
          free((char *)s2);
          (void)getship(&s2, ship2no);

          insert_sh_ship(s, s2);

          /* increase mass of mothership */
          s2->mass += s->mass;
          s2->hanger += (unsigned short)Size(s);
          fuel = 0.0;

          sprintf(buf, "%s loaded onto %s using %.1f fuel.\n", Ship(s),
                  Ship(s2), fuel);
          notify(Playernum, Governor, buf);

          s->docked = 1;
          clearhyper(s);

          putship(s2);
          free((char *)s2);
        }
        else if (s->docked)
        {
          sprintf(buf, "%s is already docked or landed.\n", Ship(s));
          notify(Playernum, Governor, buf);
          free((char *)s);
          free((char *)s2);
          continue;
        }
        else
        {
          /* 
           * Check if the ships are in the same
           * scope level. Maarten
           */
          if (s->whatorbits != s2->whatorbits)
          {
            notify(Playernum, Governor,
                   "Those ships are not in the same scope.\n");
            free((char *)s);
            free((char *)s2);
            continue;
          }

          /* 
           * check to see if close enough to
           * land
           */
          Dist = sqrt((double)Distsq(s2->xpos, s2->ypos, s->xpos, s->ypos));

          if (Dist > DIST_TO_DOCK)
          {
            sprintf(buf, "%s must be %.2f or closer to %s.\n", Ship(s),
                    DIST_TO_DOCK, Ship(s2));
            notify(Playernum, Governor, buf);
            free((char *)s);
            free((char *)s2);
            continue;
          }

          fuel = 0.05 + Dist * 0.025 * sqrt(s->mass);

          if (s->fuel < fuel)
          {
            sprintf(buf, "Not enough fuel.\n");
            notify(Playernum, Governor, buf);
            free((char *)s);
            free((char *)s2);
            continue;
          }

          if (Size(s) > Hanger(s2))
          {
            sprintf(buf,
                    "Mothership does not have %d hanger space available to load ship.\n",
                    Size(s));
            notify(Playernum, Governor, buf);
            free((char *)s);
            free((char *)s2);
            continue;
          }

          use_fuel(s, fuel);

          /* 
           * remove the ship from whatever
           * scope it is currently in
           */
          if (s->whatorbits == LEVEL_PLAN)
          {
            remove_sh_plan(s);
          }
          else if (s->whatorbits == LEVEL_STAR)
          {
            remove_sh_star(s);
          }
          else
          {
            notify(Playernum, Governor,
                   "Ship is not in planet or star scope.\n");
            free((char *)s);
            free((char *)s2);
            continue;
          }

          /* 
           * get the target ship again because
           * it had a pointer changed (and put
           * to disk) in the remove routines
           */
          free((char *)s2);
          (void)getship(&s2, ship2no);

          insert_sh_ship(s, s2);

          /* increase mass of mothership */
          s2->mass += s->mass;
          s2->hanger += (unsigned short)Size(s);

          sprintf(buf, "%s landed on %s using %.1f fuel.\n", Ship(s), Ship(s2),
                  fuel);
          notify(Playernum, Governor, buf);

          clearhyper(s);
          s->docked = 1;

          putship(s2);
          free((char *)s2);
        }
      }
      else
      {
        /* attempting to land on a planet */
        if (s->docked)
        {
          sprintf(buf, "%s is docked.\n", Ship(s));
          notify(Playernum, Governor, buf);
          free((char *)s);
          continue;
        }

        sscanf(args[2], "%d,%d", &x, &y);

        if (s->whatorbits != LEVEL_PLAN)
        {
          sprintf(buf, "%s doesn't orbit a planet.\n", Ship(s));
          notify(Playernum, Governor, buf);
          free((char *)s);
          continue;
        }

        if (!Shipdata[s->type][ABIL_CANLAND])
        {
          sprintf(buf, "This ship is not equipped to land.\n");
          notify(Playernum, Governor, buf);
          free((char *)s);
          continue;
        }

        if ((s->storbits != Dir[Playernum - 1][Governor].snum) ||
            (s->pnumorbits != Dir[Playernum - 1][Governor].pnum))
        {
          sprintf(buf, "You have to cs to the planet it orbits.\n");
          notify(Playernum, Governor, buf);
          free((char *)s);
          continue;
        }

        if (!speed_rating(s))
        {
          sprintf(buf, "This ship is not rated for maneuvering.\n");
          notify(Playernum, Governor, buf);
          free((char *)s);
          continue;
        }

        if (!enufAP
            (Playernum, Governor, Stars[s->storbits]->AP[Playernum - 1],
             APcount))
        {
          sprintf(buf, "Not enough APs.\n");
          notify(Playernum, Governor, buf);
          free((char *)s);
          continue;
        }

        getplanet(&p, (int)s->storbits, (int)s->pnumorbits);

        /* handle wormhole */
        if (p->type == TYPE_WORMHOLE)
        {
          free((char *)p);
          go_thru_wormhole(s);
          free((char *)s);
          continue;
        }

        sprintf(buf, "Planet /%s/%s has gravity field of %.2f.\n",
                Stars[s->storbits]->name,
                Stars[s->storbits]->pnames[s->pnumorbits], gravity(p));
        notify(Playernum, Governor, buf);

        sprintf(buf, "Distance to planet: %.2f.\n", Dist =
                sqrt((double)
                     Distsq(Stars[s->storbits]->xpos + p->xpos,
                            Stars[s->storbits]->ypos + p->ypos, s->xpos,
                            s->ypos)));
        notify(Playernum, Governor, buf);

        if (Dist > DIST_TO_LAND)
        {
          sprintf(buf, "%s must be %.3g or closer to the planet (%.2f).\n",
                  Ship(s), DIST_TO_LAND, Dist);
          notify(Playernum, Governor, buf);
          free((char *)s);
          free((char *)p);
          continue;
        }

        fuel = s->mass * gravity(p) * LAND_GRAV_MASS_FACTOR;

        if ((x < 0) || (y < 0) || (x > p->Maxx - 1) || (y > p->Maxy - 1))
        {
          sprintf(buf, "Illegal coordinates.\n");
          notify(Playernum, Governor, buf);
          free((char *)s);
          free((char *)p);
          continue;
        }

        /* handle FIRST_COMBAT rule here */
        nupdates = get_num_updates();

        for (i = 1; i <= Num_races; i++)
        {
          if (i != Playernum && p->info[i - 1].popn)
          {
            Race = races[Playernum - 1];
            alien = races[i - 1];

            if (alien->Guest)
            {
              notify(Playernum, Governor, "Can't land on a Guest's planet.\n");
              free((char *)s);
              free((char *)p);
              continue;
            }

            if (nupdates < CombatUpdate)
            {
              /* if combat is not enabled yet, you cannot even land on an alien 
               * planet */

              if (!(isset(Race->allied, i) && isset(alien->allied, Playernum)))
              {
                sprintf(buf,
                        "Can only land on allies planets before Combat enabled.\nCombat enabled at update [%d]\n",
                        CombatUpdate);
                notify(Playernum, Governor, buf);
                free((char *)s);
                free((char *)p);
                continue;
              }
            }
          }
        }

#ifdef DEFENSE
        /* 
         * people who have declared war on you will
         * fire at your landing ship
         */

        /* HUTm (kse) enslaved planets do not shoot at enslaver's ships */
        if (p->slaved_to != s->owner)
        {
          for (i = 1; i <= Num_races; i++)
          {
            if (s->alive && i != Playernum && p->info[i - 1].popn &&
                p->info[i - 1].guns && p->info[i - 1].destruct)
            {
              alien = races[i - 1];

              if (isset(alien->atwar, (int)s->owner))
              {
                /* 
                 * attack the landing
                 * ship
                 */
                strength =
                  MIN((int)p->info[i - 1].guns, (int)p->info[i - 1].destruct);

                if (strength)
                {
                  damage =
                    shoot_planet_to_ship(alien, p, s, strength, buf, temp);

                  post(temp, COMBAT);
                  notify_star(0, 0, (int)s->owner, (int)s->storbits, temp);
                  warn(i, (int)Stars[s->storbits]->governor[i - 1], buf);
                  notify((int)s->owner, (int)s->governor, buf);
                  p->info[i - 1].destruct -= strength;
                }
              }
            }

            if (!s->alive)
            {
              putplanet(p, (int)s->storbits, (int)s->pnumorbits);
              putship(s);
              free((char *)p);
              free((char *)s);
              return;
            }
          }
        }
#endif

        if (s->damage)
        {
          sprintf(buf, "Attempting to land ship with %d%% damage...\n",
                  (int)s->damage);
          notify(Playernum, Governor, buf);
        }

        /* 
         * check to see if the ship crashes from lack
         * of fuel or damage
         */
        if (crash(s, fuel))
        {
          /* 
           * damaged ships stand of chance of
           * crash landing
           */
          if (roll)
          {
            sprintf(buf, "You rolled a %d!\n", roll);
          }
          else
          {
            sprintf(buf, "You had %.1ff while the landing required %.1ff\n",
                    s->fuel, fuel);
          }
          notify(Playernum, Governor, buf);

          numdest =
            shoot_ship_to_planet(s, p, round_rand((double)(s->destruct) / 3.),
                                 x, y, 1, 0, HEAVY, long_buf, short_buf);

          if (numdest > 0)
          {
            sprintf(buf,
                    "BOOM!! %s crashes on sector %d,%d with blast radius of %d.\n",
                    Ship(s), x, y, numdest);
          }
          else
          {
            sprintf(buf,
                    "BOOM!! %s crashes on sector %d,%d with no collateral damage.\n",
                    Ship(s), x, y);
          }

          for (i = 1; i <= Num_races; i++)
          {
            if (p->info[i - 1].numsectsowned || i == Playernum)
            {
              warn(i, (int)Stars[s->storbits]->governor[i - 1], buf);
            }
          }

          kill_ship((int)s->owner, s);
        }
        else
        {
          s->land_x = x;
          s->land_y = y;
          s->xpos = p->xpos + Stars[s->storbits]->xpos;
          s->ypos = p->ypos + Stars[s->storbits]->ypos;
          use_fuel(s, fuel);
          s->docked = 1;
          clearhyper(s);
          s->whatdest = LEVEL_PLAN;     /* no destination */
          s->deststar = s->storbits;
          s->destpnum = s->pnumorbits;

          if (getsector(&sect, p, x, y))
          {
            if (sect->condition == WASTED)
            {
              sprintf(buf, "Warning: That sector is a wasteland!\n");
              notify(Playernum, Governor, buf);
            }
            else if (sect->owner && sect->owner != Playernum)
            {
              Race = races[Playernum - 1];
              alien = races[sect->owner - 1];

              if (!
                  (isset(Race->allied, sect->owner) &&
                   isset(alien->allied, Playernum)))
              {
                sprintf(buf, "You have landed on an alien sector (%s).\n",
                        alien->name);
                notify(Playernum, Governor, buf);
              }
              else
              {
                sprintf(buf, "You have landed on allied sector (%s).\n",
                        alien->name);
                notify(Playernum, Governor, buf);
              }
            }
          }
          else
          {
            notify(Playernum, Governor,
                   "Error in sector database, ship not landed, notify deity.\n");
            return;
          }

          if (s->whatorbits == LEVEL_UNIV)
            deductAPs(Playernum, Governor, APcount, 0, 1);
          else
            deductAPs(Playernum, Governor, APcount, (int)s->storbits, 0);

          putplanet(p, (int)s->storbits, (int)s->pnumorbits);

          putsector(sect, p, x, y);

          /* send messages to anyone there */
          sprintf(buf, "%s observed landing on sector %d,%d,planet /%s/%s.\n",
                  Ship(s), s->land_x, s->land_y, Stars[s->storbits]->name,
                  Stars[s->storbits]->pnames[s->pnumorbits]);

          for (i = 1; i <= Num_races; i++)
          {
            if (p->info[i - 1].numsectsowned && i != Playernum)
            {
              notify(i, (int)Stars[s->storbits]->governor[i - 1], buf);
            }
          }

          sprintf(buf, "%s landed on planet.\n", Ship(s));
          notify(Playernum, Governor, buf);

          free((char *)sect);
        }

        free((char *)p);
      }
      putship(s);
    }

    free((char *)s);

  }                             /* while */
}

int
crash(shiptype * s, double fuel)
{
  roll = 0;

  if (s->fuel < fuel)
    return 1;
  else if ((roll = int_rand(1, 100)) <= (int)s->damage)
    return 1;
  else
    return 0;
}

int
docked(shiptype * s)
{
  return (s->docked && s->whatdest == LEVEL_SHIP);
}

int
overloaded(shiptype * s)
{
  /* HUT modification (tze) : ship is consedered to be overloaded if there's
   * more than 1 fuel over capacity. */
  return ((s->resource > Max_resource(s)) || (s->fuel > Max_fuel(s) + 1) ||
          (s->popn + s->troops > s->max_crew) ||
          (s->destruct > Max_destruct(s)));
}

int
wormhole_damage(int here, int there)
{
  /* return maximum possible damage for traversal of this wormhole. Based on
   * travel distance. */
  int             dmg;
  startype       *h, *t;
  double          tdist;

  h = Stars[here];
  t = Stars[there];

  tdist = sqrt((double)Distsq(h->xpos, h->ypos, t->xpos, t->ypos));

  dmg = (int)((tdist / UNIVSIZE) * 200);

  return dmg;
}

void
go_thru_wormhole(shiptype * ship)
{
  startype       *here, *there;
  int             h, t;
  int             damage, maxdamage;
  planettype     *dpl;

  if (ship->used_wormhole)
  {
    sprintf(buf, "That ship already went through a wormhole this segment.\n");
    notify(ship->owner, ship->governor, buf);
  }

  h = ship->storbits;
  here = Stars[h];
  t = here->wh_dest_starnum;
  there = Stars[t];

  getplanet(&dpl, t, (int)there->numplanets - 1);

  if (ship->tech < TECH_WORMHOLE)
  {
    maxdamage = wormhole_damage(h, t);

    damage = (int)((1 - (ship->tech / TECH_WORMHOLE)) * maxdamage);

    ship->damage += damage;
  }

  if (damage)
  {
    sprintf(buf, "Ship[%d] incurred %d%% damage\n", ship->number, damage);
    notify(ship->owner, ship->governor, buf);
  }

  if (ship->damage > 100)
  {
    sprintf(buf, "Damage destroyed ship\n");
    kill_ship((int)ship->owner, ship);
    return;
  }

  remove_sh_plan(ship);
  ship->storbits = t;
  ship->pnumorbits = there->numplanets - 1;
  ship->xpos = there->xpos + dpl->xpos;
  ship->ypos = there->ypos + dpl->ypos;
  ship->protect.planet = 0;
  insert_sh_plan(dpl, ship);
  ship->used_wormhole = 1;
  StarsInhab[ship->storbits] = 1;
  setbit(there->inhabited, ship->owner);
  setbit(there->explored, ship->owner);
  dpl->explored = 1;
  dpl->info[ship->owner - 1].explored = 1;
  ship->whatdest = LEVEL_PLAN;
  ship->deststar = ship->storbits;
  ship->destpnum = ship->pnumorbits;

  putship(ship);
  putplanet(dpl, (int)ship->storbits, (int)ship->pnumorbits);
  putstar(there, t);

  sprintf(buf, "%s has traversed a wormhole!\nShip is at: %s\n", Ship(ship),
          prin_ship_orbits(ship));
  notify(ship->owner, ship->governor, buf);
}
