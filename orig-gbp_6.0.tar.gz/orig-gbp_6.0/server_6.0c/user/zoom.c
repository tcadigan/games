/*
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 ***********************************************
 * #ident  "@(#)zoom.c	1.13 12/3/93 "
 * zoom.c
 *
 * Created:
 * Author:  ???
 *
 * Version:  1.9 17:35:12
 *
 * Contains:
 *   zoom()
 *
 * $Header: /var/cvs/gbp/GB+/user/zoom.c,v 1.3 2007/07/06 18:09:34 gbp Exp $
 *
 ***********************************************/

#include <stdlib.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "ranks.h"
#include "buffers.h"
#include "csp.h"
#include "csp_types.h"
#include "proto.h"

/* 
 * GB_schedule:
 * 
 * arguments: Playernum Playernum who called it Governor Governor who called it
 * 
 * Called by: process_command
 * 
 */

void
zoom(int Playernum, int Governor)
{
  double          num, denom;
  int             i;

  i = (Dir[Playernum - 1][Governor].level == LEVEL_UNIV);

  if (argn > 1)
  {
    if (sscanf(args[1], "%lf/%lf", &num, &denom) == 2)
    {
      /* num/denom format */
      if (denom == 0.0)
      {
        sprintf(buf, "Illegal denominator value.\n");
        notify(Playernum, Governor, buf);
      }
      else                      /* if (denom) */
        Dir[Playernum - 1][Governor].zoom[i] = num / denom;
    }
    else
    {
      /* one number */
      Dir[Playernum - 1][Governor].zoom[i] = num;
    }
  }
  sprintf(buf, "Zoom value %G, lastx = %G, lasty = %G.\n",
          Dir[Playernum - 1][Governor].zoom[i],
          Dir[Playernum - 1][Governor].lastx[i],
          Dir[Playernum - 1][Governor].lasty[i]);
  notify(Playernum, Governor, buf);
}

void
csp_zoom(int Playernum, int Governor)
{
  double          num, denom;
  int             i, ns;

  i = (Dir[Playernum - 1][Governor].level == LEVEL_UNIV);

  if (argn > 2)
  {
    i = atoi(args[2]);
    if (i)
      i = 1;
  }
  if (argn > 3)
  {
    if ((ns = sscanf(args[3], "%lf/%lf", &num, &denom)) == 2)
    {
      /* num/denom format */
      if (denom == 0.0)
      {
        sprintf(buf, "Illegal denominator value.\n");
        notify(Playernum, Governor, buf);
      }
      else                      /* if (denom) */
        Dir[Playernum - 1][Governor].zoom[i] = num / denom;
    }
    else if (ns == 1)
    {
      /* one number */
      Dir[Playernum - 1][Governor].zoom[i] = num;
    }
    else
    {
      sprintf(buf, "%c %d %d\n", CSP_CLIENT, CSP_ERR, CSP_ERR);
      notify(Playernum, Governor, buf);
    }
  }
  sprintf(buf, "%c %d %d %f\n", CSP_CLIENT, CSP_ZOOM, i,
          Dir[Playernum - 1][Governor].zoom[i]);
  notify(Playernum, Governor, buf);
}
