/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)orbit.c  1.9 12/3/93 "
 * 
 * orbit.c -- display orbits of planets (graphic representation)
 * 
 * OPTIONS -p : If this option is set, ``orbit'' will not display planet names.
 * 
 * -S : Do not display star names.
 * 
 * -s : Do not display ships.
 * 
 * -(number) : Do not display that #'d ship or planet (in case it obstructs the
 * view of another object)
 *
 * $Header: /var/cvs/gbp/GB+/user/orbit.c,v 1.3 2007/07/06 18:09:34 gbp Exp $
 */

#include <stdlib.h>
#include <string.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"
#include <curses.h>
#include <stdio.h>
extern char     Shipltrs[];

static racetype *Race;

/* Global Definitions here... Should possibly move 'em */
char            Psymbol[] =
  { '@', 'o', 'O', '#', '~', '.', '"', '-', '0', '(' };
const char     *Planet_types[] = { "Class M", "Asteroid", "Airless", "Iceball",
  "Jovian", "Waterball", "Forest", "Desert", "Wormhole", "Swamp"
};

          /* Note: swamp is not implemented */

EXTERN void     orbit(int, int, int);
EXTERN void     DispStar(int, int, int, startype *, int, char *, orbitinfo *);
EXTERN void     DispPlanet(int, int, int, planettype *, char *, racetype *,
                           char *, orbitinfo *);
EXTERN void     DispShip(int, int, placetype *, shiptype *, planettype *, int,
                         char *, orbitinfo *);

#include "proto.h"

void
orbit(int Playernum, int Governor, int APcount)
{
  register int    sh, i, iq;
  planettype     *p;
  shiptype       *s;
  placetype       where;
  orbitinfo       oi;

  oi.DontDispPlanets = oi.DontDispShips = oi.DontDispStars = 0;
  oi.DontDispNum = -1;

  /* find options, set flags accordingly */
  if (optn)
  {
    if (opts['s'])
      oi.DontDispShips = 1;
    if (opts['S'])
      oi.DontDispStars = 1;
    if (opts['p'])
      oi.DontDispPlanets = 1;
    if (opts['d'])
    {
      if ((oi.DontDispNum = opts['d']))
      {
        oi.DontDispNum--;       /* make a '1' into a '0' */
      }
      else
      {
        sprintf(buf, "Bad number %d.\n", oi.DontDispNum);
        notify(Playernum, Governor, buf);
        oi.DontDispNum = -1;
      }
    }
  }

  if (argn == 1)
  {
    where = Getplace(Playernum, Governor, ":", 0);
    i = (Dir[Playernum - 1][Governor].level == LEVEL_UNIV);
    oi.Lastx = Dir[Playernum - 1][Governor].lastx[i];
    oi.Lasty = Dir[Playernum - 1][Governor].lasty[i];
    oi.Zoom = Dir[Playernum - 1][Governor].zoom[i];
  }
  else
  {
    where = Getplace(Playernum, Governor, args[argn - 1], 0);
    oi.Lastx = oi.Lasty = 0.0;
    oi.Zoom = 1.0;
  }

  if (where.err)
  {
    notify(Playernum, Governor, "orbit: error in args.\n");
    return;
  }

  /* Display CSP orbit instead, if the client can understand it */
  if (client_can_understand(Playernum, Governor, CSP_ORBIT_OUTPUT_INTRO))
  {
    csp_orbit(Playernum, Governor, &oi);
    return;
  }

  /* orbit type of map */
  notify(Playernum, Governor, "#");

  Race = races[Playernum - 1];

  switch (where.level)
  {
    case LEVEL_UNIV:
      for (i = 0; i < Sdata.numstars; i++)
      {
        if (oi.DontDispNum != i)
        {
          DispStar(Playernum, Governor, LEVEL_UNIV, Stars[i], (int)Race->God,
                   buf, &oi);
          notify(Playernum, Governor, buf);
        }
      }

      if (!oi.DontDispShips)
      {
        sh = Sdata.ships;

        while (sh)
        {
          (void)getship(&s, sh);

          if (oi.DontDispNum != sh)
          {
            DispShip(Playernum, Governor, &where, s, NULL, (int)Race->God, buf,
                     &oi);
            notify(Playernum, Governor, buf);
          }

          sh = nextship(s);
          free((char *)s);
        }
      }
      break;

    case LEVEL_STAR:
      DispStar(Playernum, Governor, LEVEL_STAR, Stars[where.snum],
               (int)Race->God, buf, &oi);
      notify(Playernum, Governor, buf);

      for (i = 0; i < Stars[where.snum]->numplanets; i++)
      {
        if (oi.DontDispNum != i)
        {
          getplanet(&p, (int)where.snum, i);
          DispPlanet(Playernum, Governor, LEVEL_STAR, p,
                     Stars[where.snum]->pnames[i], Race, buf, &oi);
          notify(Playernum, Governor, buf);
          free((char *)p);
        }
      }
      /* 
       * check to see if you have ships at orbiting the star, if so
       * you can see enemy ships
       */
      iq = 0;
      if (Race->God)
        iq = 1;
      else
      {
        sh = Stars[where.snum]->ships;
        while (sh && !iq)
        {
          (void)getship(&s, sh);

          if (s->owner == Playernum && Sight(s))
            iq = 1;             /* you are there to sight, need a crew */

          sh = nextship(s);
          free((char *)s);
        }
      }

      if (!oi.DontDispShips)
      {
        sh = Stars[where.snum]->ships;
        while (sh)
        {
          (void)getship(&s, sh);

          if (oi.DontDispNum != sh &&
              !(s->owner != Playernum && s->type == STYPE_MINEF))
          {
            if ((s->owner == Playernum) || (iq == 1))
            {
              DispShip(Playernum, Governor, &where, s, NULL, (int)Race->God,
                       buf, &oi);
              notify(Playernum, Governor, buf);
            }
          }

          sh = nextship(s);
          free((char *)s);
        }
      }
      break;

    case LEVEL_PLAN:
      getplanet(&p, (int)where.snum, (int)where.pnum);
      DispPlanet(Playernum, Governor, LEVEL_PLAN, p,
                 Stars[where.snum]->pnames[where.pnum], Race, buf, &oi);
      notify(Playernum, Governor, buf);

      /* 
       * check to see if you have ships at landed or orbiting the
       * planet, if so you can see orbiting enemy ships
       */
      iq = 0;
      sh = p->ships;
      while (sh && !iq)
      {
        (void)getship(&s, sh);
        if (s->owner == Playernum && Sight(s))
          iq = 1;               /* you are there to sight, need a crew */

        sh = nextship(s);
        free((char *)s);
      }

      /* end check */
      if (!oi.DontDispShips)
      {
        sh = p->ships;

        while (sh)
        {
          (void)getship(&s, sh);
          if (oi.DontDispNum != sh)
          {
            if (!landed(s))
            {
              if ((s->owner == Playernum) || (iq == 1))
              {
                DispShip(Playernum, Governor, &where, s, p, (int)Race->God, buf,
                         &oi);
                notify(Playernum, Governor, buf);
              }
            }
          }

          sh = nextship(s);
          free((char *)s);
        }
      }
      free((char *)p);
      break;
    default:
      notify(Playernum, Governor, "Bad scope.\n");
      return;
  }
  notify(Playernum, Governor, "\n");
}

void
DispStar(int Playernum, int Governor, int level, startype * star, int God,
         char *string, orbitinfo * oi)
{
  int             x = -1, y = -1;
  int             stand;

  *string = '\0';

  if (level == LEVEL_UNIV)
  {
    x =
      (int)(ORBIT_SCALE +
            ((ORBIT_SCALE * (star->xpos - oi->Lastx)) / (UNIVSIZE * oi->Zoom)));
    y =
      (int)(ORBIT_SCALE +
            ((ORBIT_SCALE * (star->ypos - oi->Lasty)) / (UNIVSIZE * oi->Zoom)));
  }
  else if (level == LEVEL_STAR)
  {
    x =
      (int)(ORBIT_SCALE +
            (ORBIT_SCALE * (-oi->Lastx)) / (SYSTEMSIZE * oi->Zoom));
    y =
      (int)(ORBIT_SCALE +
            (ORBIT_SCALE * (-oi->Lasty)) / (SYSTEMSIZE * oi->Zoom));
  }
  /* 
   * if (star->nova_stage) DispArray(x, y, 11,7,
   * Novae[star->nova_stage-1], fac);
   */
  if (y >= 0 && x >= 0)
  {
    if (Race->governor[Governor].toggle.color)
    {
      stand = (isset(star->explored, Playernum) ? Playernum : 0) + '?';
      sprintf(temp, "%c %d %d %d * ", (char)stand, x, y, star->nova_stage);
      strcat(string, temp);
      stand = (isset(star->inhabited, Playernum) ? Playernum : 0) + '?';
      sprintf(temp, "%c %s;", (char)stand, star->name);
      strcat(string, temp);
    }
    else if (Race->governor[Governor].toggle.inverse)
    {
      stand = (isset(star->explored, Playernum) ? 1 : 0);
      sprintf(temp, "%d %d %d %d * ", stand, x, y, star->nova_stage);
      strcat(string, temp);
      stand = (isset(star->inhabited, Playernum) ? 1 : 0);
      sprintf(temp, "%d %s;", stand, star->name);
      strcat(string, temp);
    }
    else
    {
      sprintf(temp, "0 %d %d %d * ", x, y, star->nova_stage);
      strcat(string, temp);
      sprintf(temp, "0 %s;", star->name);
      strcat(string, temp);
    }
  }
}

void
DispPlanet(int Playernum, int Governor, int level, planettype * p, char *name,
           racetype * r, char *string, orbitinfo * oi)
{
  int             x = -1, y = -1;
  int             stand;

  *string = '\0';

  if (level == LEVEL_STAR)
  {
    y =
      (int)(ORBIT_SCALE +
            (ORBIT_SCALE * (p->ypos - oi->Lasty)) / (SYSTEMSIZE * oi->Zoom));
    x =
      (int)(ORBIT_SCALE +
            (ORBIT_SCALE * (p->xpos - oi->Lastx)) / (SYSTEMSIZE * oi->Zoom));
  }
  else if (level == LEVEL_PLAN)
  {
    y =
      (int)(ORBIT_SCALE +
            (ORBIT_SCALE * (-oi->Lasty)) / (PLORBITSIZE * oi->Zoom));
    x =
      (int)(ORBIT_SCALE +
            (ORBIT_SCALE * (-oi->Lastx)) / (PLORBITSIZE * oi->Zoom));
  }
  if (x >= 0 && y >= 0)
  {
    if (r->governor[Governor].toggle.color)
    {
      stand = (p->info[Playernum - 1].explored ? Playernum : 0) + '?';
      sprintf(temp, "%c %d %d 0 %c ", (char)stand, x, y,
              ((stand > '?' || r->God) ? Psymbol[p->type] : '?'));
      strcat(string, temp);
      stand = (p->info[Playernum - 1].numsectsowned ? Playernum : 0) + '?';
      sprintf(temp, "%c %s", (char)stand, name);
      strcat(string, temp);
    }
    else if (r->governor[Governor].toggle.inverse)
    {
      stand = p->info[Playernum - 1].explored ? 1 : 0;
      sprintf(temp, "%d %d %d 0 %c ", stand, x, y,
              ((stand || r->God) ? Psymbol[p->type] : '?'));
      strcat(string, temp);
      stand = p->info[Playernum - 1].numsectsowned ? 1 : 0;
      sprintf(temp, "%d %s", stand, name);
      strcat(string, temp);
    }
    else
    {
      stand = p->info[Playernum - 1].explored ? 1 : 0;
      sprintf(temp, "0 %d %d 0 %c ", x, y,
              ((stand || r->God) ? Psymbol[p->type] : '?'));
      strcat(string, temp);
      sprintf(temp, "0 %s", name);
      strcat(string, temp);
    }

    if (r->governor[Governor].toggle.compat && p->info[Playernum - 1].explored)
    {
      sprintf(temp, "(%d)", (int)compatibility(p, r));
      strcat(string, temp);
    }
    strcat(string, ";");
  }
}

void
DispShip(int Playernum, int Governor, placetype * where, shiptype * ship,
         planettype * pl, int God, char *string, orbitinfo * oi)
{
  int             x, y, wm;
  int             stand;
  shiptype       *aship;
  planettype     *apl;
  double          xt, yt, slope;

  if (!ship->alive)
    return;

  *string = '\0';

  switch (where->level)
  {
    case LEVEL_PLAN:
      x =
        (int)(ORBIT_SCALE +
              (ORBIT_SCALE *
               (ship->xpos - (Stars[where->snum]->xpos + pl->xpos) -
                oi->Lastx)) / (PLORBITSIZE * oi->Zoom));
      y =
        (int)(ORBIT_SCALE +
              (ORBIT_SCALE *
               (ship->ypos - (Stars[where->snum]->ypos + pl->ypos) -
                oi->Lasty)) / (PLORBITSIZE * oi->Zoom));
      break;
    case LEVEL_STAR:
      x =
        (int)(ORBIT_SCALE +
              (ORBIT_SCALE *
               (ship->xpos - Stars[where->snum]->xpos -
                oi->Lastx)) / (SYSTEMSIZE * oi->Zoom));
      y =
        (int)(ORBIT_SCALE +
              (ORBIT_SCALE *
               (ship->ypos - Stars[where->snum]->ypos -
                oi->Lasty)) / (SYSTEMSIZE * oi->Zoom));
      break;
    case LEVEL_UNIV:
      x =
        (int)(ORBIT_SCALE +
              (ORBIT_SCALE * (ship->xpos - oi->Lastx)) / (UNIVSIZE * oi->Zoom));
      y =
        (int)(ORBIT_SCALE +
              (ORBIT_SCALE * (ship->ypos - oi->Lasty)) / (UNIVSIZE * oi->Zoom));
      break;
    default:
      notify(Playernum, Governor, "WHOA! error in DispShip.\n");
      return;
  }

  switch (ship->type)
  {
    case STYPE_MIRROR:
      if (ship->special.aimed_at.level == LEVEL_STAR)
      {
        xt = Stars[ship->special.aimed_at.snum]->xpos;
        yt = Stars[ship->special.aimed_at.snum]->ypos;
      }
      else if (ship->special.aimed_at.level == LEVEL_PLAN)
      {
        if (where->level == LEVEL_PLAN &&
            ship->special.aimed_at.pnum == where->pnum)
        {
          /* same planet */
          xt = Stars[ship->special.aimed_at.snum]->xpos + pl->xpos;
          yt = Stars[ship->special.aimed_at.snum]->ypos + pl->ypos;
        }
        else
        {
          /* different planet */
          getplanet(&apl, (int)where->snum, (int)where->pnum);
          xt = Stars[ship->special.aimed_at.snum]->xpos + apl->xpos;
          yt = Stars[ship->special.aimed_at.snum]->ypos + apl->ypos;
          free((char *)apl);
        }
      }
      else if (ship->special.aimed_at.level == LEVEL_SHIP)
      {
        if (getship(&aship, (int)ship->special.aimed_at.shipno))
        {
          xt = aship->xpos;
          yt = aship->ypos;
          free((char *)aship);
        }
        else
          xt = yt = 0.0;
      }
      else
        xt = yt = 0.0;

      wm = 0;

      if (xt == ship->xpos)
      {
        if (yt > ship->ypos)
          wm = 5;
        else
          wm = 1;
      }
      else
      {
        slope = (yt - ship->ypos) / (xt - ship->xpos);

        if (yt == ship->ypos)
        {
          if (xt > ship->xpos)
            wm = 3;
          else
            wm = 7;
        }
        else if (yt > ship->ypos)
        {
          if (slope < -2.414)
            wm = 5;
          if (slope > -2.414)
            wm = 6;
          if (slope > -0.414)
            wm = 7;
          if (slope > 0.000)
            wm = 3;
          if (slope > 0.414)
            wm = 4;
          if (slope > 2.414)
            wm = 5;
        }
        else if (yt < ship->ypos)
        {
          if (slope < -2.414)
            wm = 1;
          if (slope > -2.414)
            wm = 2;
          if (slope > -0.414)
            wm = 3;
          if (slope > 0.000)
            wm = 7;
          if (slope > 0.414)
            wm = 8;
          if (slope > 2.414)
            wm = 1;
        }
      }

      /* (magnification) */
      if (x >= 0 && y >= 0)
      {
        if (Race->governor[Governor].toggle.color)
        {
          sprintf(string, "%c %d %d %d %c %c %d;", (char)(ship->owner + '?'), x,
                  y, wm, Shipltrs[ship->type], (char)(ship->owner + '?'),
                  ship->number);
        }
        else
        {
          stand = (ship->owner == Race->governor[Governor].toggle.highlight);
          sprintf(string, "%d %d %d %d %c %d %d;", stand, x, y, wm,
                  Shipltrs[ship->type], stand, ship->number);
        }
      }
      break;

    case OTYPE_CANIST:
    case OTYPE_GREEN:
      break;

#ifdef USE_VN
    case OTYPE_VN:
    {
      register int    n, xa, ya;
      register float  fac;

      wm = 0;

      /* make a cloud of Von Neumann machines */
      if (ship->whatorbits != LEVEL_UNIV || (ship->owner == Playernum || God))
      {
        fac =
          ship->number /
          ((ship->whatorbits ==
            LEVEL_UNIV ? 100.0 : (ship->whatorbits ==
                                  LEVEL_STAR ? 30.0 : 4.0)) * oi->Zoom);

        for (n = 1; n <= ship->number && n < 267; n++)
        {
          xa = int_rand(x - (int)fac, x + (int)fac);
          ya = int_rand(y - (int)fac, y + (int)fac);

          if (xa >= 0 && ya >= 0)
          {
            if (Race->governor[Governor].toggle.color)
            {
              sprintf(temp, "%c %d %d %d %c %c %d;", (char)(ship->owner + 48),
                      xa, ya, wm, Shipltrs[ship->type],
                      (char)(ship->owner + 48), ship->number);
            }
            else
            {
              stand =
                (ship->owner == Race->governor[Governor].toggle.highlight);
              sprintf(temp, "%d %d %d %d %c %d %d;", stand, xa, ya, wm,
                      Shipltrs[ship->type], stand, ship->number);
            }

            strcat(string, temp);
          }
        }
      }
    }
      break;
#endif

    default:
      /* make sure ship is not cloaked if not ours */
      if (ship->owner != Playernum && ship->cloaked)
        return;

      /* other ships can only be seen when in system */
      wm = 0;
      if (ship->whatorbits != LEVEL_UNIV || ((ship->owner == Playernum) || God))
        if (x >= 0 && y >= 0)
        {
          if (Race->governor[Governor].toggle.color)
          {
            sprintf(string, "%c %d %d %d %c %c %d;", (char)(ship->owner + '?'),
                    x, y, wm, Shipltrs[ship->type], (char)(ship->owner + '?'),
                    ship->number);
          }
          else
          {
            stand = (ship->owner == Race->governor[Governor].toggle.highlight);
            sprintf(string, "%d %d %d %d %c %d %d;", stand, x, y, wm,
                    Shipltrs[ship->type], stand, ship->number);
          }
        }
      break;
  }
}
