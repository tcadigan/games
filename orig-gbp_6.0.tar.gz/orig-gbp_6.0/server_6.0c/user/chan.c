/*
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 ***********************************************
 * #ident  "@(#)chan.c	1.7 12/3/93 "
 * chan.c
 *
 * Created: Wed Jan 27 20:56:42 EST 1993
 * Author:  John Paul Deragon
 *
 * Version: 1.5 23:05:36
 *
 * Contains: 
 *          
 * $Header: /var/cvs/gbp/GB+/user/chan.c,v 1.4 2007/07/06 18:09:34 gbp Exp $
 ***********************************************/

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

#define EXTERN extern
#include "GB_copyright.h"
#include "vars.h"
#include "races.h"
#include "ships.h"
#include "buffers.h"
#include "power.h"
#include "config.h"
#include "proto.h"

EXTERN void     channel(int, int, int, int);

void
channel(int Playernum, int Governor, int AP, int startup)
{
  int             want;

  if (startup)
  {
    if (isclr
        (races[Playernum - 1]->governor[Governor].channel, COMM_RCV_CHANNEL1) &&
        isclr(races[Playernum - 1]->governor[Governor].channel,
              COMM_RCV_CHANNEL2) &&
        isclr(races[Playernum - 1]->governor[Governor].channel,
              COMM_RCV_CHANNEL3))
    {
      setbit(races[Playernum - 1]->governor[Governor].channel,
             COMM_RCV_CHANNEL1);
      setbit(races[Playernum - 1]->governor[Governor].channel,
             COMM_XMIT_CHANNEL1);
    }
    return;
  }

#ifndef MULTIPLE_COMM_CHANNELS
  notify(Playernum, Governor, "Command disabled.\n");
  return;
#endif

  if (argn >= 2)
  {
    if (argn == 2)
    {
      want = atoi(args[1]);

      if (want < 1 || want > 3)
      {
        notify(Playernum, Governor, "Invalid channel.\n");
        return;
      }

      if (isset(races[Playernum - 1]->governor[Governor].channel, want))
      {
        clrbit(races[Playernum - 1]->governor[Governor].channel, want);
        clrbit(races[Playernum - 1]->governor[Governor].channel,
               want + COMM_CHANNEL_MASK);
      }
      else
      {
        setbit(races[Playernum - 1]->governor[Governor].channel, want);
      }

      if (isset
          (races[Playernum - 1]->governor[Governor].channel,
           want + COMM_CHANNEL_MASK))
      {
        clrbit(races[Playernum - 1]->governor[Governor].channel,
               want + COMM_CHANNEL_MASK);
        setbit(races[Playernum - 1]->governor[Governor].channel,
               COMM_XMIT_CHANNEL1);
        notify(Playernum, Governor, "Setting xmit comm channel to 1\n");
      }
    }
    else if (argn == 3)
    {
      want = atoi(args[1]);

      if (want < 1 || want > 3)
      {
        notify(Playernum, Governor, "Invalid channel.\n");
        return;
      }

      if (match(args[2], "xmit"))
      {
        clrbit(races[Playernum - 1]->governor[Governor].channel,
               COMM_XMIT_CHANNEL1);
        clrbit(races[Playernum - 1]->governor[Governor].channel,
               COMM_XMIT_CHANNEL2);
        clrbit(races[Playernum - 1]->governor[Governor].channel,
               COMM_XMIT_CHANNEL3);

        if (isclr(races[Playernum - 1]->governor[Governor].channel, want))
        {
          setbit(races[Playernum - 1]->governor[Governor].channel, want);
          setbit(races[Playernum - 1]->governor[Governor].channel,
                 want + COMM_CHANNEL_MASK);
        }
        else
        {
          setbit(races[Playernum - 1]->governor[Governor].channel,
                 want + COMM_CHANNEL_MASK);
        }
      }
    }
    else
    {
      notify(Playernum, Governor, "Syntax: channel <channel> xmit\n");
      return;
    }
  }

  /* Make sure we have a xmit channel set */
  if (isclr
      (races[Playernum - 1]->governor[Governor].channel, COMM_XMIT_CHANNEL1) &&
      isclr(races[Playernum - 1]->governor[Governor].channel,
            COMM_XMIT_CHANNEL2) &&
      isclr(races[Playernum - 1]->governor[Governor].channel,
            COMM_XMIT_CHANNEL3))
  {
    /* No xmit channel set, pick one */
    if (isset
        (races[Playernum - 1]->governor[Governor].channel, COMM_RCV_CHANNEL1))
    {
      setbit(races[Playernum - 1]->governor[Governor].channel,
             COMM_XMIT_CHANNEL1);
      notify(Playernum, Governor, "Xmit channel set to 1.\n");
    }
    else
      if (isset
          (races[Playernum - 1]->governor[Governor].channel, COMM_RCV_CHANNEL2))
    {
      setbit(races[Playernum - 1]->governor[Governor].channel,
             COMM_XMIT_CHANNEL2);
      notify(Playernum, Governor, "Xmit channel set to 2.\n");
    }
    else
      if (isset
          (races[Playernum - 1]->governor[Governor].channel, COMM_RCV_CHANNEL3))
    {
      setbit(races[Playernum - 1]->governor[Governor].channel,
             COMM_XMIT_CHANNEL3);
      notify(Playernum, Governor, "Xmit channel set to 3.\n");
    }
  }

  notify(Playernum, Governor, "Channel Status:\n");
  sprintf(buf, "    One: %s %s\n",
          (isset
           (races[Playernum - 1]->governor[Governor].channel,
            COMM_RCV_CHANNEL1) ? "RCV" : "OFF"),
          (isset
           (races[Playernum - 1]->governor[Governor].channel,
            COMM_XMIT_CHANNEL1) ? "XMIT" : "   "));
  notify(Playernum, Governor, buf);
  sprintf(buf, "    Two: %s %s\n",
          (isset
           (races[Playernum - 1]->governor[Governor].channel,
            COMM_RCV_CHANNEL2) ? "RCV" : "OFF"),
          (isset
           (races[Playernum - 1]->governor[Governor].channel,
            COMM_XMIT_CHANNEL2) ? "XMIT" : "   "));
  notify(Playernum, Governor, buf);
  sprintf(buf, "  Three: %s %s\n",
          (isset
           (races[Playernum - 1]->governor[Governor].channel,
            COMM_RCV_CHANNEL3) ? "RCV" : "OFF"),
          (isset
           (races[Playernum - 1]->governor[Governor].channel,
            COMM_XMIT_CHANNEL3) ? "XMIT" : "   "));
  notify(Playernum, Governor, buf);
}
