/*
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 ***********************************************
 * #ident  "@(#)toxi.c	1.8 12/3/93 "
 * toxi.c
 *
 * Created:
 * Author:  Robert Chansky
 *
 * Version: 1.6 17:35:18
 *
 * Contains:
 *  toxicity()
 *
 * $Header: /var/cvs/gbp/GB+/user/toxi.c,v 1.4 2007/07/06 18:09:34 gbp Exp $
 *
 ********************************************/

#include <stdlib.h>
#include <math.h>
#include <ctype.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"
#include "proto.h"

/* 
 * clearlog:
 * 
 * arguments: Playernum Governor APcount
 * 
 * called by: process_commands
 * 
 * description:  Called from process_commands.  This sets the toxicity value on
 * the planet to automatically launch twc when reached.
 * 
 */

void
toxicity(int Playernum, int Governor, int APcount)
{
  int             thresh;
  planettype     *p;

  sscanf(args[1], "%d", &thresh);

  if (thresh > 100 || thresh < 0)
  {
    sprintf(buf, "Illegal value.\n");
    notify(Playernum, Governor, buf);
    return;
  }
  if (Dir[Playernum - 1][Governor].level != LEVEL_PLAN)
  {
    sprintf(buf, "scope must be a planet.\n");
    notify(Playernum, Governor, buf);
    return;
  }

  if (!enufAP
      (Playernum, Governor,
       Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1], APcount))
    return;

  getplanet(&p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);

  /* set the tox value for the planet */
  p->info[Playernum - 1].tox_thresh = thresh;

  putplanet(p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);

  deductAPs(Playernum, Governor, APcount, Dir[Playernum - 1][Governor].snum, 0);

  sprintf(buf, " New threshold is: %u\n", p->info[Playernum - 1].tox_thresh);
  notify(Playernum, Governor, buf);

  free((char *)p);
}
