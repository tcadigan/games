/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 ***********************************************
 * 
 * #ident  "@(#)bug.c  1.0 7/5/01 "
 * 
 * Galactic Bloodshed Bug Reporting System
 *
 * Author: Michael F. Wilkinson (mfw)
 *
 * Contains:
 *   bug() called from GB_server.c
 *   ancillary functions
 *
 * These functions write to and display the
 * bugrep.txt file. This file replaces the
 * original system, this is designed to be more
 * helpful for both user and admin.
 *
 ***********************************************/

#include <stdio.h>
#include <string.h>
/* #include <strings.h> */
#include <stdlib.h>
#include <time.h>

#define EXTERN extern
#include "GB_copyright.h"
#include "vars.h"
#include "files.h"
#include "races.h"
#include "buffers.h"
#include "power.h"
#include "ships.h"
#include "config.h"
#include "game_info.h"

#include "proto.h"

void
bug(int Playernum, int Governor, int APcount)
{
  FILE           *fp;
  time_t          t;
  struct tm      *st;
  int             i;

  t = time(NULL);
  st = localtime(&t);

  if (argn < 2)
  {
    notify(Playernum, Governor, "No bug to report?\n");
    return;
  }

  if (argn == 2 && match(args[1], "report"))
  {
    read_bug_report(Playernum, Governor);
    return;
  }

  sprintf(buf, "%s", args[1]);

  for (i = 2; i < argn; i++)
  {
    sprintf(temp, " %s", args[i]);
    strcat(buf, temp);
  }

  sprintf(long_buf,
          "{{Bugid}}: ?? Status: REPORTED\n%.2d/%.2d/%.2d %.2d:%.2d:%.2d Reported by: %s, %s [%d,%d]\nDesc: %s\nNarr:\n--\n\n",
          st->tm_mon + 1, st->tm_mday,
          (st->tm_year > 99) ? (st->tm_year - 100) : (st->tm_year), st->tm_hour,
          st->tm_min, st->tm_sec, races[Playernum - 1]->name,
          races[Playernum - 1]->governor[Governor].name, Playernum, Governor,
          buf);

  sprintf(telegram_buf, "+++ BUG REPORT FILED +++ %s", buf);

  if ((fp = fopen(BUGREP, "a+")) != 0)
  {
    fprintf(fp, long_buf);
    fclose(fp);

    send_race_dispatch(Playernum, Governor, 1, TO_RACE, 1, telegram_buf);

    if (send_bug_email(long_buf))
      notify(Playernum, Governor, "Bug reported, thank you.\n");
    else
      notify(Playernum, Governor, "Bug reported, but email NOT sent.\n");
  }
  else
  {
    notify(Playernum, Governor, "Bug NOT reported, can't open bug db.\n");
  }
}

int
send_bug_email(char *report)
{
  char            repfile[80];
  FILE           *fp;

  strcpy(repfile, "/tmp/gbbugrep");

  if ((fp = fopen(repfile, "w")) != 0)
  {
    fprintf(fp, "%s", report);
    fclose(fp);

    sprintf(temp, "cat %s | %s -s \"GB Bug Report\" %s; rm %s", repfile,
            MAILPROG, GODADDR, repfile);

    if (!system(temp))
      return 1;
    else
      return 0;
  }
  else
  {
    return 0;
  }
}

void
read_bug_report(int Playernum, int Governor)
{

  FILE           *f;

  if ((f = fopen(BUGREP, "r")) != 0)
  {
    while (fgets(buf, sizeof buf, f))
    {
      /* strcat(buf, "\n"); */
      notify(Playernum, Governor, buf);
    }

    fclose(f);

    notify(Playernum, Governor, "----\nEnd.\n");
  }
  else
  {
    notify(Playernum, Governor, "Unable to open bug report file.\n");
  }
}
