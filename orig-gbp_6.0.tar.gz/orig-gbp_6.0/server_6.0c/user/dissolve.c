/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)dissolve.c      1.8 12/3/93 "
 *
 * dissolve.c -- commit suicide, nuke all ships and sectors;
 * July 24th, 1989, John Deragon, deragon@jethro.nyu.edu
 *
 * $Header: /var/cvs/gbp/GB+/user/dissolve.c,v 1.4 2007/07/06 18:09:34 gbp Exp $
 */

#include <stdlib.h>
#include <math.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "doturn.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"
#include "config.h"
#include "proto.h"

void
dissolve(int Playernum, int Governor)
{
  int             n_ships, i, j, z, x2, y2, hix, hiy, lowx, lowy;
  unsigned char   waste;
  char            nuke, racepass[100], govpass[100];
  shiptype       *sp;
  racetype       *Race;
  planettype     *pl;
  sectortype     *s;

#ifndef DISSOLVE
  notify(Playernum, Governor,
         "Dissolve has been disabled. Please notify diety.\n");
  return;
#endif

  n_ships = Numships();

  if (argn < 3)
  {
    sprintf(buf, "Self-Destruct sequence requires passwords.\n");
    notify(Playernum, Governor, buf);
    sprintf(buf,
            "Syntax: dissolve <race password> <leader password> <option> to initiate.\n");
    notify(Playernum, Governor, buf);
    return;
  }
  else
  {
    sprintf(buf, "WARNING!! WARNING!! WARNING!!\n");
    notify(Playernum, Governor, buf);
    sprintf(buf, "-------------------------------\n");
    notify(Playernum, Governor, buf);
    sprintf(buf, "Entering self destruct sequence!\n");
    notify(Playernum, Governor, buf);

    sscanf(args[1], "%s", racepass);
    sscanf(args[2], "%s", govpass);

    waste = 0;
    if (argn > 3)
    {
      sscanf(args[3], "%c", &nuke);
      if (nuke == 'w')
        waste = 1;
    }
#ifdef CHAP_AUTH
    Getracenum(racepass, govpass, &i, &j, govpass, waste);      /* need to fix
                                                                 * -mfw */
#else
    Getracenum(racepass, govpass, &i, &j);
#endif

    if (!i)
    {
      sprintf(buf, "Password mismatch, self-destruct not initiated!\n");
      notify(Playernum, Governor, buf);
      return;
    }
    for (i = 1; i <= n_ships; i++)
    {
      (void)getship(&sp, i);
      if (sp->owner == Playernum)
      {
        kill_ship(Playernum, sp);
        sprintf(buf, "-- Ship #%d, self-destruct enabled\n", i);
        notify(Playernum, Governor, buf);
        putship(sp);
      }
      free((char *)sp);
    }

    getsdata(&Sdata);
    for (z = 0; z < Sdata.numstars; z++)
    {
      getstar(&(Stars[z]), z);
      if (isset(Stars[z]->explored, Playernum))
      {
        for (i = 0; i < Stars[z]->numplanets; i++)
        {
          getplanet(&pl, z, i);

          if (pl->info[Playernum - 1].explored &&
              pl->info[Playernum - 1].numsectsowned)
          {
            pl->info[Playernum - 1].fuel = 0;
            pl->info[Playernum - 1].destruct = 0;
            pl->info[Playernum - 1].resource = 0;
            pl->info[Playernum - 1].popn = 0;
            pl->info[Playernum - 1].troops = 0;
            pl->info[Playernum - 1].tax = 0;
            pl->info[Playernum - 1].newtax = 0;
            pl->info[Playernum - 1].crystals = 0;
            pl->info[Playernum - 1].numsectsowned = 0;
            pl->info[Playernum - 1].explored = 0;
            pl->info[Playernum - 1].autorep = 0;
          }
          getsmap(Smap, pl);

          lowx = 0;
          lowy = 0;
          hix = pl->Maxx - 1;
          hiy = pl->Maxy - 1;
          for (y2 = lowy; y2 <= hiy; y2++)
          {
            for (x2 = lowx; x2 <= hix; x2++)
            {
              s = &Sector(*pl, x2, y2);
              if (s->owner == Playernum)
              {
                s->owner = 0;
                s->troops = 0;
                s->popn = 0;
                if (waste)
                  /* 
                   * code
                   * folded
                   * 
                   * from
                   * here
                   */
                  s->condition = WASTED;
                /* unfolding */
              }
            }
          }
          putsmap(Smap, pl);
          putstar(Stars[z], z);
          putplanet(pl, z, i);
          free((char *)pl);
        }
      }
    }

    Race = races[Playernum - 1];
    Race->dissolved = 1;
    putrace(Race);

    sprintf(buf, "%s [%d] has dissolved.\n", Race->name, Playernum);
    post(buf, DECLARATION);

  }
}

int
revolt(planettype * pl, int victim, int agent)
{
  int             x, y, hix, hiy, lowx, lowy, changed_hands = 0;
  racetype       *Race, *Race2;
  sectortype     *s;

  Race = races[victim - 1];
  Race2 = races[agent - 1];

  getsmap(Smap, pl);
  /* do the revolt */
  lowx = 0;
  lowy = 0;
  hix = pl->Maxx - 1;
  hiy = pl->Maxy - 1;
  for (y = lowy; y <= hiy; y++)
  {
    for (x = lowx; x <= hix; x++)
    {
      s = &Sector(*pl, x, y);
      if (s->owner == victim && s->popn)
      {
        /* HUT Gardan 13.2.1997 added sector pref to chance to convert sector
         * chance is pref/2 removed tax factor */
        if (int_rand(1, 200) < (100 * Race2->likes[s->type]))
        {
          if (int_rand(1, (int)s->popn) > 10 * Race->fighters * s->troops)
          {
            s->owner = agent;   /* enemy gets it */
            s->popn = int_rand(1, (int)s->popn);        /* some people killed */
            s->troops = 0;      /* all troops destroyed */
            pl->info[victim - 1].numsectsowned -= 1;
            pl->info[agent - 1].numsectsowned += 1;
            pl->info[victim - 1].mob_points -= s->mobilization;
            pl->info[agent - 1].mob_points += s->mobilization;
            changed_hands++;
          }
        }
      }
    }
  }
  putsmap(Smap, pl);

  return changed_hands;
}
