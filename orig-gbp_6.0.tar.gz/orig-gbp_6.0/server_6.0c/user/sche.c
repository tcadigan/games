/*
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 ***********************************************
 * #ident  "@(#)sche.c	1.13 12/3/93 "
 * sched.c
 *
 * Created: Fri Dec 11 03:50:49 EST 1992
 * Author:  ???
 *
 * Version: 1.8 17:35:15
 *
 * Contains:
 *   GB_schedule()
 *
 *
 * $Header: /var/cvs/gbp/GB+/user/sche.c,v 1.3 2007/07/06 18:09:34 gbp Exp $
 *
 ***********************************************/

#include <ctype.h>
#include <time.h>
#include <string.h>
/* #include <strings.h> */
#include <sys/stat.h>

/* 
 * Prototypes
 */
void            timedifftoascii(long, long, char *);

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"

#include "proto.h"

/* 
 * GB_schedule:
 * 
 * arguments: Playernum Playernum who called it Governor Governor who called it
 * 
 * Called by: process_command
 * 
 */

void
GB_schedule(int Playernum, int Governor)
{
  char           *ctp, *nlp;
  time_t          clk;
  char            tbuf[BUFSIZ];
  char            fbuf[BUFSIZ];
  struct stat     stbuf;
  racetype       *r;

  r = races[Playernum - 1];

  if (suspended || stat(NOGOFL, &stbuf) >= 0)
  {
    sprintf(buf, "Updates and segments currently suspended\n");
    notify(Playernum, Governor, buf);
    return;
  }

  clk = time(0);

  sprintf(buf, "%d minute update intervals\n", update_time);
  notify(Playernum, Governor, buf);
  sprintf(buf, "%ld movement segments per update\n", segments);
  notify(Playernum, Governor, buf);

  sprintf(buf, "Combat update is: %d\n", CombatUpdate);
  notify(Playernum, Governor, buf);

  if (r->governor[Governor].CSP_client_info.csp_user == 1)
  {
    sprintf(tbuf, "%ld", clk);
    sprintf(buf, "Current time    : %s%-10s%s\n", OPEN_TIME_TAG, tbuf,
            CLOSE_TIME_TAG);
    notify(Playernum, Governor, buf);

    sprintf(fbuf, "%ld", next_backup_time);
    timedifftoascii(next_backup_time, clk, tbuf);
    sprintf(buf, "Next Backup %3s : %s%-10s%s (%s)\n", " ", OPEN_TIME_TAG, fbuf,
            CLOSE_TIME_TAG, tbuf);
    notify(Playernum, Governor, buf);

    sprintf(fbuf, "%ld", next_segment_time);
    timedifftoascii(next_segment_time, clk, tbuf);
    sprintf(buf, "Next Segment %2d : %s%-10s%s (%s)\n",
            nsegments_done == segments ? 1 : nsegments_done + 1, OPEN_TIME_TAG,
            fbuf, CLOSE_TIME_TAG, tbuf);
    notify(Playernum, Governor, buf);

    sprintf(fbuf, "%ld", next_update_time);
    timedifftoascii(next_update_time, clk, tbuf);
    sprintf(buf, "Next Update %3d : %s%-10s%s (%s)\n", nupdates_done + 1,
            OPEN_TIME_TAG, fbuf, CLOSE_TIME_TAG, tbuf);
    notify(Playernum, Governor, buf);

    if (next_shutdown_time)
    {
      sprintf(fbuf, "%ld", next_shutdown_time);
      timedifftoascii(next_shutdown_time, clk, tbuf);
      sprintf(buf, "SHUTDOWN AT     : %s%-10s%s (%s)\n", OPEN_TIME_TAG, fbuf,
              CLOSE_TIME_TAG, tbuf);
      notify(Playernum, Governor, buf);
    }
  }
  else
  {
    sprintf(buf, "Current time    : %s", ctime(&clk));
    notify(Playernum, Governor, buf);

    timedifftoascii(next_backup_time, clk, tbuf);
    ctp = ctime(&next_backup_time);
    while ((nlp = index(ctp, '\n')))
      *nlp = '\0';
    sprintf(buf, "Next Backup %3s : %s (%s)\n", " ", ctp, tbuf);
    notify(Playernum, Governor, buf);

    timedifftoascii(next_segment_time, clk, tbuf);
    ctp = ctime(&next_segment_time);
    while ((nlp = index(ctp, '\n')))
      *nlp = '\0';
    sprintf(buf, "Next Segment %2d : %s (%s)\n",
            nsegments_done == segments ? 1 : nsegments_done + 1, ctp, tbuf);
    notify(Playernum, Governor, buf);

    timedifftoascii(next_update_time, clk, tbuf);
    ctp = ctime(&next_update_time);
    while ((nlp = index(ctp, '\n')))
      *nlp = '\0';
    sprintf(buf, "Next Update %3d : %s (%s)\n", nupdates_done + 1, ctp, tbuf);
    notify(Playernum, Governor, buf);
  }
}

void
timedifftoascii(long t1, long t2, char *tbuf)
{
  long            x, tdiff;
  char            tbuf2[BUFSIZ];

  tbuf[0] = '\0';
  tdiff = t1 - t2;

  /* days */
  x = tdiff / (24 * 60 * 60);
  if (x)
  {
    sprintf(tbuf2, "%ld day%s", x, x > 1 ? "s" : "");
    strcat(tbuf, tbuf2);
  }
  tdiff -= (x * 24 * 60 * 60);

  /* hours */
  x = tdiff / (60 * 60);
  if (x)
  {
    sprintf(tbuf2, "%ld hour%s", x, x > 1 ? "s" : "");
    if (*tbuf)
      strcat(tbuf, ", ");
    strcat(tbuf, tbuf2);
  }
  tdiff -= (x * 60 * 60);

  /* minutes */
  x = tdiff / 60;
  if (x)
  {
    sprintf(tbuf2, "%ld min%s", x, x > 1 ? "s" : "");
    if (*tbuf)
      strcat(tbuf, ", ");
    strcat(tbuf, tbuf2);
  }
  tdiff -= (x * 60);

  /* seconds */
  x = tdiff;
  if (x)
  {
    sprintf(tbuf2, "%ld sec%s", x, x > 1 ? "s" : "");
    if (*tbuf)
      strcat(tbuf, ", ");
    strcat(tbuf, tbuf2);
  }
}
