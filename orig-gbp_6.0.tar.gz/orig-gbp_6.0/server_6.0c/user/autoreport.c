/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)autoreport.c    1.8 12/3/93 "
 *
 * autoreport.c -- tell server to generate a report for each planet
 *
 * $Header: /var/cvs/gbp/GB+/user/autoreport.c,v 1.3 2007/07/06 18:09:34 gbp Exp $
 */

#include <stdlib.h>             /* adder for free() (kse) */

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"
#include "ranks.h"

#include "proto.h"

void
autoreport(int Playernum, int Governor, int APcount)
{
  planettype     *p;
  placetype       place;
  int             snum, pnum;

  snum = Dir[Playernum - 1][Governor].snum;
  pnum = Dir[Playernum - 1][Governor].pnum;

  if (argn == 1)
  {                             /* no args */
    if (Dir[Playernum - 1][Governor].level == LEVEL_PLAN)
    {
      getplanet(&p, snum, pnum);
      if (p->info[Playernum - 1].autorep)
        p->info[Playernum - 1].autorep = 0;
      else
        p->info[Playernum - 1].autorep = TELEG_MAX_AUTO;
      putplanet(p, snum, pnum);

      sprintf(buf, "Autoreport on %s has been %s.\n", Stars[snum]->pnames[pnum],
              p->info[Playernum - 1].autorep ? "set" : "unset");
      notify(Playernum, Governor, buf);
      free((char *)p);
    }
    else
    {
      sprintf(buf, "Scope must be a planet.\n");
      notify(Playernum, Governor, buf);
    }
  }
  else if (argn > 1)
  {                             /* argn==2, place specified */
    place = Getplace(Playernum, Governor, args[1], 0);
    if (place.level == LEVEL_PLAN)
    {
      getplanet(&p, snum, pnum);
      sprintf(buf, "Autoreport on %s has been %s.\n", Stars[snum]->pnames[pnum],
              p->info[Playernum - 1].autorep ? "set" : "unset");
      notify(Playernum, Governor, buf);
      p->info[Playernum - 1].autorep = !p->info[Playernum - 1].autorep;
      putplanet(p, snum, pnum);
      free((char *)p);
    }
    else
    {
      sprintf(buf, "Scope must be a planet.\n");
      notify(Playernum, Governor, buf);
    }
  }
}
