/*
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 ***********************************************
 * #ident  "@(#)togg.c	1.8 12/3/93 "
 * togg.c
 *
 * Created: ???
 * Author:  Robert Chansky
 *
 * Version: 1.6 23:05:33
 *
 * Contains: toggle()
 *           highlight()
 *           tog()
 *
 * $Header: /var/cvs/gbp/GB+/user/togg.c,v 1.3 2007/07/06 18:09:34 gbp Exp $
 *
 ***********************************************/

#include <string.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "power.h"
#include "buffers.h"

/* 
 * Prototypes
 */
void            tog(int, int, char *, const char *);

#include "proto.h"

/* 
 * toggle:
 * 
 * arguments: Playernum Governor
 * 
 * called by: process_commands
 * 
 * description:  Called from process_commands, allows you to toggle some
 * options. Currently inverse, double_digits, gag, autoload, autopurge,
 * color, and monitor
 * 
 */

void
toggle(int Playernum, int Governor, int APcount)
{
  racetype       *Race;

  Race = races[Playernum - 1];

  if (argn > 1)
  {
    if (match(args[1], "inverse"))
      tog(Playernum, Governor, &Race->governor[Governor].toggle.inverse,
          "inverse");
    else if (match(args[1], "double_digits"))
      tog(Playernum, Governor, &Race->governor[Governor].toggle.double_digits,
          "double_digits");
    else if (match(args[1], "geography"))
      tog(Playernum, Governor, &Race->governor[Governor].toggle.geography,
          "geography");
    else if (match(args[1], "gag"))
      tog(Playernum, Governor, &Race->governor[Governor].toggle.gag, "gag");
    else if (match(args[1], "autoload"))
      tog(Playernum, Governor, &Race->governor[Governor].toggle.autoload,
          "autoload");
    // else if (match(args[1], "autopurge"))
    // tog(Playernum, Governor,
    // &Race->governor[Governor].toggle.autopurge, "autopurge");
    else if (match(args[1], "color"))
      tog(Playernum, Governor, &Race->governor[Governor].toggle.color, "color");
    else if (match(args[1], "visible"))
      tog(Playernum, Governor, &Race->governor[Governor].toggle.invisible,
          "invisible");
    else if (Race->God && match(args[1], "monitor"))
      tog(Playernum, Governor, &Race->monitor, "monitor");
    else if (match(args[1], "compatibility"))
      tog(Playernum, Governor, &Race->governor[Governor].toggle.compat,
          "compatibility");
    else if (match(args[1], "client"))
    {
      CSP_client_toggle(Playernum, Governor, 0);
      notify(Playernum, Governor, "client toggled\n");
    }
    else
    {
      sprintf(buf, "No such option '%s'\n", args[1]);
      notify(Playernum, Governor, buf);
      return;
    }
    putrace(Race);
  }
  else
  {
    sprintf(buf, "gag is %s\n",
            Race->governor[Governor].toggle.gag ? "ON" : "OFF");
    notify(Playernum, Governor, buf);

    sprintf(buf, "inverse is %s\n",
            Race->governor[Governor].toggle.inverse ? "ON" : "OFF");
    notify(Playernum, Governor, buf);

    sprintf(buf, "double_digits is %s\n",
            Race->governor[Governor].toggle.double_digits ? "ON" : "OFF");
    notify(Playernum, Governor, buf);

    sprintf(buf, "geography is %s\n",
            Race->governor[Governor].toggle.geography ? "ON" : "OFF");
    notify(Playernum, Governor, buf);

    sprintf(buf, "autoload is %s\n",
            Race->governor[Governor].toggle.autoload ? "ON" : "OFF");
    notify(Playernum, Governor, buf);

    // sprintf(buf, "autopurge is %s\n",
    // Race->governor[Governor].toggle.autopurge ? "ON" : "OFF");
    // notify(Playernum, Governor, buf);

    sprintf(buf, "color is %s\n",
            Race->governor[Governor].toggle.color ? "ON" : "OFF");
    notify(Playernum, Governor, buf);

    sprintf(buf, "compatibility is %s\n",
            Race->governor[Governor].toggle.compat ? "ON" : "OFF");
    notify(Playernum, Governor, buf);

    sprintf(buf, "%s\n",
            Race->governor[Governor].toggle.
            invisible ? "INVISIBLE" : "VISIBLE");
    notify(Playernum, Governor, buf);

    sprintf(buf, "highlight player %d\n",
            Race->governor[Governor].toggle.highlight);
    notify(Playernum, Governor, buf);

    sprintf(buf, "client mode is %s\n",
            Race->governor[Governor].CSP_client_info.csp_user ? "ON" : "OFF");
    notify(Playernum, Governor, buf);

    if (Race->God)
    {
      sprintf(buf, "monitor is %s\n", Race->monitor ? "ON" : "OFF");
      notify(Playernum, Governor, buf);
    }
  }
}

/* 
 * hightlight:
 * 
 * arguments: Playernum Governor
 * 
 * description:  Called process commands.
 * 
 */

void
highlight(int Playernum, int Governor)
{
  int             n;
  racetype       *Race;

  if (!(n = GetPlayer(args[1])))
  {
    sprintf(buf, "No such player.\n");
    notify(Playernum, Governor, buf);
    return;
  }
  Race = races[Playernum - 1];
  Race->governor[Governor].toggle.highlight = n;
  putrace(Race);
}

/* 
 * tog:
 * 
 * arguments: Playernum Governor op  - what we are toggling name
 * 
 * called by: toggle (local to this file)
 * 
 * description: This function does the acutal toggle of the bits
 * 
 */

void
tog(int Playernum, int Governor, char *op, const char *name)
{
  *op = !(*op);
  sprintf(buf, "%s is now %s\n", name, *op ? "on" : "off");
  notify(Playernum, Governor, buf);
}
