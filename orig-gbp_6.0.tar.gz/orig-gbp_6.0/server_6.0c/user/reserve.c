/* 
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * #ident  "@(#)reserve.c       1.14 11/5/93 "
 *
 * Author: Tim Brown smq@ucscb.ucsc.edu
 *
 * reserve() - set aside fuel and resources
 */

#include <math.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "races.h"
#include "doturn.h"
#include "power.h"
#include "buffers.h"
#include "tweakables.h"
#include "proto.h"

void
reserve(int Playernum, int Governor, int APcost)
{
  placetype       where;
  planettype     *p;

  /* check scope */
  where.level = Dir[Playernum - 1][Governor].level;
  if (where.level != LEVEL_PLAN)
  {
    sprintf(buf, "Change scope to a planet\n");
    notify(Playernum, Governor, buf);
    return;
  }

  where.snum = Dir[Playernum - 1][Governor].snum;
  where.pnum = Dir[Playernum - 1][Governor].pnum;

  getplanet(&p, (int)where.snum, (int)where.pnum);

  /* check args */
  if (argn < 3)
  {
    sprintf(buf, "Resource reserve set to: %d\n\
Fuel reserve set to: %d\n", p->info[Playernum - 1].res_reserve, p->info[Playernum - 1].fuel_reserve);

    notify(Playernum, Governor, buf);
    free((char *)p);
    return;
  }

  /* check for reasonable amount */
  if (atoi(args[1]) < 0)
  {
    sprintf(buf,
            "USAGE: reserve <amt> res/fuel\nPlease provide a numeric amount > 0\n");
    notify(Playernum, Governor, buf);
    free((char *)p);
    return;
  }

  if (match(args[2], "res"))
  {
    p->info[Playernum - 1].res_reserve = atoi(args[1]);
  }
  else if (match(args[2], "fuel"))
  {
    p->info[Playernum - 1].fuel_reserve = atoi(args[1]);
  }
  else
  {
    sprintf(buf,
            "USAGE: reserve <amt> res/fuel\nYou must designate \"res\" or \"fuel\"\n");
    notify(Playernum, Governor, buf);
  }

  sprintf(buf, "Resource reserve set to: %d\n\
Fuel reserve set to: %d\n", p->info[Playernum - 1].res_reserve, p->info[Playernum - 1].fuel_reserve);
  notify(Playernum, Governor, buf);

  putplanet(p, where.snum, where.pnum);
  free((char *)p);

}
