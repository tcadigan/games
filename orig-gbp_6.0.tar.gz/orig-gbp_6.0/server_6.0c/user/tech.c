/*
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 ***********************************************
 * 
 * #ident  "@(#)tech.c	1.9 12/3/93 "
 *
 * tech.c
 *
 * Created: ??
 * Author:  ??
 *
 * Version: @(#)tech.c	1.7 2/22/93
 *
 * $Header: /var/cvs/gbp/GB+/user/tech.c,v 1.4 2007/07/06 18:09:34 gbp Exp $
 *
 ***********************************************/

#include <stdlib.h>
#include <string.h>
/* #include <strings.h> */
#include <math.h>
#include <ctype.h>

#include "GB_copyright.h"
#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "power.h"
#include "races.h"
#include "buffers.h"
#include "ranks.h"

/* 
 * Prototypes
 */
double          tech_prod(int, int);

#include "proto.h"

void
technology(int Playernum, int Governor, int APcount)
{
  short           invest;
  planettype     *p;

  /* CWL */
  shiptype       *seti;
  int             sh, setihere;
  float           seticrew, setimaxcrew, setidamage;
  float           setimult;
  int             got;
  float           seti_fact = 0.0;
  float           nseti_fact = 0.0;

  /* end CWL */

  if (Dir[Playernum - 1][Governor].level != LEVEL_PLAN)
  {
    sprintf(buf, "scope must be a planet (%d).\n",
            Dir[Playernum - 1][Governor].level);
    notify(Playernum, Governor, buf);
    return;
  }
  if (!enufAP
      (Playernum, Governor,
       Stars[Dir[Playernum - 1][Governor].snum]->AP[Playernum - 1], APcount))
    return;

  getplanet(&p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);

  /* CWL code to support setis */
  sh = p->ships;
  setihere = setimaxcrew = seticrew = setidamage = 0;
  got = 1;
  while (sh && got)
  {
    if ((got = getship(&seti, sh)))
    {
      if (seti->type == OTYPE_SETI && seti->on && seti->alive &&
          seti->owner == Playernum)
      {
        setihere++;
        nseti_fact =
          (seti->on) ? ((float)seti->popn / (float)seti->max_crew) *
          ((float)(100 - seti->damage) / 100.0) : 0;
        seti_fact += nseti_fact;
      }

      sh = nextship(seti);
      free(seti);
    }
  }
  setimult = (1.0 + (log10(1.0 + seti_fact) / 5));
  /* end CWL */

  if (argn < 2)
  {

    float           tech_display;       /* CWL */

    tech_display =
      tech_prod((int)(p->info[Playernum - 1].tech_invest),
                (int)(p->info[Playernum - 1].popn));

    sprintf(buf,
            "Current investment : %d    Technology production/update: %.3f\n",
            p->info[Playernum - 1].tech_invest, tech_display);
    notify(Playernum, Governor, buf);

    /* CWL */
    if (setihere)
    {
      tech_display *= setimult;
      sprintf(buf, "Active science research centers: %d.\n", setihere);
      notify(Playernum, Governor, buf);
      sprintf(buf,
              "Scientific research center factor: %2.4f.\nTotal tech production: %2.4f.\n",
              setimult, tech_display);
      notify(Playernum, Governor, buf);
    }

    free((char *)p);
    return;
  }
  invest = atoi(args[1]);

  if (invest < 0)
  {
    sprintf(buf, "Illegal value.\n");
    notify(Playernum, Governor, buf);
    free((char *)p);
    return;
  }
  p->info[Playernum - 1].tech_invest = invest;

  putplanet(p, Dir[Playernum - 1][Governor].snum,
            Dir[Playernum - 1][Governor].pnum);

  deductAPs(Playernum, Governor, APcount, Dir[Playernum - 1][Governor].snum, 0);

  sprintf(buf, "   New (ideal) tech production: %.3f (this planet)\n",
          tech_prod((int)(p->info[Playernum - 1].tech_invest),
                    (int)(p->info[Playernum - 1].popn)));
  notify(Playernum, Governor, buf);

  free((char *)p);
}

void
techlevel(int Playernum, int Governor, int APcount)
{
  racetype       *r;

  r = races[Playernum - 1];

  sprintf(buf, "You have discovered the following technologies:");
  if (Hyper_drive(r))
    strcat(buf,
           "\n  Ability to install hyper drive engines on most ships (HYPERSPACE), ");
  if (Crystal(r))
    strcat(buf,
           "\n  Ability to identify crystal sectors and mine them.  Also can\nnow build things which require this, like laser and hyperdrive, ");
  if (Atmos(r))
    strcat(buf, "\n  Ability to use atmospheric processor features (ATMOS), ");
  if (Laser(r))
    strcat(buf, "\n  Ability to install laser weapons on ships (LASER), ");
  if (Wormhole(r))
    strcat(buf, "\n  Ability to identify Worm Holes (WORMHOLE), ");
#ifdef USE_VN
  if (Vn(r))
    strcat(buf, "\n  Von Neumann Machines (VN), ");
#endif
  if (Cew(r))
    strcat(buf, "\n  Confined Energy Weapons (CEW), ");
  if (Cloak(r))
    strcat(buf, "\n  Ability to cloak war ships (CLOAK), ");
  if (Avpm(r))
    strcat(buf, "\n  Ability to transport between star systems (AVPM), ");
  if (Tractor_beam(r))
    strcat(buf, "\n  TRACTOR_BEAM (not implemented), ");
  if (Transporter(r))
    strcat(buf, "\n  TRANSPORTER (not implemented), ");

  notify(Playernum, Governor, buf);

  sprintf(buf,
          "\n\nList of available technologies and level of tech needed:\n");
  notify(Playernum, Governor, buf);
  sprintf(buf, "HYPER_DRIVE    %f\n", TECH_HYPER_DRIVE);
  notify(Playernum, Governor, buf);
  sprintf(buf, "CRYSTAL        %f\n", TECH_CRYSTAL);
  notify(Playernum, Governor, buf);
  sprintf(buf, "ATMOS          %f\n", TECH_ATMOS);
  notify(Playernum, Governor, buf);
  sprintf(buf, "LASER          %f\n", TECH_LASER);
  notify(Playernum, Governor, buf);
  sprintf(buf, "WORMHOLE       %f\n", TECH_WORMHOLE);
  notify(Playernum, Governor, buf);
#ifdef USE_VN
  sprintf(buf, "VN_MACHINES    %f\n", TECH_VN);
  notify(Playernum, Governor, buf);
#endif
  sprintf(buf, "CEW            %f\n", TECH_CEW);
  notify(Playernum, Governor, buf);
  sprintf(buf, "CLOAK          %f\n", TECH_CLOAK);
  notify(Playernum, Governor, buf);
  sprintf(buf, "AVPM           %f\n", TECH_AVPM);
  notify(Playernum, Governor, buf);
  sprintf(buf, "TRACTOR_BEAM   %f\n", TECH_TRACTOR_BEAM);
  notify(Playernum, Governor, buf);
  sprintf(buf, "TRANSPORTER    %f\n", TECH_TRANSPORTER);
  notify(Playernum, Governor, buf);
}

double
tech_prod(int investment, int popn)
{
  double          scale;

  scale = (double)popn / 10000.;

  return (TECH_INVEST * log10((double)investment * scale + 1.0));
}
