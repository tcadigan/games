/*
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 ***********************************************
 * exrace.c
 *
 * By Michael Wilkinson (3/1/05). Based on John
 * Deragon's exship.c 
 *
 ***********************************************/

/* 
 * includes
 */
#include <strings.h>
#include <signal.h>
#include <sys/file.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

#define EXTERN extern
#include "vars.h"
#include "races.h"
#include "files.h"

#define DATAFILE DATA(race)

/* 
 * Prototypes
 */

void            check_size(void);
void            check_race(void);
void            display_race(void);
void            readrace(racetype **, int);

/* 
 * Global vars
 */

static int      race_fd;	/* the file descriptor of the datafile */
struct stat     buffer;		/* used for getting the size of the file */
int             num_races;	/* number of total ships in database */
racetype       *display;	/* this ship we are currently working on */
int             bad_race_count = 0;	/* the number of bad racess in the
					 * database */

/* 
 * main:
 * 
 * arguments: racenumber
 * 
 * description:  If invoked with zero arguments, it will open the race
 * datafile and count the number of races stored in the db. If invoked with
 * a ship number it will print out a very verbose listing of the requested
 * ship.
 * 
 */
int
main(int argc, char **argv)
{
  int             i;

  if ((race_fd = open(DATAFILE, 000, 0777)) < 0)
  {
    perror("main");
    printf("unable to open %s\n", DATAFILE);
    exit(-1);
  }

  check_size();

  if (argc == 1)
  {
    // check the whole database for errors
    for (i = 1; i <= num_races; i++)
    {
      readrace(&display, i);
      check_race();
      free(display);
    }

    printf("I found a total of %d corrupt races out of %d\n", bad_race_count,
	   num_races);
  }
  else
  {
    // we want a specific ship display
    readrace(&display, atoi(argv[1]));
    display_race();
  }

  printf("All Done \n");

  return 0;
}

/* 
 * readrace:
 * 
 * arguments: racetype structure, racenumber
 * 
 * called by:
 * 
 * description:  This funtion reads the actual data from the file.
 * 
 */
void
readrace(racetype ** s, int racenum)
{
  int             n;

  if (racenum <= 0)
    exit(1);

  if ((*s = (racetype *) malloc(sizeof (racetype))) == 0)
  {
    printf("getrace:Malloc() error\n");
    exit(0);
  }

  if (lseek(race_fd, (racenum - 1) * sizeof (racetype), L_SET) < 0)
  {
    perror("lseek");
    exit(1);
  }

  if ((n = read(race_fd, (char *)*s, sizeof (racetype))) != sizeof (racetype))
    perror("read");
}

/* 
 * check_size:
 * 
 * arguments: none
 * 
 * called by: main
 * 
 * description:  gets the number of races in the current database
 * 
 */
void
check_size(void)
{
  fstat(race_fd, &buffer);
  num_races = buffer.st_size / sizeof (racetype);
  printf("Number of races in database is %d\n", num_races);
}

/* 
 * check_race:
 * 
 * arguments: none
 * 
 * called by: main
 * 
 * description: does nothing right now
 */
void
check_race(void)
{

}

/* 
 * display_race:
 * 
 * arguments: none
 * 
 * called by: main
 * 
 * description:  Prints info on a specific race.
 * 
 */
void
display_race(void)
{
  int             i;

  printf("Race Number: %d\tRace Name: %s\tRace Password: %s\n",
	 display->Playernum, display->name, display->password);

  if (display->God)
    printf("Race has GOD permissions.\n");

  if (display->Guest)
    printf("Race has GUEST permissions.\n");

  if (display->Metamorph)
    printf("Race is a Metamorph.\n");

  if (display->dissolved)
    printf("Race has DISSOLVED.\n");

  printf("Gov ship: %d\n\n", display->Gov_ship);

  for (i = 0; i < 6; i++)
  {
    if (display->governor[i].active)
      printf("Gov Number: %d\tGov Name: %s\tGov Password: %s\tRank: %d\n", i,
	     display->governor[i].name, display->governor[i].password,
	     display->governor[i].rank);
  }
}
