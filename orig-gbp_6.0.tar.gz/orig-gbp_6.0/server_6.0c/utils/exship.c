/*
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 ***********************************************
 * #ident  "@(#)exship.c  1.4 3/21/93 "
 * exship.c
 *
 * Created: Fri Jan  1 19:34:23 EST 1993
 * Author:  J. Deragon (deragon@jethro.nyu.edu)
 *
 * Version: 1.4 14:23:29
 *
 ***********************************************/

/* 
 * includes
 */
#include <strings.h>
#include <signal.h>
#include <sys/file.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

#define EXTERN extern
#include "vars.h"
#include "ships.h"
#include "shipdata.h"
#include "files.h"

#define DATAFILE DATA(ship)

/* 
 * Prototypes
 */

void            check_ship(int);
void            check_size(void);
void            display_ship(void);
void            summarize_ship(void);

#ifdef __STDC__
void            readship(shiptype **, int);
#else
void            main();
void            readship();
#endif

/* 
 * Global vars
 */

static int      ship_fd;	/* the file descriptor of the datafile */
struct stat     buffer;		/* used for getting the size of the file */
int             num_ships;	/* number of total ships in database */
int             bad_ship_count = 0;	/* the number of bad ships in the *
					 * database */
shiptype       *display;	/* this ship we are currently working on */

/* 
 * main:
 * 
 * arguments: shipnumber
 * 
 * called by:
 * 
 * description:  If invoked with zero arguments, it will open the ship datafile
 * and go through looking for obvious errors. If invoked with a ship number
 * it will print out a very verbose listing of the requested ship.
 * 
 */
int
main(int argc, char **argv)
{
  int             i;

  if ((ship_fd = open(DATAFILE, 000, 0777)) < 0)
  {
    perror("main");
    printf("unable to open %s\n", DATAFILE);
    exit(-1);
  }
  check_size();

  if (argc == 1)
  {
    /* check the whole database for errors */
    for (i = 1; i <= num_ships; i++)
    {
      readship(&display, i);
      check_ship(i);
      free(display);
    }

    printf("I found a total of %d bad ships out of %d\n", bad_ship_count,
	   num_ships);
  }
  else if (!atoi(argv[1]))
  {
    /* a summary of all ships */
    for (i = 1; i <= num_ships; i++)
    {
      readship(&display, i);
      summarize_ship();
      free(display);
    }
  }
  else
  {
    /* we want a specific ship display */
    readship(&display, atoi(argv[1]));
    display_ship();
  }
  printf("All Done \n");

  return 0;
}

/* 
 * readship:
 * 
 * arguments: shiptype structure, shipnumber
 * 
 * called by:
 * 
 * description:  This funtion reads the actual data from the file.
 * 
 */

void
readship(shiptype ** s, int shipnum)
{
  int             n;

  if (shipnum <= 0)
    exit(1);

  if ((*s = (shiptype *) malloc(sizeof (shiptype))) == 0)
  {
    printf("getship:Malloc() error\n");
    exit(0);
  }
  if (lseek(ship_fd, (shipnum - 1) * sizeof (shiptype), L_SET) < 0)
  {
    perror("lseek");
    exit(1);
  }
  if ((n = read(ship_fd, (char *)*s, sizeof (shiptype))) != sizeof (shiptype))
    perror("read");

}

/* 
 * check_size:
 * 
 * arguments: none
 * 
 * called by: main
 * 
 * description:  gets the number of ships in the current database
 * 
 */
void
check_size(void)
{
  fstat(ship_fd, &buffer);
  num_ships = buffer.st_size / sizeof (shiptype);
  printf("Number of ships in database is %d\n", num_ships);
}

/* 
 * check_ship:
 * 
 * arguments: index
 * 
 * called by: main
 * 
 * description:  checks basic cargo to make sure its within limits of ships
 * ability.
 * 
 */
void
check_ship(int idx)
{
  int             ship_ok = 1;
  int             pop, troops, res, des, fu, speed, hanger;

  pop = troops = res = des = fu = speed = hanger = 1;

  if (display->owner == 0 && display->governor == 0 && display->type == 0 &&
      display->number == 0)
  {
    bad_ship_count++;
    printf("Uninitialized ship in position %d\n", idx);
    return;
  }

  if (display->type == OTYPE_FACTORY)
  {
    if (display->popn > Shipdata[(display)->type][ABIL_MAXCREW])
      ship_ok = pop = 0;
    if (display->troops > Shipdata[(display)->type][ABIL_MAXCREW])
      ship_ok = troops = 0;
    if ((display->popn + display->troops) >
	Shipdata[(display)->type][ABIL_MAXCREW])
      ship_ok = pop = troops = 0;
  }
  else
  {
    if (display->popn > display->max_crew)
      ship_ok = pop = 0;
    if (display->troops > display->max_crew)
      ship_ok = troops = 0;
    if ((display->popn + display->troops) > display->max_crew)
      ship_ok = pop = troops = 0;
  }
  if (display->resource > Max_resource(display) &&
      display->type != STYPE_SHUTTLE)
    ship_ok = res = 0;
  if (display->destruct > Max_destruct(display))
    ship_ok = des = 0;
  if ((int)display->fuel > Max_fuel(display))
    ship_ok = fu = 0;
  if (display->speed > Max_speed(display))
    ship_ok = speed = 0;
  if (display->hanger > display->max_hanger)
    ship_ok = hanger = 0;

  if (!ship_ok)
  {
    bad_ship_count++;

    printf("Problem with ship number %d\n", display->number);
    printf("\t\tOwner: %d\n", display->owner);
    printf("\t\tGovernor: %d\n", display->governor);
    printf("\t\tName: %s\n", display->name);
    printf("\t\tType: %c\n", Shipltrs[display->type]);
    printf("\n");

    printf("\t %s popn: %d\t max_popn: %d:\n", pop ? "      " : "----->",
	   display->popn, display->max_crew);
    printf("\t %s troops: %d\t max_troops: %d\n", troops ? "      " : "----->",
	   display->troops, display->max_crew);
    printf("\t %s resources: %d\t max_resources: %d\n",
	   res ? "      " : "----->", display->resource, display->max_resource);
    printf("\t %s destruct: %d\t max_destruct: %d\n", des ? "      " : "----->",
	   display->destruct, display->max_destruct);
    printf("\t %s fuel: %d\t max_fuel: %d\n", fu ? "      " : "----->",
	   (int)display->fuel, (int)display->max_fuel);
    printf("\t %s speed: %d\t max_speed: %d\n", speed ? "      " : "----->",
	   display->speed, display->max_speed);
    printf("\t %s hanger: %d\t max_hanger: %d\n", hanger ? "      " : "----->",
	   display->hanger, display->max_hanger);
  }
}

/* 
 * display_ship:
 * 
 * arguments: none
 * 
 * called by: main
 * 
 * description:  Prints a _long_ description a a specific ship.
 * 
 */
void
display_ship(void)
{
  printf("Ship Number: %d\tShip Type: %c\tShip Owner: %d\tShip Governor %d\n",
	 display->number, Shipltrs[display->type], display->owner,
	 display->governor);
  printf("Ship Name: %s\tAge: %d\n", display->name, display->age);

  printf("\nCrew: %-9d\t  Troops: %-6d\tArmor: %d\n", display->popn,
	 display->troops, display->armor);
  printf("Size: %-9d\t  Base Mass: %-4.1f\tBase Tech: %4.1f\n", display->size,
	 display->base_mass, display->tech);
  printf("Destruct: %-6d  Resources: %-6d\tCrystals: %d\n", display->destruct,
	 display->resource, display->crystals);
  printf("Fuel: %4.1f\t  Max Fuel: %-6d\tOn: %d\n", display->fuel,
	 display->max_fuel, display->on);
  printf("\n");
  printf("Whatorbits: %d Pos X: %lf  Pos Y: %lf  Sorbit: %d  Porbit: %d\n",
	 display->whatorbits, display->xpos, display->ypos, display->storbits,
	 display->pnumorbits);
  printf("whatdest: %d  deststar: %d  destpnum: %d\n", display->whatdest,
	 display->deststar, display->destpnum);
  printf("Loc X: %d  Loc Y: %d  Docked: %d\n", display->land_x, display->land_y,
	 display->docked);
  printf("\n");
  printf("Guns:\tPrimary: %-3d%c\n", display->primary,
	 (display->primtype == LIGHT ? 'L' : display->primtype ==
	  MEDIUM ? 'M' : display->primtype == HEAVY ? 'H' : 'N'));
  printf("     \tSecondary:  %-3d%c\n", display->primary,
	 (display->primtype == LIGHT ? 'L' : display->primtype ==
	  MEDIUM ? 'M' : display->primtype == HEAVY ? 'H' : 'N'));

  printf("\n");			/* fleet stuff -mfw */
  printf("Fleet: %d (%c)  Next in Fleet: %d\n", display->fleetmember,
	 (display->fleetmember + ('A' - 1)), display->nextinfleet);

#ifdef USE_VN
  /* VN mind output -mfw */
  if (display->type == OTYPE_VN || display->type == OTYPE_BERS)
  {
    printf("\nVon Neumann Mind:\n");
    printf("\tProgenitor: %-3u  Generation: %-3u\n",
	   display->special.mind.progenitor, display->special.mind.generation);
    printf("\tBusy: %-3u        Target: %-3u\n", display->special.mind.busy,
	   display->special.mind.target);
    printf("\tWho Killed: %-3u  Tampered: %-3u\n",
	   display->special.mind.who_killed, display->special.mind.tampered);
  }
#endif

  printf("\nShips: %-6d\n", display->ships);
  printf("Nextship: %-6d\t (%s) Reuse=%d\n", display->nextship,
	 display->alive ? "ALIVE" : "DEAD", display->reuse);
}

/* 
 * summarize_ship:
 * 
 * arguments: none
 * 
 * called by: main
 * 
 * description:  Prints a _short_ description a a specific ship.
 * 
 */
void
summarize_ship(void)
{
  printf("#%d %c [%d,%d] %s %s %d\n", display->number, Shipltrs[display->type],
	 display->owner, display->governor, (display->alive ? "alive" : "dead"),
	 (display->reuse ? "reuse" : ""), display->age);
}
