/*
 * Galactic Bloodshed, A multi-player 4X game of space conquest
 * Copyright (c) 1989 1990 by Robert P. Chansky, et al.
 * See GB_copyright.h for additional authors and details.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.
 *
 * The GNU General Public License is contained in the file LICENSE.
 *
 * -------------------------------------------------------------------------
 *
 * guardian.c - makes sure your GB server keeps running, sends notice
 * via email of any crashes, bails after 5 restarts.
 * by Michael F. Wilkinson 10/07/03
 * 
 */

#include <stdio.h>
#include <signal.h>
#include <libgen.h>		/* for basename() */
#include <unistd.h>		/* for chdir() */
#include <stdlib.h>		/* for system() */
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

#include "config.h"
#include "files.h"

#define UIDMIN 100		/* Minimum UID (user) that we'll run as */
#define GIDMIN 100		/* Minimum GID (group) that we'll run as */

#define RESTARTS 4		/* Number of times we restart before giving up */

char           *guard;
char           *prog;

int
main(int argc, char *argv[])
{
  sigset_t        newsigset;
  int             pid;
  int             status;
  char            timestr[80];
  char            corestr[160];
  char            temp[512];
  char           *bfn;
  struct tm      *mytime;
  time_t          tim;
  int             foundcore = 0;
  int             died = 0;
  char            repfile[80];
  FILE           *pidfile;
  FILE           *fp;
  uid_t           uid;
  gid_t           gid;

  guard = basename(*argv++);	/* remember guardian name */
  prog = PATH(bin/GB_server);	/* program to start */

  if (((uid = getuid()) < UIDMIN) || ((uid = geteuid()) < UIDMIN))
  {
        fprintf(stderr, "%s tried to run as user-id %d, requires at-least %d.\n", guard, uid, UIDMIN);
        exit(1);
  }

  if (((gid = getgid()) < GIDMIN) || ((gid = getegid()) < GIDMIN))
  {
        fprintf(stderr, "%s tried to run as group-id %d, requires at-least %d.\n", guard, gid, GIDMIN);
        exit(1);
  }

  if (getenv("HOME") == NULL)
  {
        fprintf(stderr, "Problem with shell, check HOME variable.\n");
        exit(1);
  }

  if (argc != 1)
  {
    fprintf(stderr, "No arguments required...\n");
    fprintf(stderr, "%s will automatically start %s\n", guard, prog);
    exit(1);
  }

  if (chdir(PATH(bin)) != 0)
  {
    fprintf(stderr, "%s: could not change directory to: %s\n", guard,
	    PATH(bin));
    exit(1);
  }

  bfn = basename(prog);

  sigemptyset(&newsigset);	/* newsigset is empty */
  sigaddset(&newsigset, SIGHUP);	/* add SIGHUP to newsigset */
  if (sigprocmask(SIG_BLOCK, &newsigset, NULL) < 0)
  {
    perror("could not block the signal");
    exit(1);
  }

  if (dup2(1, 2) < 0)
  {
    perror("could not duplicate stderr/stdout");
    exit(1);
  }

  /* create pid file */
  sprintf(temp, "%s/%s.pid", LOG(), guard);

  if ((pidfile = fopen(temp, "w+")) != 0)
  {
    fprintf(pidfile, "%d", (int)getpid());
    fclose(pidfile);
  }
  else
  {
    fprintf(stderr, "Unable to create %s\n", temp);
    exit(1);
  }

  fprintf(stderr, "%s: on duty.\n", guard);

  while (1)
  {
    switch (pid = fork())
    {
      case -1:			/* error! */
	perror("can't fork a child");
	sleep(600);		/* 10 min */
	break;
      case 0:			/* child */
	execl(prog, bfn, (char *)NULL);
	perror("can't exec child");
	exit(1);
	break;
      default:			/* parent */
	fprintf(stderr, "%s: starting '%s' with pid [%d]\n", guard, bfn, pid);

	/* wait for the little brat */
	while (wait(&status) != pid) ;

	break;
    }

    /* Did the child exit abnormally? */
    if (WIFEXITED(status) == 0)
    {
      /* we're out of fork, the process has died */
      died++;

      fprintf(stderr, "%s: '%s' died!\n", guard, bfn);

      /* get the current time */
      tim = time(NULL);
      mytime = localtime(&tim);
      strftime(timestr, sizeof (timestr), "%m.%d.%Y-%T", mytime);

      sprintf(corestr, "core-%s", timestr);

#ifdef DEBUG
      if (rename("core", corestr) == 0)
      {
	foundcore = 1;
	fprintf(stderr, "%s: found core file, moved to %s\n", guard, corestr);
      }
#  ifdef WCOREDUMP
      if (WCOREDUMP(status))
      {
	foundcore = 1;
      }
#  endif
#endif

      sprintf(repfile, "/tmp/%s-%d", guard, pid);

      if ((fp = fopen(repfile, "w")) != 0)
      {
	fprintf(fp, "Notice from %s\n'%s' died on %s\n", guard, bfn, timestr);

	if (foundcore)
	{
	  fprintf(fp, "A core file was produced.\n");
	}

	if (died > RESTARTS)
	{
	  fprintf(fp, "\nToo many restarts...giving up!\n\n");
	}
	else
	{
	  fprintf(fp, "\nWill attempt a restart...have a nice day!\n\n");
	}

	fclose(fp);

	sprintf(temp, "cat %s | %s -s \"GB Crash Guard Report\" %s; rm %s",
		repfile, MAILPROG, GODADDR, repfile);

	if (!system(temp))
	  fprintf(stderr, "%s: sent email crash report\n", guard);
	else
	  fprintf(stderr, "%s: could not send email crash report\n", guard);
      }
      else
      {
	fprintf(stderr, "%s: could not open %s\n", guard, repfile);
      }

      fprintf(stderr, "%s: time is '%s'\n", guard, timestr);

      if (died > RESTARTS)
      {
	fprintf(stderr, "Too many restarts (%d), shutting down.\n", died);
	exit(1);
      }

      /* wait a minute then try to start it up again */
      sleep(60);

      foundcore = 0;
    }
    else
    {
      /* We exited normally, so the guardian will shut down too */
      exit(0);
    }
  }
}
